package com.ge.capital.dms.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.ge.capital.dms.entity.CommonDoc;
import com.ge.capital.dms.entity.CorptaxDoc;
import com.ge.capital.dms.entity.DealDoc;
import com.ge.capital.dms.utility.DmsUtilityConstants;
import com.ge.capital.dms.utility.DmsUtilityService;

@Component
@Configuration
@EnableTransactionManagement
public class UpdateDAO {

	@PersistenceUnit
	private EntityManagerFactory emf;

	@Autowired
	private DmsUtilityService dmsUtilityService;

	@SuppressWarnings("unchecked")
	@Transactional
	public void updateMetadata(String docId, Map<String, String> inputMetadataMap) {

		System.out.println("Entering updateMetadata() in DAO...");
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		EntityManager em = emf.createEntityManager();

		Properties props = dmsUtilityService.loadPropertiesFile(DmsUtilityConstants.docIdMappingResource);

		Set<String> inputKeys = inputMetadataMap.keySet();

		String prefix = "";
		String updateKey = "";

		if (inputMetadataMap.containsKey("docMetaKey") || inputMetadataMap.containsKey("docMetaVal")) {
			updateKey = "document.update2.clause";
			prefix = "meta.";
		} else {
			updateKey = "document.update1.clause";
			prefix = "document.";
		}

		String whereKey = "document.where.clause";

		String updateQuery = "";

		updateQuery = props.getProperty(updateKey);
		// filters the required input attributes for metadata search
		for (String key : inputKeys) {
			updateQuery = updateQuery + " " + props.getProperty(prefix + key) + "=:" + key + " ,";
		}

		updateQuery = updateQuery.substring(0, updateQuery.length() - 1);

		updateQuery = updateQuery + " " + props.getProperty(whereKey) + " AND " + props.getProperty(prefix + "docId")
				+ "='" + docId + "'";

		if (prefix.equals("meta."))
			updateQuery = updateQuery + " AND " + props.getProperty(prefix + "docMetaKey") + "=:"
					+ props.getProperty(prefix + "docMetaKey");

		System.out.println("updateQuery......." + updateQuery);

		Query invoicesearchQuery = em.createQuery(updateQuery);

		// set the named query values for the metadata inputs
		for (final Iterator iter = inputMetadataMap.entrySet().iterator(); iter.hasNext();) {
			Map.Entry entry = (Entry) iter.next();
			final String key = (String) entry.getKey();
			try {
				if (key.contains("Date")) {
					String oldDate = inputMetadataMap.get(key);
					Date date = df.parse(oldDate);
					invoicesearchQuery.setParameter(key, date, TemporalType.TIMESTAMP);
				} else
					invoicesearchQuery.setParameter(key, inputMetadataMap.get(key));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		em.joinTransaction();
		System.out.println("invoicesearchQuery......." + updateQuery);
		invoicesearchQuery.executeUpdate();

	}

	@SuppressWarnings("unchecked")
	@Transactional
	public void updateDocumentTypeMetadata(String docType, String tableName, Map<String, String> updateParams) {

		EntityManager em = emf.createEntityManager();
		Properties props = dmsUtilityService.loadPropertiesFile(DmsUtilityConstants.docIdMappingResource);
		String documentType = docType;
		String updateKey = documentType + ".update." + tableName + ".clause";
		String whereKey = documentType + ".where." + tableName + ".clause";

		// for (Map<String, String> updateParam : updateParams) {
		String updateQuery = props.getProperty(updateKey);
		Set<String> updateKeys = updateParams.keySet();
		Iterator<String> itr = updateKeys.iterator();
		while (itr.hasNext()) {
			String key = itr.next();
			updateQuery = updateQuery + props.getProperty(documentType + "." + key) + "=:" + key + ",";
		}

		StringBuilder finalUpdateQuery = new StringBuilder(updateQuery);
		int index = finalUpdateQuery.lastIndexOf(",");
		finalUpdateQuery.replace(index, updateQuery.length() + index, "");
		String finalQry = finalUpdateQuery.toString() + " " + props.getProperty(whereKey);
		System.out.println("Query:  " + finalQry);
		Query updateMetadataQuery = em.createQuery(finalQry);

		for (Map.Entry<String, String> entry : updateParams.entrySet())
			updateMetadataQuery.setParameter(entry.getKey(), entry.getValue());

		em.joinTransaction();
		int result = updateMetadataQuery.executeUpdate();
		System.out.println("update successfully: " + result);
		updateQuery = "";
		finalUpdateQuery = null;

	}

	@SuppressWarnings("unchecked")
	@Transactional
	public void updateDocumentMetadata(String docType, Map<String, String> documentDetails) {

		EntityManager em = emf.createEntityManager();

		CommonDoc commonDoc = new CommonDoc();
		commonDoc.setDocId(documentDetails.get("docId"));
		commonDoc.setDocVersionId(documentDetails.get("docVersionId"));
		commonDoc.setDocName(documentDetails.get("docName"));
		commonDoc.setDocTitle(documentDetails.get("docTitle"));
		commonDoc.setDocType(documentDetails.get("docType"));
		commonDoc.setDocSource(documentDetails.get("docSource"));
		commonDoc.setMimeType(documentDetails.get("mimeType"));
		commonDoc.setIsMigrated(documentDetails.get("isMigrated"));
		commonDoc.setPermName(documentDetails.get("permName"));
		commonDoc.setRealmName(documentDetails.get("realmName"));
		commonDoc.setOwnerName(documentDetails.get("ownerName"));
		commonDoc.setCreateDate(java.sql.Timestamp.valueOf(documentDetails.get("createDate")));
		commonDoc.setCreator(documentDetails.get("creator"));
		commonDoc.setModifyDate(java.sql.Timestamp.valueOf(documentDetails.get("modifyDate")));
		commonDoc.setModifier(documentDetails.get("modifier"));
		commonDoc.setIsDeleted(documentDetails.get("isDeleted"));
		commonDoc.setIsCurrent(documentDetails.get("isCurrent"));
		if (documentDetails.get("versionNum") != null)
			commonDoc.setVersionNum(Long.parseLong(documentDetails.get("versionNum")));
		commonDoc.setDocState(documentDetails.get("docState"));
		commonDoc.setContentRef(documentDetails.get("contentRef"));
		commonDoc.setIsLocked(documentDetails.get("isLocked"));
		commonDoc.setFolderRef(documentDetails.get("folderRef"));
		em.joinTransaction();
		em.persist(commonDoc);

		Session session = em.unwrap(org.hibernate.Session.class);

		if (docType.equals("dealDoc")) {
			DealDoc dealDoc = new DealDoc();
			dealDoc.setDeal_doc_id(documentDetails.get("docId"));
			session.save(dealDoc);
		} else if (docType.equals("corptax")) {
			CorptaxDoc corptaxDoc = new CorptaxDoc();
			corptaxDoc.setCorptaxDocId(documentDetails.get("docId"));
			corptaxDoc.setCtScanDate(java.sql.Timestamp.valueOf(documentDetails.get("createDate")));
			session.save(corptaxDoc);
		}

		System.out.println("Document details created successfully...");

	}
	@SuppressWarnings("unchecked")
	@Transactional
	public int updateCustomerName(String partyNumber, String partyName) {
		EntityManager em = emf.createEntityManager();
		Properties props = dmsUtilityService.loadPropertiesFile(DmsUtilityConstants.docIdMappingResource);
		String updateKey = "deal.update.clause";
		String valueKey = "deal.value.clause";
		String whereKey = "deal.where.clause";

		String updateQuery = props.getProperty(updateKey)+" "+props.getProperty(valueKey)+" "+props.getProperty(whereKey);
	
		try {
		Query result = em.createQuery(updateQuery);
		result.setParameter("partyName", partyName);
		result.setParameter("partyNumber", partyNumber);
		
		
		em.getTransaction().begin();
		int count=result.executeUpdate();
		System.out.println("count......."+count);
        em.getTransaction().commit();
        return count;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	public int integFour(String partyNumber, String partyName,String creditNumber,String opportunityID) {
		int a = locUpdate(partyNumber,partyName,creditNumber,opportunityID);
		int b = permUpdate(creditNumber,opportunityID);
		int c = hfsUpdate(partyNumber,partyName,creditNumber,opportunityID);
		int d= origUpdate(partyNumber,partyName,creditNumber,opportunityID);
		return a+b+c+d;
	}
	public int permUpdate(String creditNumber,String opportunityID) {
		EntityManager em = emf.createEntityManager();
		Properties props = dmsUtilityService.loadPropertiesFile(DmsUtilityConstants.docIdMappingResource);
		String updateKey = "perm.update.clause";
		String valueKey = "perm.value.clause";
		String whereKey = "perm.where.clause";
		String updateQuery = props.getProperty(updateKey)+" "+props.getProperty(valueKey)+" "+props.getProperty(whereKey);
		try {
			Query result = em.createQuery(updateQuery);
			result.setParameter("permName", "Capital_ALF_HEF_FINAL_MANAGER");
			result.setParameter("opportunityId", opportunityID);
			result.setParameter("creditNumber", creditNumber);
			em.getTransaction().begin();
	        int count=result.executeUpdate();
	        System.out.println("count......."+count);
	        em.getTransaction().commit();
	        return count;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	@SuppressWarnings("unchecked")
	@Transactional
	public int locUpdate(String partyNumber, String partyName,String creditNumber,String opportunityID) {
		EntityManager em = emf.createEntityManager();
		Properties props = dmsUtilityService.loadPropertiesFile(DmsUtilityConstants.docIdMappingResource);
		String updateKey = "deal1.update.clause";
		String valueKey = "deal1.value.clause";
		String whereKey = "deal1.where.clause";

		String updateQuery = props.getProperty(updateKey)+" "+props.getProperty(valueKey)+" "+props.getProperty(whereKey);
	
		try {
		Query result = em.createQuery(updateQuery);
		result.setParameter("partyName", partyName);
		result.setParameter("partyNumber", partyNumber);
		result.setParameter("opportunityId", opportunityID);
		result.setParameter("creditNumber", creditNumber);

		em.getTransaction().begin();
        int count=result.executeUpdate();
        System.out.println("count......."+count);
        em.getTransaction().commit();
        return count;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
		
	}
	@SuppressWarnings("unchecked")
	@Transactional
	public int hfsUpdate(String partyNumber, String partyName,String creditNumber,String opportunityID) {
		EntityManager em = emf.createEntityManager();
		Properties props = dmsUtilityService.loadPropertiesFile(DmsUtilityConstants.docIdMappingResource);
		String updateKey = "hfs.update.clause";
		String valueKey = "hfs.value.clause";
		String whereKey = "hfs.where.clause";

		String updateQuery = props.getProperty(updateKey)+" "+props.getProperty(valueKey)+" "+props.getProperty(whereKey);
	
		try {
		Query result = em.createQuery(updateQuery);
		result.setParameter("partyName", partyName);
		result.setParameter("partyNumber", partyNumber);
		result.setParameter("opportunityId", opportunityID);
		result.setParameter("creditNumber", creditNumber);

		em.getTransaction().begin();
        int count=result.executeUpdate();
        System.out.println("count......."+count);
        em.getTransaction().commit();
        return count;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
		
	}
	@SuppressWarnings("unchecked")
	@Transactional
	public int origUpdate(String partyNumber, String partyName,String creditNumber,String opportunityID) {
		EntityManager em = emf.createEntityManager();
		Properties props = dmsUtilityService.loadPropertiesFile(DmsUtilityConstants.docIdMappingResource);
		String updateKey = "origin.update.clause";
		String valueKey = "origin.value.clause";
		String whereKey = "origin.where.clause";

		String updateQuery = props.getProperty(updateKey)+" "+props.getProperty(valueKey)+" "+props.getProperty(whereKey);
	
		try {
		Query result = em.createQuery(updateQuery);
		result.setParameter("partyName", partyName);
		result.setParameter("partyNumber", partyNumber);
		result.setParameter("opportunityId", opportunityID);
		result.setParameter("creditNumber", creditNumber);

		em.getTransaction().begin();
        int count=result.executeUpdate();
        System.out.println("count......."+count);
        em.getTransaction().commit();
        return count;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
		
	}
	@SuppressWarnings("unchecked")
	@Transactional
	public int loanUpdate(String creditNumber, String sequenceNumber, Date commencementDate) {

		EntityManager em = emf.createEntityManager();
		Properties props = dmsUtilityService.loadPropertiesFile(DmsUtilityConstants.docIdMappingResource);
		String updateKey = "common.update.clause";
		String valueKey = "common.value.clause";
		String whereKey = "common.where.clause";
// AND (deal.credit_number=:creditNumber OR deal.lw_sequence_num=:sequenceNumber)
		String updateQuery = props.getProperty(updateKey)+" "+props.getProperty(valueKey)+" "+props.getProperty(whereKey);
		try {
			System.out.println(updateQuery);
		Query result = em.createQuery(updateQuery);
		result.setParameter("retentionDate", commencementDate);
		result.setParameter("docState", "FINAL");
		result.setParameter("permName", "Capital_ALF_HEF_FINAL_MANAGER");
		result.setParameter("creditNumber", creditNumber);
		result.setParameter("sequenceNumber", sequenceNumber);
		System.out.println(result);
		em.getTransaction().begin();
		int count=result.executeUpdate();
        System.out.println("count......."+count);
        em.getTransaction().commit();
        return count;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return 0;

	}

}
