export class ContractDealDropDown {

  public id: number;
  public name: string;
}
