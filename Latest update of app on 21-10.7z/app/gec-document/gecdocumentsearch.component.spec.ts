import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GecDocumentSearchComponent } from './gecdocumentsearch.component';

describe('DocumentsearchComponent', () => {
  let component: GecDocumentSearchComponent;
  let fixture: ComponentFixture<GecDocumentSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GecDocumentSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GecDocumentSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
