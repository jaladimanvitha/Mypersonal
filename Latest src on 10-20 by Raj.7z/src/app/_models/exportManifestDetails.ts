import { ExportManifestModel } from './ExportManifestModel';

export class ExportManifestDetails {

    public docType = 'exportManifest';
    public ExportManifestModel: ExportManifestModel;

}
