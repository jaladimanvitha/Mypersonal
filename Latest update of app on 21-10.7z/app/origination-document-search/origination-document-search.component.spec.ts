import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OriginationDocumentSearchComponent } from './origination-document-search.component';

describe('OriginationDocumentSearchComponent', () => {
  let component: OriginationDocumentSearchComponent;
  let fixture: ComponentFixture<OriginationDocumentSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OriginationDocumentSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OriginationDocumentSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
