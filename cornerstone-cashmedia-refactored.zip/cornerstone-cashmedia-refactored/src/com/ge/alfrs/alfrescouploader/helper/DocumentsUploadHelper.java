package com.ge.alfrs.alfrescouploader.helper;

import java.io.File;
import java.io.FileWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;

import com.ge.alfrs.alfrescouploader.alfresco.AlfrescoOperations;
import com.ge.alfrs.alfrescouploader.common.Lockbox;
import com.ge.alfrs.alfrescouploader.constants.Constants;
import com.ge.alfrs.alfrescouploader.vo.XMLPropertyVO;

/**
 * DocumentsUploadHelper is a helper class used to read the properties from the
 * CommonDetails Properties file and set the data to CommonPropsVO bean and
 * assign the VO object to List.
 * 
 * @author mahindraSatyam, VS60636
 * 
 */
public class DocumentsUploadHelper {

	private int recievedTransactionsCount = 0;
	private int processedTransactionsCount = 0;

	private boolean isFailureCSVGenerated;
	private static Logger log = Logger.getLogger(DocumentsUploadHelper.class);
	private Map<String, List<XMLPropertyVO>> propertyMappings;
	private List<XMLPropertyVO> xmlPropertiesList;
	private Map<String, String> bankNameMappings;
	private Map<String, String> classNameMappings;

	private String metadataCSVFilePath;
	private String errorMessage = "";

	private String successCSVFilePath;
	private String failureCSVFilePath;

	/**
	 * @return the isFailureCSVGenerated
	 */
	public boolean isFailureCSVGenerated() {
		return isFailureCSVGenerated;
	}

	/**
	 * Constructor for initializing the DocumentsUploadHelper class with the
	 * metadataCSVFilePath which is passed as a input parameter
	 * 
	 * @param metadataCSVFilePath
	 *            String
	 */
	public DocumentsUploadHelper(String successCSVFilePath, String failureCSVFilePath, String metadataCSVFilePath,
			String incomingFolderPath) {

		String csvFileName;

		bankNameMappings = getNameValueMappings(Constants.BANK_NAME_MAPPING);
		classNameMappings = getNameValueMappings(Constants.CLASS_NAME_MAPPING);
		this.metadataCSVFilePath = metadataCSVFilePath;

		// csvFileName =
		// metadataCSVFilePath.replace(incomingFolderPath+File.separator,"");

		int fileNameIndex = 0;

		fileNameIndex = metadataCSVFilePath.lastIndexOf("\\");

		if (fileNameIndex == -1) {

			fileNameIndex = metadataCSVFilePath.lastIndexOf("/");
		}

		csvFileName = metadataCSVFilePath.substring(fileNameIndex + 1);

		log.info("csvFileName ======" + csvFileName);

		this.successCSVFilePath = successCSVFilePath + File.separator + Constants.SUCCESS_CSV_PREFIX + csvFileName;

		log.info("successCSVFilePath ======" + successCSVFilePath);

		this.failureCSVFilePath = failureCSVFilePath + File.separator + Constants.FAILURE_CSV_PREFIX + csvFileName;

		log.info("failureCSVFilePath ======" + failureCSVFilePath);

	}

	/**
	 * ingestDocuments method is used for starting the documents ingestion
	 * process and it uses AlfrescoOperations as a helper class for accessing
	 * Alfresco.
	 * 
	 */
	// removed targetObjStore param
	public boolean ingestDocuments() {

		boolean isUploaded = true;

		String sourceBankName = "";
		String targetDC = "";
		String csvRecordToWrite = "";

		List<Map<String, String>> csvFileRecordsList = null;
		List<String> unProcessedRecords = null;

		String objectStoreWithClassName = null;
		AlfrescoOperations alfrescoDocUploader = null;

		CSVReader csvReader = new CSVReader();
		XMLReader xmlReader = new XMLReader();
		CashMediaXMLReader mediaBusiness = new CashMediaXMLReader();

		try {
			unProcessedRecords = checkIfPreProcessed(metadataCSVFilePath);

			if (unProcessedRecords == null) {
				csvFileRecordsList = csvReader.readCSV(metadataCSVFilePath);

			} else if (unProcessedRecords.size() > 0) {
				csvFileRecordsList = csvReader.readCSV(unProcessedRecords, Constants.CSV_FILE_HEADERS);
			} else {
				log.info("All the records in the CSV file are processed");
				doPostCSVProcessing(metadataCSVFilePath);
				isFailureCSVGenerated = new File(failureCSVFilePath).exists();
				return true;
			}
			propertyMappings = xmlReader.getPropertyMappings();

			List<Lockbox> list = mediaBusiness.lockBox();

			if (csvFileRecordsList.size() > 0) {
				sourceBankName = bankNameMappings.get(csvFileRecordsList.get(0).get(Constants.CSV_COL_SourceBankName));
			} else {
				isFailureCSVGenerated = new File(failureCSVFilePath).exists();
				return false;
			}
			if (propertyMappings != null) {
				for (Map<String, String> csvDataMap : csvFileRecordsList) {

					long uploadStartTime = new Date().getTime();
					isUploaded = false;
					try {
						targetDC = classNameMappings.get(csvDataMap.get(Constants.CSV_COL_TARGETDC));
						csvRecordToWrite = mapToString(csvDataMap, targetDC);
						objectStoreWithClassName = Constants.FN_TARGET_OBJECTSTORE + ":" + targetDC;
						xmlPropertiesList = propertyMappings.get(objectStoreWithClassName);
						if (xmlPropertiesList != null) {
							// renamed variable filenetDocUploader to
							// alfrescoDocUploader
							alfrescoDocUploader = new AlfrescoOperations(csvDataMap, xmlPropertiesList, sourceBankName,
									targetDC, list);

							isUploaded = alfrescoDocUploader.ingestDocument();
							errorMessage = alfrescoDocUploader.getErrorMesage();
							if (isUploaded)
								log.info("Document upload to Alfresco commented.....assuming it is fine");

						} else {
							errorMessage = Constants.ERROR_MSG_CLASSMAPPING_NOTFOUND;
							writeProcessedRecordToCSV(isUploaded, csvRecordToWrite, targetDC);
							log.error(
									"Properties Mappings not found in properties mapping sheet for the document class: "
											+ objectStoreWithClassName + " for csv record: " + csvDataMap);
							continue;
						}

					} catch (Exception exception) {
						log.error(
								"Upload Faild: Error while retrieving the required meta data for the csv record with Check Number: "
										+ csvDataMap.get(Constants.CSV_COL_CheckNumber) + " because of: ",
								exception);
						exception.printStackTrace();
					}
					long startTime = new Date().getTime();
					log.info("csvRecordToWrite ===== " + csvRecordToWrite);
					writeProcessedRecordToCSV(isUploaded, csvRecordToWrite, targetDC);
					log.debug("Time taken for CSV writing: " + (new Date().getTime() - startTime));
					log.debug("------Total time taken for Upload process for a csv record: "
							+ (new Date().getTime() - uploadStartTime));

				}
			} else {
				log.error("Class properties mappings not created from the MappingsRules.xml file");
			}

			writeReconcilationReportToFile();
			doPostCSVProcessing(metadataCSVFilePath);

		} catch (Exception exception) {
			log.error("Error while intiating the ingestion of documents from the CSV file: " + metadataCSVFilePath
					+ " because of the error: ", exception);
			exception.printStackTrace();
		}
		isFailureCSVGenerated = new File(failureCSVFilePath).exists();
		return true;

	}

	/**
	 * checkIfPreProcessed method is used to know whether a CSV file which is
	 * being processed is already processed or not. If already processed it
	 * sends a list of unprocessed records from the CSV file if not it will send
	 * the null object static it is a new CSV file and it is not processed yet
	 * 
	 * @param csvFilePath
	 *            String
	 * @return List<String>
	 */
	public List<String> checkIfPreProcessed(String csvFilePath) {
		File successCSVRecordsFile = null;
		File failureCSVRecordsFile = null;
		List<String> unProcessedRecords = null;
		CSVReader csvReader = null;
		successCSVRecordsFile = new File(successCSVFilePath);
		failureCSVRecordsFile = new File(failureCSVFilePath);
		if (successCSVRecordsFile.exists() || failureCSVRecordsFile.exists()) {
			csvReader = new CSVReader();
			unProcessedRecords = csvReader.getUnprocessedRecords(successCSVFilePath, failureCSVFilePath, csvFilePath);

		} else {
			return null;
		}
		return unProcessedRecords;
	}

	/**
	 * doPostCSVProcessing method is used for performing post CSV file
	 * processing activities like renaming the processed CSV file to .done
	 * 
	 * @param csvFilePath
	 *            String
	 * @return boolean
	 */
	public boolean doPostCSVProcessing(String csvFilePath) {
		boolean isRenamed;
		File csvFile = null;
		File renamedFile = null;
		csvFile = new File(csvFilePath);
		System.gc();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		renamedFile = new File(csvFilePath.replace(".csv", ".done"));
		isRenamed = csvFile.renameTo(renamedFile);
		return isRenamed;
	}

	/**
	 * mapToString method is used to convert the map of data to a CSV file
	 * record string and returns the string which is used for writing to a CSV
	 * file
	 * 
	 * @param csvDataMap
	 *            Map<String,String>
	 * @return String
	 */
	public String mapToString(Map<String, String> csvDataMap, String targetDC) {

		String[] headerColumns = null;
		String csvRecord = "";

		if (targetDC.equalsIgnoreCase("FleetLockbox")) {
			headerColumns = Constants.CSV_FILE_HEADERS.split(Constants.CSV_HEADERS_SPLITTER);
		} else if (targetDC.equalsIgnoreCase("PMSLockbox")) {
			headerColumns = Constants.PMS_CSV_FILE_HEADERS.split(Constants.CSV_HEADERS_SPLITTER);

		}
		for (String headerColumn : headerColumns) {

			csvRecord += csvDataMap.get(headerColumn) + Constants.CSV_COLUMN_SEPARATOR;

		}

		return csvRecord.substring(0, csvRecord.length() - 1);
	}

	/**
	 * writeProcessedRecordToCSV method is used for calling the methods in CSV
	 * writer to write the processed record to the CSV file based on the
	 * isUploaded boolean value the processed record will be written to Success
	 * / Failure CSV file
	 * 
	 * @param isUploaded
	 *            boolean
	 * @param metadataRecord
	 *            String
	 */
	public void writeProcessedRecordToCSV(boolean isUploaded, String metadataRecord, String targetDC) {
		CSVWriter successRecordsCSVWriter;
		CSVWriter failureRecordsCSVWriter;

		try {
			log.info("successCSVFilePath in writeProcessedRecordToCSV ======" + successCSVFilePath);
			if (isUploaded) {
				if (targetDC.equalsIgnoreCase("FleetLockbox")) {

					successRecordsCSVWriter = new CSVWriter(Constants.CSV_FILE_HEADERS, successCSVFilePath);
					successRecordsCSVWriter.writeRecordToCSV(metadataRecord);
				} else if (targetDC.equalsIgnoreCase("PMSLockbox")) {
					successRecordsCSVWriter = new CSVWriter(Constants.PMS_CSV_FILE_HEADERS, successCSVFilePath);
					successRecordsCSVWriter.writeRecordToCSV(metadataRecord);
				}

			} else {
				if (targetDC.equalsIgnoreCase("FleetLockbox")) {

					log.info("It is a FleetLockBox......");
					log.info("Value of the string used for Writing to CSV ======" + Constants.CSV_FILE_HEADERS
							+ Constants.CSV_COLUMN_SEPARATOR + Constants.FAILURE_CSV_EXTRAHEADER);
					failureRecordsCSVWriter = new CSVWriter(Constants.CSV_FILE_HEADERS + Constants.CSV_COLUMN_SEPARATOR
							+ Constants.FAILURE_CSV_EXTRAHEADER, failureCSVFilePath);
					failureRecordsCSVWriter.writeRecordToCSV(metadataRecord + Constants.CSV_COLUMN_SEPARATOR
							+ (errorMessage == null ? Constants.ERROR_MSG_ALFRESCO_UPLOAD : errorMessage));
				} else if (targetDC.equalsIgnoreCase("PMSLockbox")) {
					failureRecordsCSVWriter = new CSVWriter(Constants.PMS_CSV_FILE_HEADERS
							+ Constants.CSV_COLUMN_SEPARATOR + Constants.FAILURE_CSV_EXTRAHEADER, failureCSVFilePath);
					failureRecordsCSVWriter.writeRecordToCSV(metadataRecord + Constants.CSV_COLUMN_SEPARATOR
							+ (errorMessage == null ? Constants.ERROR_MSG_ALFRESCO_UPLOAD : errorMessage));
				}
			}
		} catch (Exception exception) {
			log.error("Error while writing the record to Success / Failure CSV record is: " + metadataRecord
					+ " :: because of error:", exception);
		}
	}

	/**
	 * writeReconcilationReportToFile method is used for writing the
	 * reconcilation report once the utility is processed a particular XLS file
	 * 
	 * @param reportContent
	 *            String
	 */
	public void writeReconcilationReportToFile() {

		SimpleDateFormat destinationDateFormat = null;
		SimpleDateFormat reconcilationReportContentDateFormat = null;
		FileWriter reconcilationReportWriter = null;
		String reconcilationFilePath = "";
		String contentToWrite = "";

		try {
			recievedTransactionsCount = CSVReader.getCSVRecordsCount(metadataCSVFilePath);
			processedTransactionsCount = CSVReader.getCSVRecordsCount(successCSVFilePath);

			destinationDateFormat = new SimpleDateFormat(Constants.RECONCILATION_REPORTFILE_DATEFORMAT);
			reconcilationReportContentDateFormat = new SimpleDateFormat(Constants.RECONCILATION_REPORT_DATEFORMAT);

			contentToWrite = reconcilationReportContentDateFormat.format(new Date()) + " - "
					+ Constants.RECONCILATION_REPORT_STATEMENT;
			contentToWrite = contentToWrite.replace(Constants.RECONCILATION_REPORT_CONS_MetadataCSVFileName,
					metadataCSVFilePath);
			contentToWrite = contentToWrite.replace(Constants.RECONCILATION_REPORT_CONS_TransactionsCount,
					"" + recievedTransactionsCount);
			contentToWrite = contentToWrite.replace(Constants.RECONCILATION_REPORT_CONS_UploadCount,
					"" + processedTransactionsCount);

			reconcilationFilePath = Constants.RECONCILATION_REPORT_FILEPATH + destinationDateFormat.format(new Date())
					+ Constants.RECONCILATION_REPORTFILE_EXTENTION;
			reconcilationReportWriter = new FileWriter(reconcilationFilePath, true);
			reconcilationReportWriter.write(contentToWrite + System.getProperty("line.separator"));
			reconcilationReportWriter.close();
		} catch (Exception exception) {
			log.error("Error while generating the reconcilation report: ", exception);
		}
	}

	/**
	 * getNameValueMappings method is used for forming a map of name to value
	 * pair
	 * 
	 * @return HashMap<String,String>
	 */
	public HashMap<String, String> getNameValueMappings(String nameValueMaping) {
		HashMap<String, String> bankNameMappings = null;
		String bankNameMappingArr[] = nameValueMaping.split(";");
		bankNameMappings = new HashMap<String, String>();

		for (String currentMap : bankNameMappingArr) {
			bankNameMappings.put(currentMap.split(",")[0], currentMap.split(",")[1]);
		}
		return bankNameMappings;
	}

	/**
	 * convertDateFormat method is used to convert the given dateString in a
	 * required format which is taken from the properties file
	 * 
	 * @param dateString
	 *            String
	 * @return String
	 */
	public String convertDateFormat(String dateString) {
		String convertedDateString = null;
		SimpleDateFormat sourceDateFormat = null;
		SimpleDateFormat destinationDateFormat = null;

		sourceDateFormat = new SimpleDateFormat(Constants.CSV_DATE_FORMAT);
		destinationDateFormat = new SimpleDateFormat(Constants.FN_DATE_FORMAT);

		try {
			convertedDateString = destinationDateFormat.format(sourceDateFormat.parse(dateString));
		} catch (ParseException parseException) {
			log.error("Error while converting the date format ", parseException);
		} catch (Exception exception) {
			log.error("Error while converting the date format ", exception);
		}
		return convertedDateString;
	}

}
