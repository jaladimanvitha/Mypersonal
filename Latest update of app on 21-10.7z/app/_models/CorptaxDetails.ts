import { CorptaxModel } from './CorptaxModel';

export class CorptaxDetails {

    public docType = 'corptax';
    public corptaxModel: CorptaxModel;

}
