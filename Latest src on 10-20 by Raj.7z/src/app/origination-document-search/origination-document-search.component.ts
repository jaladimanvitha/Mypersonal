import { StatusDropDown } from '../_models/StatusDropDown';
import { WelcomePackageDropDown } from '../_models/WelcomePackageDropDown';
import { ContractDealDropDown } from '../_models/ContractDealDropDown';
import { SyndicationDropDown } from '../_models/SyndicationDropDown';
import { Component, OnInit } from '@angular/core';
import { OriginDocSearchModel } from '../_models';
import { InvoiceService } from '../_services';
import { OriginDocDetails } from '../_models/OriginDocDetails';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from '../_services/dateformat';

@Component({
  selector: 'app-origination-document-search',
  templateUrl: './origination-document-search.component.html',
  styleUrls: ['./origination-document-search.component.css'],
  providers: [
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
  ]
})
export class OriginationDocumentSearchComponent implements OnInit {

  status: OriginDocSearchModel = new OriginDocSearchModel();

  status1: StatusDropDown[] = [
    { id: 0, name: 'Interim' },
    { id: 1, name: 'Final' },
  ];

  welcome1: WelcomePackageDropDown[] = [
    { id: 0, name: 'True' },
    { id: 1, name: 'False' },

  ];

  contract1: ContractDealDropDown[] = [
    { id: 0, name: 'Loan' },
    { id: 1, name: 'Lease' },
    { id: 2, name: 'Progress-Loan' },

  ];

  syndication1: SyndicationDropDown[] = [
    { id: 0, name: 'True' },
    { id: 1, name: 'False' },

  ];

  public searchData: Array<object> = [];
  submitted = false;
  searchModel: OriginDocDetails = new OriginDocDetails();
  originDoc: OriginDocSearchModel = new OriginDocSearchModel;

  constructor(private _invoiceService: InvoiceService) {
  }
  ngOnInit() {

  }

  public getSearchData() {

    this.searchModel.originDoc = this.originDoc;
    this._invoiceService.searchOriginDocSearch(this.searchModel).subscribe((data: Array<object>) => {
      this.searchData = data['metadataList'];
      console.log('entered');
      // console.log(data);
      // console.log(this.searchModel);
      console.log(this.searchData);

    });
  }

  onSubmit() {
    this.getSearchData();
    document.getElementById('displaytable').style.display = 'inline-table';
    return true;
  }
}
