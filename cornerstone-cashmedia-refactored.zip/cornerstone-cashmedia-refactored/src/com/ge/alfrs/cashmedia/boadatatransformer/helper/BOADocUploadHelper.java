package com.ge.alfrs.cashmedia.boadatatransformer.helper;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ge.alfrs.cashmedia.boadatatransformer.constants.Constants;

/**
 * BOADocUploadHelper Class is used to read the CSV file by getting it from
 * folder and to write the data into a new CSV File.
 * 
 * @author CP97964
 * 
 */

public class BOADocUploadHelper {

	private static Logger log = Logger.getLogger(BOADocUploadHelper.class);
   

	String csvfilepathtoWrite = null;
	String imagesFolderPath = null;
	String formatedDate = null;
	int csvFileNumber = 0;
	int totalRecordsCount = 0;
	int exitCode = 0;
	SimpleDateFormat sdfDateFormat = null;
	Map<String, String> csvFilePathsMap = null;

	
	public int getExitCode(){
		return exitCode;
	}
	
	public BOADocUploadHelper() {
		csvFilePathsMap = new HashMap<String, String>();
		sdfDateFormat = new SimpleDateFormat(Constants.CURRENT_DATE_FORMAT);
		formatedDate = sdfDateFormat.format(new Date());
		csvfilepathtoWrite = Constants.CSV_FILEPATH_TO_WRITE.replaceFirst(
				Constants.Date_Name, formatedDate);
	}

	/**
	 * processDocuments method is used for starting CSV reading
	 * 
	 * @return boolean
	 * 
	 * */

	public boolean processDocuments() {

		boolean isMetadataCSVFileGenerated = false;
		boolean isRecordWrittenToCSVFile = false;
		String csvFilePath = null;
		List<Map<String, String>> csvFileRecordsList = null;
		Map<String, String> csvFilePaths = null;
		Map<String,String> defaultedValuesMapping = null;
		Set<String> lockBoxNamesSet = null;
		Iterator<String> lockBoxNamesItr = null;
		List<Map<String, String>> appendedCSVFileRecordList = null;
		CSVReader csvParsing = new CSVReader();
		try {

			appendedCSVFileRecordList = new ArrayList<Map<String, String>>();
			csvFilePaths = new HashMap<String, String>();
			lockBoxNamesSet = new HashSet<String>();
			csvFileRecordsList = new ArrayList<Map<String, String>>();
			csvFilePaths = getCSVFiles(Constants.LOCKBOX_PATH + File.separator	+ formatedDate);
			lockBoxNamesSet = csvFilePaths.keySet();
			lockBoxNamesItr = lockBoxNamesSet.iterator();
			defaultedValuesMapping = getNameValueMappings(Constants.COLUMN_VALUES_TOBE_DEFAULTED,Constants.COLUMN_VALUES_TOBE_DEFAULTED_SEPARATOR,Constants.COLUMN_VALUES_TOBE_DEFAULTED_VALUESEPARATOR);
			while (lockBoxNamesItr.hasNext()) {

				csvFilePath = csvFilePaths.get(lockBoxNamesItr.next());
				imagesFolderPath = csvFilePath.substring(0, csvFilePath
						.lastIndexOf(File.separator));

				csvFileRecordsList = csvParsing.readCSV(csvFilePath);
				
				appendedCSVFileRecordList = appendMultiValuedColumns(csvFileRecordsList);
				for (Map<String, String> currentRecordDataMap : appendedCSVFileRecordList) {
					isRecordWrittenToCSVFile = processRequiredMetadata(currentRecordDataMap,defaultedValuesMapping,imagesFolderPath);
					if(!isRecordWrittenToCSVFile){
						exitCode = Constants.EXITCODE_CSVRECORDS_PROCESSERRORS;
					}
				}
			}
			if(csvParsing.getExitCode() > 0){
				if(exitCode > 0){
					exitCode = exitCode!=csvParsing.getExitCode()?Constants.EXITCODE_CSVFILE_READISSUES:exitCode;					
				} else{
					exitCode = csvParsing.getExitCode();
				}
			}
			
			isMetadataCSVFileGenerated = new File(csvfilepathtoWrite+Constants.CSV_EXTENSION).exists();			
					
		} catch (Exception exception) {
			exception.printStackTrace();
			log.error("Error while processing the documents, because of the error: ",exception);
		}
		return isMetadataCSVFileGenerated;
	}

	/**
	 * getCSVFiles Method used to get all the CSV file paths from the lockbox
	 * folder
	 * 
	 * @param String
	 *            lockBoxPath
	 * 
	 * @return Map<String,List<String>> csvFilePathsMap
	 * 
	 * */

	public Map<String, String> getCSVFiles(String lockBoxPath) {

		String[] lockBoxNames = null;
		File[] lockBoxFolderPaths = null;
		File lockBoxesFolder = null;

		try {
			lockBoxesFolder = new File(lockBoxPath);
			
			if (lockBoxesFolder.exists()) {
				lockBoxFolderPaths = lockBoxesFolder.listFiles();
				
				if(lockBoxFolderPaths.length==0){ 
					
					log.info("There are no lock boxes for processing today at:"
							+ lockBoxesFolder);
					System.exit(Constants.EXITCODE_NOLOCKBOXS);
							}
				lockBoxNames = lockBoxesFolder.list();
				for (int noOfFolders = 0; noOfFolders < lockBoxFolderPaths.length; noOfFolders++) {
					csvFilePathsMap = findCSVFile(lockBoxNames[noOfFolders],
							lockBoxFolderPaths[noOfFolders]);
				}
			} else {
				log.info("Error occurs because the Root folder of todays lock boxes is not found: "
						+lockBoxesFolder);
				System.exit(Constants.EXITCODE_ROOTFOLDER_NOTFOUND);
			}
		}

		catch (Exception exception) {
			log.error("Error while getting CSV Files from the folder:"
					+ lockBoxesFolder + ", because of the error:", exception);
		}
		return csvFilePathsMap;
	}

	/**
	 * findCSVFiles method is used to find all the CSV files in the specified
	 * lockBox folder path.
	 * 
	 * @param String
	 *            lockBoxName
	 * @param File
	 *            lockBoxFile
	 * 
	 * @return Map<String,List<String>> csvFilePathsMap
	 */

	public Map<String, String> findCSVFile(String lockBoxName, File lockBoxFile) {

		File[] listOfFiles = null;
		boolean hasDetailsCSVFile = false;
		try {
			listOfFiles = lockBoxFile.listFiles();

			for (File csvFile : listOfFiles) {
				if (csvFile.isFile()
						&& csvFile.getName().toLowerCase().endsWith(Constants.DETAIL_CSV_EXTENSION)) {
					hasDetailsCSVFile = true;
					csvFilePathsMap.put(lockBoxName, csvFile.getAbsolutePath());
				}
			}

			if (!hasDetailsCSVFile) {
				log.error("There is no such file with the name:"
						+ Constants.DETAIL_CSV_EXTENSION + " in the lockbox: "
						+ lockBoxName);
				exitCode = Constants.EXITCODE_DETAILCSV_NOTFOUND;				
			}
		} catch (Exception exception) {
			exception.printStackTrace();
			log.error("Error while finding CSV Files in" + lockBoxFile
					+ ", because of the error : " + exception);	
		}
		return csvFilePathsMap;
	}

	/**
	 * Method used for processing required data from CSV file
	 * 
	 * @param Map
	 *            <String, String> csvFileRecord
	 * 
	 * @return Map<String, String> reqInvoiceMetaData
	 * 
	 * */
	public boolean processRequiredMetadata(Map<String, String> csvFileRecord,Map<String,String> defaultedValuesMapping, String imagesFolderPath)  {

		String currentColumnValue = null;
		String imageFilePath = null;
		String[] requiredProperties = null;
		String requiredCSVRecord = "";
        boolean isCSVFileGenerated=false;
		try {
				
			requiredProperties =(Constants.METADATA_CSV_HEADERS.split(Constants.COMMA_SEPERATOR));
			for (String propertyName : requiredProperties) {
				if ((propertyName.equalsIgnoreCase(Constants.CSV_COL_CheckImage)
						|| propertyName.equalsIgnoreCase(Constants.CSV_COL_EnvelopeImage) || propertyName.equalsIgnoreCase(Constants.CSV_COL_InvoiceImage))) {					
					requiredCSVRecord += "" + Constants.COMMA_SEPERATOR;					
					continue;
				}
				
				if (propertyName.equalsIgnoreCase(Constants.CSV_COL_ImagePath)) {
					imageFilePath = imagesFolderPath + File.separator + Constants.BOA_ImagesFolderName + File.separator + csvFileRecord.get(Constants.CSV_COL_Check);
					requiredCSVRecord += imageFilePath + Constants.BOA_ImageExtension + Constants.COMMA_SEPERATOR;
					continue;
				}
				
				currentColumnValue = csvFileRecord.get(propertyName)!= null ? csvFileRecord.get(propertyName).trim() : "";				
				if (Constants.COLUMN_VALUES_TO_ELIMINATE_TRAILINGZEROS.contains(propertyName+Constants.COLUMN_VALUES_TO_ELIMINATE_TRAILINGZEROS_SEPARATOR)) {
					currentColumnValue = currentColumnValue.replaceFirst("^0*", "");
				}
				
				if (currentColumnValue.equals("") && defaultedValuesMapping.containsKey(propertyName)) {
					requiredCSVRecord += defaultedValuesMapping.get(propertyName) + Constants.COMMA_SEPERATOR;
				} else{
					requiredCSVRecord += currentColumnValue + Constants.COMMA_SEPERATOR;
				}
			}
			isCSVFileGenerated = writeDataToCSV(requiredCSVRecord.substring(0, requiredCSVRecord.length()- 1));

		} catch (Exception exception) {
			exception.printStackTrace();
			log.error("Error while processing required metadata, because of the error:"
							,exception);
			return isCSVFileGenerated;
			
		}
		return isCSVFileGenerated;
	}

	/**
	 * writeDataToCSV method is to write data to the csv File
	 * 
	 * @param String
	 *            csvRecord
	 * @return boolean
	 */

	public boolean writeDataToCSV(String csvRecord) {

		boolean isWrittentoCSV = false;
		CSVWriter csvWriter = new CSVWriter();
		int recordsLimit = Integer.parseInt(Constants.CSV_RecordsLimit);

		try {
			
			if (totalRecordsCount >= recordsLimit) {
				csvfilepathtoWrite = Constants.CSV_FILEPATH_TO_WRITE
						.replaceFirst(Constants.Date_Name, formatedDate)
						+ "_" + ++csvFileNumber;
				totalRecordsCount = 0;
			}
			
			isWrittentoCSV = csvWriter.writeRecordToCSV(csvRecord,
					csvfilepathtoWrite + Constants.CSV_EXTENSION);
			if(isWrittentoCSV){
				totalRecordsCount++;
			}
									
		} catch (Exception exception) {
			exception.printStackTrace();
			log.error("Error while writing required metadata into csv file, because of the error:"
							+ exception);
				}
		
		return isWrittentoCSV;
	}

	/**
	 * appendMultiValuedColumns method is used to append the multiValued columns
	 * 
	 * @param List
	 *            <Map<String, String>> csvFileRecords
	 * 
	 * @return List<Map<String, String>> csvDataMap
	 */

	public List<Map<String, String>> appendMultiValuedColumns(
			List<Map<String, String>> csvFileRecords) {

		boolean isImageColumn = false;
		String multivalueIdentifier = null;
		String multiValueIdentifierValue = null;
		String erroredMultiValueIdentifierValue = "";
		String[] multiValuedProperties = null;
		String currentPropertyValue = null;
		String csvRecordColumnValue = null;
		Map<String, String> newDataMap;
		HashMap<String, Map<String, String>> csvDataMap = null;

		try {
            			
			multiValuedProperties = Constants.CSV_MULTIVALUED_COLUMNNAMES
					.split(Constants.CSV_MULTIVALUED_COLUMNNAMES_SEPARATOR);
			
			multivalueIdentifier = Constants.CSV_COL_MULTIIVALUEDENTIFIER;

			csvDataMap = new LinkedHashMap<String, Map<String, String>>();

			for (Map<String, String> csvFileRecordMap : csvFileRecords) {
				
				try{
					multiValueIdentifierValue = csvFileRecordMap
							.get(multivalueIdentifier);
					
					if (csvDataMap.get(multiValueIdentifierValue) == null) {
						if(erroredMultiValueIdentifierValue.equals(multiValueIdentifierValue)){
							continue;
						}
						csvDataMap.put(multiValueIdentifierValue, csvFileRecordMap);
					} else {
						newDataMap = csvDataMap.get(multiValueIdentifierValue);
	                    
	                    
						for (String currentProperty : multiValuedProperties) {
							
							isImageColumn = false;
							currentPropertyValue = newDataMap.get(currentProperty);
							csvRecordColumnValue = csvFileRecordMap.get(currentProperty);	
							
							if(csvRecordColumnValue != null){
								if (currentProperty
										.equalsIgnoreCase(Constants.CSV_COL_InvoiceImage)
										|| currentProperty
												.equalsIgnoreCase(Constants.CSV_COL_EnvelopeImage)
										|| currentProperty
												.equalsIgnoreCase(Constants.CSV_COL_CheckImage)) {
		                           
									isImageColumn = true;
									if (!(hasValueAlreadyPresent(currentPropertyValue,csvRecordColumnValue,true))
											&& !currentPropertyValue.equals("") && !csvRecordColumnValue.equals("")) {	
										currentPropertyValue += Constants.BOA_ImageExtension + Constants.SEMICOLON_SEPERATOR;
									}
									currentPropertyValue = hasValueAlreadyPresent(currentPropertyValue,csvRecordColumnValue,true) ? currentPropertyValue : currentPropertyValue+csvRecordColumnValue;
									newDataMap.put(currentProperty,currentPropertyValue);
								}
		
								if (!hasValueAlreadyPresent(currentPropertyValue,csvRecordColumnValue,false) && !isImageColumn) {								
									if(!currentPropertyValue.equals("") && !csvRecordColumnValue.equals("")){
										currentPropertyValue += Constants.SEMICOLON_SEPERATOR;									
									}									
									currentPropertyValue += csvRecordColumnValue;
									newDataMap.put(currentProperty,currentPropertyValue);
								}
		
							}
						}
						newDataMap = null;
					}
				} catch(Exception exception){
					log.error("Error while performing multivalued row appending operation for record with check number: "+csvFileRecordMap.get(Constants.CSV_COL_MULTIIVALUEDENTIFIER)+" because of the error: ",exception);
					csvDataMap.remove(multiValueIdentifierValue);
					erroredMultiValueIdentifierValue = multiValueIdentifierValue;
					exitCode = Constants.EXITCODE_CSVRECORDS_PROCESSERRORS;
				}
			}
		} catch (Exception exception) {
			exception.printStackTrace();
			log	.error("Error while appending multivalued columns because of error:"
							+ exception);
			exitCode = Constants.EXITCODE_CSVRECORDS_PROCESSERRORS;
			
		}

		return new ArrayList<Map<String, String>>(csvDataMap.values());
	}
	
	/**
	 * hasValueAlreadyPresent method is used to check the existingMultivalue is having the new value or not
	 * 
	 * @param String existingMultiValue
	 * @param String newValue
	 * @param boolean isImage
	 * @return boolean
	 */
	
	
	public boolean hasValueAlreadyPresent(String existingMultiValue,String newValue,boolean isImage){
		boolean isValuePresent = false;
		
		if(isImage){
			if(existingMultiValue.contains(Constants.SEMICOLON_SEPERATOR)){
				isValuePresent = (existingMultiValue.startsWith(newValue+Constants.BOA_ImageExtension) || existingMultiValue.endsWith(Constants.SEMICOLON_SEPERATOR+newValue) || existingMultiValue.contains(Constants.SEMICOLON_SEPERATOR+newValue+Constants.BOA_ImageExtension));
			} else{
				isValuePresent = existingMultiValue.equals(newValue);
			}
		} else{
			if(existingMultiValue.contains(Constants.SEMICOLON_SEPERATOR)){
				isValuePresent = (existingMultiValue.endsWith(Constants.SEMICOLON_SEPERATOR+newValue) || existingMultiValue.startsWith(newValue+Constants.SEMICOLON_SEPERATOR) || existingMultiValue.contains(Constants.SEMICOLON_SEPERATOR+newValue+Constants.SEMICOLON_SEPERATOR));
			} else{
				isValuePresent = existingMultiValue.equals(newValue);
			}
		}
		return isValuePresent;
	}

	/**
	 * getNameValueMappings method is used for forming a map of name to value pair
	 * 
	 * @param String nameValueMapping
	 * @param String mapSeparator
	 * @param String valueSeparator
	 * 
	 * @return HashMap<String,String>
	 */
	
	public HashMap<String,String> getNameValueMappings(String nameValueMaping, String mapSeparator, String valueSeparator){
		
		HashMap<String,String> defaultedValuesMappings = null;
		String valuesToBeDefaultedArray[]=null;
		try{
							 
			valuesToBeDefaultedArray = nameValueMaping.split(mapSeparator);
			defaultedValuesMappings = new HashMap<String,String>();
			
			for(String currentValue : valuesToBeDefaultedArray){
				defaultedValuesMappings.put(currentValue.split(valueSeparator)[0],currentValue.split(valueSeparator)[1]);
			}
		}
		catch(Exception exception){
			log.error("Error while mapping the default name and values because of the error:",exception);
		}
		return defaultedValuesMappings;
	}
	
}
                                                    