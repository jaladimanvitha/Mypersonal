package com.ge.alfrs.alfrescouploader.constants;

/**
 * 
 * Constants class is used to get the data from properties file and to store all the constant values
 * to be used in the utility
 *  
 * @author mahindraSatyam, VS60636
 */
public class Constants {
	
	public static final String LOG_FILEPATH = Messages.getString("logFilePath");
	public static final String LOG_FILENAME_DATEFORMAT = Messages.getString("logFileNameDateFormat");
	public static final String FOLDER_PATH = Messages.getString("folderPath");
	public static final String ALF_TICKET_REST_URL = Messages.getString("AlfTicketRestUrl");
	public static final String UPLOAD_WEBSCRIPT_URL = Messages.getString("uploadWebScriptUrl");
	
	//defined for box upload:
		public static final String BOX_UPLOAD_URL = Messages.getString("boxUploadUrl");
		public static final String CSV_COL_RFC_Remittance = Messages.getString("CSV_COL_RFC_Remittance");
		
	public static final String RECONCILATION_REPORT_FILEPATH = Messages.getString("RECONCILATION_REPORT_FILEPATH");
	public static final String RECONCILATION_REPORTFILE_DATEFORMAT = Messages.getString("RECONCILATION_REPORTFILE_DATEFORMAT");
	public static final String RECONCILATION_REPORTFILE_EXTENTION = Messages.getString("RECONCILATION_REPORTFILE_EXTENTION");
	public static final String RECONCILATION_REPORT_STATEMENT = Messages.getString("RECONCILATION_REPORT_STATEMENT");
	public static final String RECONCILATION_REPORT_CONS_TransactionsCount = Messages.getString("RECONCILATION_REPORT_CONS_TransactionsCount");
	public static final String RECONCILATION_REPORT_CONS_MetadataCSVFileName = Messages.getString("RECONCILATION_REPORT_CONS_MetadataCSVFileName");
	public static final String RECONCILATION_REPORT_CONS_UploadCount = Messages.getString("RECONCILATION_REPORT_CONS_UploadCount");
	public static final String RECONCILATION_REPORT_DATEFORMAT = Messages.getString("RECONCILATION_REPORT_DATEFORMAT");
	
	
	public static final int PDFIMAGE_SCALING_WIDTH = Integer.parseInt(Messages.getString("PDFIMAGE_SCALING_WIDTH"));
	public static final int PDFIMAGE_SCALING_HEIGHT = Integer.parseInt(Messages.getString("PDFIMAGE_SCALING_HEIGHT"));
	public static final int PDFPAGE_HEIGHT = Integer.parseInt(Messages.getString("PDFPAGE_HEIGHT"));
	public static final boolean PDFIMAGE_ISSCALING_REQUIRED = Boolean.parseBoolean(Messages.getString("PDFIMAGE_ISSCALING_REQUIRED"));
	public static final int PDFIMAGE_POSITIONING_SPACE = Integer.parseInt(Messages.getString("PDFIMAGE_POSITIONING_SPACE"));
	
	public static final String ATTR_SYMBOLIC_NAME = Messages.getString("ATTR_SYMBOLIC_NAME");
	public static final String ATTR_RULE = Messages.getString("ATTR_RULE");
	public static final String ATTR_VALUE = Messages.getString("ATTR_VALUE");
	public static final String ATTR_MAPPED_TO = Messages.getString("ATTR_MAPPED_TO");
	public static final String ATTR_DATATYPE = Messages.getString("ATTR_DATATYPE");
	public static final String ATTR_CARDINALITY = Messages.getString("ATTR_CARDINALITY");
	public static final String ATTR_MANDATORY = Messages.getString("ATTR_MANDATORY");
	
	public static final String ATTR_DATATYPE_INTEGER = Messages.getString("ATTR_DATATYPE_INTEGER");
	public static final String ATTR_DATATYPE_DOUBLE = Messages.getString("ATTR_DATATYPE_DOUBLE");
	public static final String ATTR_DATATYPE_STRING = Messages.getString("ATTR_DATATYPE_STRING");
	public static final String ATTR_DATATYPE_DATE = Messages.getString("ATTR_DATATYPE_DATE");	
	
	public static final String SUCCESS_CSV_PREFIX = Messages.getString("SUCCESS_CSV_PREFIX");
	public static final String FAILURE_CSV_PREFIX = Messages.getString("FAILURE_CSV_PREFIX");
	public static final String FAILURE_CSV_EXTRAHEADER = Messages.getString("FAILURE_CSV_EXTRAHEADER");
	public static final String SUCCESS_CSV_FILEPATH = Messages.getString("SUCCESS_CSV_FILEPATH");
	public static final String FAILURE_CSV_FILEPATH = Messages.getString("FAILURE_CSV_FILEPATH");
	public static final String METADATA_CSV_FILESPATH = Messages.getString("METADATA_CSV_FILESPATH");
	public static final String CSV_COLUMN_SEPARATOR = Messages.getString("CSV_COLUMN_SEPARATOR");
	public static final String CSV_VALUE_SEPARATOR = Messages.getString("CSV_VALUE_SEPARATOR");
	public static final String CSV_FILE_EXTENSION = Messages.getString("CSV_FILE_EXTENSION");
	
	public static final String CSV_FILE_HEADERS = Messages.getString("CSV_FILE_HEADERS");
	public static final String PMS_CSV_FILE_HEADERS = Messages.getString("PMS_CSV_FILE_HEADERS");
	public static final String CSV_HEADERS_SPLITTER = Messages.getString("CSV_HEADERS_SPLITTER");
	
	public static final String CSV_COL_CheckNumber =  Messages.getString("CSV_COL_CheckNumber");
	public static final String CSV_COL_SourceBankName =  Messages.getString("CSV_COL_SourceBankName");
	public static final String CSV_COL_CheckImage =  Messages.getString("CSV_COL_CheckImage");
	public static final String CSV_COL_EnvelopeImage =  Messages.getString("CSV_COL_EnvelopeImage");
	public static final String CSV_COL_InvoiceImage =  Messages.getString("CSV_COL_InvoiceImage");
	public static final String CSV_COL_LOCKBOXNUMBER =  Messages.getString("CSV_COL_LOCKBOXNUMBER");	
	public static final String CSV_COL_TARGETDC =  Messages.getString("CSV_COL_TARGETDC");
	public static final String CSV_COL_Image_Path =  Messages.getString("CSV_COL_Image_Path");

	public static final String BANK_SOURCETYPE_PNC =  Messages.getString("BANK_SOURCETYPE_PNC");
	public static final String BANK_SOURCETYPE_RBC =  Messages.getString("BANK_SOURCETYPE_RBC");
	public static final String BANK_SOURCETYPE_BOA =  Messages.getString("BANK_SOURCETYPE_BOA");
	public static final String BANK_SOURCETYPE_NT =  Messages.getString("BANK_SOURCETYPE_NT");
	public static final String BANK_NAME_MAPPING =  Messages.getString("BANK_NAME_MAPPING");
	public static final String CLASS_NAME_MAPPING =  Messages.getString("CLASS_NAME_MAPPING");
	
	public static final String CSV_DATE_FORMAT = Messages.getString("CSV_DATE_FORMAT");
	public static final String FN_DATE_FORMAT = Messages.getString("FN_DATE_FORMAT");
		
	public static final String RULE_DEFAULT = Messages.getString("RULE_DEFAULT");
	public static final String RULE_FEEDDRIVEN = Messages.getString("RULE_FEEDDRIVEN");
	public static final String RULE_CSV = Messages.getString("RULE_CSV");
	public static final String RULE_MAPPEDTO = Messages.getString("RULE_MAPPEDTO");
	public static final String RULE_DISPLAY = Messages.getString("RULE_DISPLAY");
	public static final String RULE_CONTENT = Messages.getString("RULE_CONTENT");	
			
	public static final String FN_TARGET_OBJECTSTORE = Messages.getString("FN_TARGET_OBJECTSTORE");
	public static final String FN_MIMETYPE = Messages.getString("FN_MIMETYPE");
	public static final String FN_CE_URI = Messages.getString("CE_URI");
	public static final String FN_DOMAINNAME = Messages.getString("FN_DOMAINNAME");
	public static final String FN_USERNAME = Messages.getString("FN_USERNAME");
	//public static final String FN_PASSWORD_FILE_PATH = Messages.getString("FileNetPasswordFilePath");
	public static final String FN_WASP_LOCATION = Messages.getString("waspLocation");
	
	public static final String FN_SYMNAME_BillingIDM = Messages.getString("FN_SYMNAME_BillingIDM");
	public static final String FN_SYMNAME_InvoiceNumber = Messages.getString("FN_SYMNAME_InvoiceNumber");	
	public static final String FN_SYMNAME_ImageType = Messages.getString("FN_SYMNAME_ImageType");
	public static final String FN_SYMNAME_Pages = Messages.getString("FN_SYMNAME_Pages");
	public static final String FN_SYMNAME_SourceType = Messages.getString("FN_SYMNAME_SourceType");
	
	public static final String FN_DISPVALUE_SEPERATOR = Messages.getString("FN_DISPVALUE_SEPERATOR");
	public static final String FN_DOCTITLE_CHECK_CONSTANT = Messages.getString("FN_DOCTITLE_CHECK_CONSTANT");
	public static final String FN_DOCTITLE_ENVELOPE_CONSTANT = Messages.getString("FN_DOCTITLE_ENVELOPE_CONSTANT");
	public static final String FN_DOCTITLE_REMITTANCE_CONSTANT = Messages.getString("FN_DOCTITLE_REMITTANCE_CONSTANT");
	
	public static final String FN_IMAGETYPE_CHECK_VALUE = Messages.getString("FN_IMAGETYPE_CHECK_VALUE");
	public static final String FN_IMAGETYPE_ENVELOPE_VALUE = Messages.getString("FN_IMAGETYPE_ENVELOPE_VALUE");
	public static final String FN_IMAGETYPE_REMITTANCE_VALUE = Messages.getString("FN_IMAGETYPE_REMITTANCE_VALUE");
	
	//public static final String FN_SECUIRTYPOLICY_3090US_ID = Messages.getString("FN_SECUIRTYPOLICY_3090US_ID");
	//public static final String FN_SECUIRTYPOLICY_3090CN_ID = Messages.getString("FN_SECUIRTYPOLICY_3090CN_ID");
	
	public static final String FN_SECUIRTYPOLICY_CDF_US = Messages.getString("FN_SECUIRTYPOLICY_CDF_US");
	public static final String FN_SECUIRTYPOLICY_FF_US = Messages.getString("FN_SECUIRTYPOLICY_FF_US");
	public static final String FN_SECUIRTYPOLICY_CDF_CANADA = Messages.getString("FN_SECUIRTYPOLICY_CDF_CANADA");

	public static final String MAPPINGRULES_XMLFILEPATH = Messages.getString("xmlFilePath");
	public static final String CASHMEDIA_BUSINESS_MAPPINGS = Messages.getString("CASHMEDIA_BUSINESS_MAPPINGS");
	
	public static final String RBC_CONS_IMAGEEXTENTION_REPLACER = Messages.getString("RBC_CONS_IMAGEEXTENTION_REPLACER");
	public static final String RBC_CONS_OFFSETDATA_STARTCHAR = Messages.getString("RBC_CONS_OFFSETDATA_STARTCHAR");
	public static final String RBC_CONS_OFFSETDATA_ENDCHAR = Messages.getString("RBC_CONS_OFFSETDATA_ENDCHAR");
	public static final String RBC_CONS_OFFSETDATA_SEPERATOR = Messages.getString("RBC_CONS_OFFSETDATA_SEPERATOR");
	
	public static final String ERROR_MSG_CLASSMAPPING_NOTFOUND = Messages.getString("ERROR_MSG_CLASSMAPPING_NOTFOUND");
	public static final String ERROR_MSG_PDFGENERATION = Messages.getString("ERROR_MSG_PDFGENERATION");
	public static final String ERROR_MSG_P8ERROR = Messages.getString("ERROR_MSG_P8ERROR");
	public static final String ERROR_MSG_PDFGENERATION_FILENOTFOUND = Messages.getString("ERROR_MSG_PDFGENERATION_FILENOTFOUND");
	public static final String ERROR_MSG_METADATAFORMATION = Messages.getString("ERROR_MSG_METADATAFORMATION");
	public static final String ERROR_MSG_ALFRESCO_UPLOAD = Messages.getString("ERROR_MSG_ALFRESCO_UPLOAD");
	
	
	public static final int EXITCODE_P8CONNECT_ISSUES = Integer.parseInt(Messages.getString("EXITCODE_P8CONNECT_ISSUES"));
	public static final int EXITCODE_METADATACSV_NOTFOUND = Integer.parseInt(Messages.getString("EXITCODE_METADATACSV_NOTFOUND"));
	public static final int EXITCODE_FAILURECSV_GENERATED = Integer.parseInt(Messages.getString("EXITCODE_FAILURECSV_GENERATED"));
	
    //PMS Enhancements
    
    public static final int CHECKNO_MAXLENGTH =  Integer.parseInt(Messages.getString("CHECKNO_MAXLENGTH"));
    
    //End
    
    //Security Policy Change
    public static final String FN_BANKNAME_BOA =  Messages.getString("FN_BANKNAME_BOA");
    public static final String FN_BANKNAME_RBC =  Messages.getString("FN_BANKNAME_RBC");
    public static final String FN_BANKNAME_NT =  Messages.getString("FN_BANKNAME_NT");
    
    public static final String FN_BUSINESS_CDF =  Messages.getString("FN_BUSINESS_CDF");
    public static final String FN_BUSINESS_FF =  Messages.getString("FN_BUSINESS_FF");
    public static final String FN_BUSINESS_CANADA =  Messages.getString("FN_BUSINESS_CANADA");
    public static final String FN_BUSINESS_FLEET_US =  Messages.getString("FN_BUSINESS_FLEET_US");
    public static final String FN_BUSINESS_FLEET_CANADA =  Messages.getString("FN_BUSINESS_FLEET_CANADA");
	//End
}

