﻿import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home';
import { SearchComponent } from './search/search.component';
import { CorptaxSearchComponent } from './corptax-search/corptax-search.component';
import { LockboxComponent } from './lockbox/lockbox.component';
import { ReportsComponent } from './reports/reports.component';
import { UploadComponent } from './upload/upload.component';
import { OriginationDocumentSearchComponent } from './origination-document-search/origination-document-search.component';
import { ManifestComponent } from './manifest/manifest.component';
import { HFSdocumentComponent } from './hfsdocument/hfsdocument.component';
import { DealsearchComponent } from './dealsearch/dealsearch.component';
import { GecDocumentSearchComponent } from './gec-document/gecdocumentsearch.component';
import { CreationDateReportComponent } from './creation-date-report/creation-date-report.component';
import { ExportManifestRecordComponent } from './export-manifest-record/export-manifest-record.component';
import { PartyDocumentUploadComponent } from './party-document-upload/party-document-upload.component';
import { AccountDocumentUploadComponent } from './account-document-upload/account-document-upload.component';
import { OpportunityDocumentUploadComponent } from './opportunity-document-upload/opportunity-document-upload.component';
import { LinesofcreditUploadComponent } from './linesofcredit-upload/linesofcredit-upload.component';
import { ContractUploadComponent } from './contract-upload/contract-upload.component';
const appRoutes: Routes = [
    { path: '', component: HomeComponent },
  
    { path : 'search', component: SearchComponent},
    { path : 'corptaxSearch', component: CorptaxSearchComponent},
    { path : 'reports', component: ReportsComponent},
    { path : 'lockbox', component: LockboxComponent},
    { path : 'upload', component: UploadComponent},
    { path : 'originDoc', component: OriginationDocumentSearchComponent},
    {path : 'manifest', component: ManifestComponent},
    {path : 'hfsdocument', component: HFSdocumentComponent},
    { path : 'dealsearch', component: DealsearchComponent},
    { path : 'documentsearch', component: GecDocumentSearchComponent},
    { path : 'creationDateReport', component: CreationDateReportComponent},
    {path : 'exportManifestRecord', component: ExportManifestRecordComponent},
    { path: 'partyDocumentUpload', component: PartyDocumentUploadComponent },
    { path: 'accountDocumentUpload', component: AccountDocumentUploadComponent },
    { path: 'opportunityDocumentUpload', component: OpportunityDocumentUploadComponent },
    { path: 'linesofcreditUpload', component: LinesofcreditUploadComponent },
    { path: 'contractUpload', component:ContractUploadComponent },
    // otherwise redirect to home
    { path: '**', redirectTo: '' }

];

export const routing = RouterModule.forRoot(appRoutes,{useHash: true});
