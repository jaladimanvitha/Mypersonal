package com.ge.alfrs.alfrescouploader.vo;

import java.io.File;
import java.io.Serializable;

/**
 * This Bean is used to set the Properties file and mimetype Values.
 * @author  mahindraSatyam, VS60636
 */

public class FileuploadVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 151L;
	private File file;
	private String mimetype;
	
	
	public File getFile() {
		return file;
	}
	public void setFile(File file) {
		this.file = file;
	}
	public String getMimetype() {
		return mimetype;
	}
	public void setMimetype(String mimetype) {
		this.mimetype = mimetype;
	}
}
