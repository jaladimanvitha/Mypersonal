import { Component, OnInit } from '@angular/core';
import { AccountDocUploadModel } from '../_models/AccountDocUploadModel';
import {Router, ActivatedRoute} from '@angular/router';
import { FileSelectDirective, FileUploader} from 'ng2-file-upload';
import { FormControl, NgForm, FormBuilder } from '@angular/forms';
import {NgbModal, ModalDismissReasons, NgbActiveModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-account-document-upload',
  templateUrl: './account-document-upload.component.html',
  styleUrls: ['./account-document-upload.component.css']
})
export class AccountDocumentUploadComponent implements OnInit {
  modalReference: NgbModalRef;
   closeResult: string;
  constructor(private modalService: NgbModal,private router:Router, private activatedRoute:ActivatedRoute) { }

  ngOnInit() {
   this.accountDoc.sfdcAccountId1 = this.activatedRoute.snapshot.queryParamMap.get('sfdcAccountId1');
    this.accountDoc.sfdcAccountName1 = this.activatedRoute.snapshot.queryParamMap.get('sfdcAccountName1');
  }
accountDoc : AccountDocUploadModel = new AccountDocUploadModel();
public acctData = [
{
 "documentSubType" : "",
  "welcomePackage" : "",
  "syndicationPackage": "",
  "physicalStorageStatus": "",
  "fileName": "",
  "progress": "",
 
}];

 upload(userForm: NgForm) {
   if(userForm.form.value.docSubType1 == null) {
     alert('document SubType cannot be Empty');
     return false;
   }else{
     if(userForm.form.value.sfdcAccountId1 == null){
     alert('SFDC Account ID cannot be Empty');
     return false;
     }
   }
  console.log(userForm.form.value);
  return true;
  }
  open(content) {
   this.modalReference = this.modalService.open(content);
   this.modalReference.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }
  close() {
     this.modalReference.close();
     this.router.navigate(['/home']);
    }
}
