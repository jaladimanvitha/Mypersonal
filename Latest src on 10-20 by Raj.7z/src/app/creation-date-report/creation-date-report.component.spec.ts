import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreationDateReportComponent } from './creation-date-report.component';

describe('CreationDateReportComponent', () => {
  let component: CreationDateReportComponent;
  let fixture: ComponentFixture<CreationDateReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreationDateReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreationDateReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
