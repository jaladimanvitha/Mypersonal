package com.ge.alfrs.cashmedia.boadatatransformer.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.log4j.Logger;
import com.ge.alfrs.alfrescouploader.util.AlfrescoUploaderUtility;
import com.ge.alfrs.cashmedia.boadatatransformer.constants.Constants;
import com.ge.alfrs.cashmedia.boadatatransformer.helper.BOADocUploadHelper;

/**
 * BOADocUploadUtil class is used to generate a csvFile based on the required
 * properties
 * 
 * @author CP97964
 * 
 */

public class BOADocUploadUtil {

	private static Logger log;

	
	/**
	 * configureLogFilePath method is used for configuring the log file path
	 */
	public static void configureLogFilePath(){
		String logFilePath;
		String dateStr;
		
		try{ 
			Date currentDate = new Date();
			SimpleDateFormat dateFormater = new SimpleDateFormat(Constants.LOG_FILENAME_DATEFORMAT);
			dateStr = dateFormater.format(currentDate);
			logFilePath = Constants.LOG_FILEPATH + "_" + dateStr + ".log";		
			System.setProperty("log.home", logFilePath);	
		} catch(Exception exception){
			log.error("Error occured while configuring logfile path" + exception);
		}
	}
	
	public static void main(String[] args) {
	
		//Refactored all the variables from p8 to alfresco convention
		
		boolean isMetaDataGenerated = false;	
		boolean isAlfrescoUploadUtilToBeInitiated = true;
		
		BOADocUploadHelper boaDocHelper = null;
		AlfrescoUploaderUtility alfrescoUploaderUtility = null;	
		configureLogFilePath();
		log = Logger.getLogger(AlfrescoUploaderUtility.class);
	
		boaDocHelper = new BOADocUploadHelper();
		isMetaDataGenerated = boaDocHelper.processDocuments();
		
		if(args.length > 0) {
			isAlfrescoUploadUtilToBeInitiated = args[0].equalsIgnoreCase("true") ? true : false;
		}
		
		if(isMetaDataGenerated){
			log.info("Converstion process ended......");
			if(isAlfrescoUploadUtilToBeInitiated){
				alfrescoUploaderUtility = new AlfrescoUploaderUtility(boaDocHelper.getExitCode());
				alfrescoUploaderUtility.startIngestionProcess(Constants.SUCCESS_CSV_FILEPATH,Constants.FAILURE_CSV_FILEPATH,Constants.METADATA_CSV_FILESPATH);
			}
		}
		else{
			log.info("Metadata CSV file is not generated");
			System.exit(Constants.EXITCODE_METADATACSV_NOTGENERATED);
		}
	}
}

