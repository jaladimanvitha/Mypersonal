export class ReportDropDown {

    public id: number;
    public name: string;

}
