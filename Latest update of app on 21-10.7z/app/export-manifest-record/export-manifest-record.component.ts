import { Component, OnInit } from '@angular/core';
import { ShippingMethodDropDown } from '../_models/shippingMethodDropDown';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from '../_services/dateformat';
import { ExportManifestModel } from '../_models/ExportManifestModel';
import { ExportManifestDetails } from '../_models/ExportManifestDetails';
import {NgbModal, ModalDismissReasons, NgbActiveModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import { FormControl, NgForm, FormBuilder } from '@angular/forms';
@Component({
  selector: 'app-export-manifest-record',
  templateUrl: './export-manifest-record.component.html',
  styleUrls: ['./export-manifest-record.component.css'],
  providers: [
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
  ]
})
export class ExportManifestRecordComponent implements OnInit {

  exportModel: ExportManifestModel = new ExportManifestModel();
   shippingMethod: ShippingMethodDropDown = new ShippingMethodDropDown();
shipping: ShippingMethodDropDown[] = [

    { id: 0, name: 'Select'},
    { id: 1, name: 'First Class'},
    { id: 2, name: 'First Class International'},
    { id: 3, name: 'Priority'},
    { id: 4, name: 'MediaMail'},
    { id: 5, name: 'Two-Day'},
    { id: 6, name: 'Fedex Overnight'},
    { id: 7, name: 'Ground'}

  ];
public exportManifest = [
{
 "senderName" : "87225521.pdf",
  "senderBusiness" : "",
  "shippingMethod": "N",
  "storerNum": "A",
  "trackingNum": "123",
  "businessLocation": "12/02/2016",
  "createdBy": "10/02/2018",
  "modifiedBy": "",
  "creationDateFrom": "B",
  "creationDateTo" : "",
  "modifiedDateFrom": "",
  "modifiedDateTo": ""
 
},
{
 "senderName" : "87225522.pdf",
  "senderBusiness" : "",
  "shippingMethod": "N",
  "storerNum": "B",
  "trackingNum": "103",
  "businessLocation": "",
  "createdBy": "10/03/2018",
  "modifiedBy": "12/04/2016",
  "creationDateFrom": "A",
  "creationDateTo" : "12/04/2016",
  "modifiedDateFrom": "",
  "modifiedDateTo": ""
 

},
{
  "senderName" : "87225571.pdf",
  "senderBusiness" : "",
  "shippingMethod": "N",
  "storerNum": "C",
  "trackingNum": "120",
  "businessLocation": "12/03/2016",
  "createdBy": "10/04/2018",
  "modifiedBy": "",
  "creationDateFrom": "Manvitha",
  "creationDateTo" : "",
  "modifiedDateFrom": "",
  "modifiedDateTo": ""
 

}
];
getLink(){
  console.log('Inside the method');
  document.getElementById('exportManifest').style.display="inline-block";
}
  constructor() { }

  ngOnInit() {
  }
  
  upload(userForm: NgForm) {
   if(userForm.form.value.senderName == null) {
     alert("Sender's Name cannot be Empty");
     return false;
   } else {
   		if(userForm.form.value.shippingMethod == null) {
   			alert('Shipping Method cannot be Empty');
   			return false;
   		} else {
   		   if(userForm.form.value.businessLocation == null) {
   		    alert('Business Location cannot be Empty');
   		    return false;
   		   }
   		}
   }
  console.log(userForm.form.value);
   document.getElementById('displayTable').style.display="inline-block";
  return true;
  }
   
 }