export class TypeIdDropDown {

  public id: number;
  public name: string;
}
