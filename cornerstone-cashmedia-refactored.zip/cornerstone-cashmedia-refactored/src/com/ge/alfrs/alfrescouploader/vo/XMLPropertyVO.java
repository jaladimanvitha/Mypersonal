package com.ge.alfrs.alfrescouploader.vo;

/**
 * This Bean is used to set the Property name and Property Values used for  storing the properties of the XML file.
 * @author  mahindraSatyam, VS60636
 */
public class XMLPropertyVO {
	
	private String symbolicName;
	private String rule;
	private String value;
	private String dataType;
	private String mappedTo;
	private String cardinality;
	private String isMandatory;
	
	/**
	 * @return  the symbolicName
	 */
	public String getSymbolicName() {
		return symbolicName;
	}
	/**
	 * @param symbolicName  the symbolicName to set
	 */
	public void setSymbolicName(String symbolicName) {
		this.symbolicName = symbolicName;
	}
	/**
	 * @return  the rule
	 */
	public String getRule() {
		return rule;
	}
	/**
	 * @param rule  the rule to set
	 */
	public void setRule(String rule) {
		this.rule = rule;
	}
	/**
	 * @return  the value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param value  the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	/**
	 * @return  the dataType
	 */
	public String getDataType() {
		return dataType;
	}
	/**
	 * @param dataType  the dataType to set
	 */
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	/**
	 * @return  the mappedTo
	 */
	public String getMappedTo() {
		return mappedTo;
	}
	/**
	 * @param mappedTo  the mappedTo to set
	 */
	public void setMappedTo(String mappedTo) {
		this.mappedTo = mappedTo;
	}
	/**
	 * @return  the cardinality
	 */
	public String getCardinality() {
		return cardinality;
	}
	/**
	 * @param cardinality  the cardinality to set
	 */
	public void setCardinality(String cardinality) {
		this.cardinality = cardinality;
	}
	/**
	 * @return  the isMandatory
	 */
	public String getIsMandatory() {
		return isMandatory;
	}
	/**
	 * @param isMandatory  the isMandatory to set
	 */
	public void setIsMandatory(String isMandatory) {
		this.isMandatory = isMandatory;
	}
	
	
}
