export class HFSdocumentModel {

    public referenceId: String;
    public srNumber: String;
    public documentDate: String;
    public subTypeId: String;
    public submittalId: String;
    public envelopeId: String;
    public platform: String;
    public subtypeId: String;
    public customerId: String;
    public transactionId: String;
    public hold: String;
    public program: String;
    public dockey: String;
    public takedownId: String;
    public scanDate: String;
    public programSegment: String;
    public customerEligibility: String;
    public classId: String;
    public typeId: String;
    public categoryId: String;
    public referenceCustomerId: String;
    public filenetGuid: String;
    public name: String;
    public title: String;

}
