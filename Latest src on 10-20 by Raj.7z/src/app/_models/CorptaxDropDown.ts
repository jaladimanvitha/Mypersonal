export class CorptaxDropDown {

    public id: number;
    public name: string;

}
