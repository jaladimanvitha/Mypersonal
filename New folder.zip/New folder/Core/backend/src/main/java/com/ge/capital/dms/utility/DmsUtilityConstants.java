package com.ge.capital.dms.utility;

public class DmsUtilityConstants {
	
	public static final String docIdMappingResource="docId-mapping.properties";
	public static final String docTypeMappingResource="doctype-mapping.properties";
	public static final String applicationConstantsResource="application-constants.properties";

}
