import { CorporationDropDown } from './corporationDropDown';
import { StatesDropDown } from './statesDropDown';
import { CountyDropDown } from './countyDropDown';


export class CorptaxModel {

  public corporation: string;
  public state: string;
  public county: string;
  public jurisdiction: string;
  public minYear: number;
  public maxYear: number;
  public checkRequestNumber: number;
  public checkNumber: number;
  public scanDateFrom: number;
  public scanDateTo: number;
  public documentName: string;
  public minAmount: string;
  public maxAmount: string;
  public fileNetGuid: string;
  public title: string;
  public name: string;
}
