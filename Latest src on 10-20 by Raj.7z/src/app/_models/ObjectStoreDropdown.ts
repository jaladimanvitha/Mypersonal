export class ObjectStoreDropdown {

    public id: number;
    public name: string;

}
