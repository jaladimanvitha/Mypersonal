package com.ge.alfrs.cashmedia.pncdatatransformer.helper;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.ge.alfrs.cashmedia.pncdatatransformer.constants.Constants;

/**
 * CSVReader class is used to read a CSV File from the given path.
 * 
 * @author CP97964
 * 
 */
public class CSVReader {
    
	private int exitCode = 0;
	private static Logger log = Logger.getLogger(CSVReader.class);

	
	public int getExitCode(){
		return exitCode;
	}
	
	/**
	 * readCSV method is used for reading the CSV File and returns a list with
	 * the data received from csvFilePath.
	 * 
	 * @param String
	 *            csvFilePath
	 * @return List<Map<String, String>>
	 * 
	 */

	public List<Map<String, String>> readCSV(String csvFilePath) {
	 
		String csvFileHeaders = null;
		String csvFileRecord = null;
		String[] csvHeader = null;
		BufferedReader csvFileReader = null;
		List<Map<String, String>> csvFileData = null;
		Map<String, String> csvRecordDetails = null;
		boolean isValidated = true;

		
		try {

			csvFileData = new ArrayList<Map<String, String>>();
			csvFileReader = new BufferedReader(new FileReader(csvFilePath));

			log.info("Reading CSV File  :  " + csvFilePath);

			csvFileReader.readLine();
			csvFileReader.readLine();
			if(csvFilePath.substring(csvFilePath.indexOf(File.separator)+1, csvFilePath.length()).matches(".*\\d.*")){
				csvFileReader.readLine();
			}
			csvFileHeaders = csvFileReader.readLine();			
			csvHeader = csvFileHeaders.split(Constants.COMMA_SEPERATOR);
			isValidated = validateCSVHeader(csvHeader);
			if (isValidated) {
				csvFileRecord = csvFileReader.readLine();
				if (csvHeader.length > 0) {
					while (csvFileRecord != null) {
						csvRecordDetails = new HashMap<String, String>();
						csvRecordDetails = getKeyPairData(csvFileHeaders,csvFileRecord);
						csvFileData.add(csvRecordDetails);
						csvFileRecord = csvFileReader.readLine();						
					}
				}
			}
			
			else {
				log.error("The CSV file at " + csvFilePath
						+ " is not in a valid format.");		
				if(exitCode>0){
					exitCode = exitCode!=Constants.EXITCODE_CSVHEADERS_INCORRECT?Constants.EXITCODE_CSVFILE_READISSUES:exitCode;					
				} else {
					exitCode = Constants.EXITCODE_CSVHEADERS_INCORRECT;
				}
			}
			
			AuditHelper auditHelper= new AuditHelper();
            auditHelper.startAuditProcess(csvFileData,csvFilePath);
		} catch (Exception exception) {
			exception.printStackTrace();
			log.error("Error while Reading CSV File at " + csvFilePath
					+ ", because of the error:" ,  exception);
			if(exitCode>0){
				exitCode = exitCode!=Constants.EXITCODE_CSVHEADERS_INCORRECT?Constants.EXITCODE_CSVFILE_READISSUES:exitCode;					
			} else {
				exitCode = Constants.EXITCODE_CSVHEADERS_INCORRECT;
			}
		}
		log.info("Completed Reading the CSV File  : " + csvFilePath);
		
		return csvFileData;
	}

	/**
	 * validateCSVHeader method is used for validating whether the CSV file received has got all the required details or not
	 * by validating the required header values against the header names received for that particular CSV file.
	 * 
	 * @param csvHeader String
	 * @return boolean
	 */
	public boolean validateCSVHeader(String[] csvHeader) {
		
		String metadataCSVHeaderNames[] = null;
		List<String> metadataCSVHeaderList = null;
		List<String> requiredCSVHeaderList = null;
		try {
			metadataCSVHeaderList = new ArrayList<String>(Arrays.asList(csvHeader));
			metadataCSVHeaderNames = Constants.REQUIRED_CSV_PROPERTY_NAMES.split(Constants.COMMA_SEPERATOR);
			requiredCSVHeaderList = new ArrayList<String>(Arrays.asList(metadataCSVHeaderNames));
		} catch (Exception exception) {
			log.error("Error while Validating CSV File Header, because ",exception);
		}
		return metadataCSVHeaderList.containsAll(requiredCSVHeaderList);
	}
	
	/**
	 * getObfuscatedValue is used for obfuscating a value which is passed as an input parameter
	 * 
	 * @param columnValue String
	 * @return String
	 */
	public String getObfuscatedValue(String columnValue){
		String originalData = null;
		String obfuscatedData = null;
		try{  	  
		originalData = columnValue.substring(0,columnValue.length() - 4);
		obfuscatedData = "";

		for (int i = 0; i < originalData.length(); i++) {
			obfuscatedData += "9";
		}
		
		obfuscatedData = columnValue.replace(originalData, obfuscatedData);
		}
		catch(Exception exception){
			exception.printStackTrace();
			log.error("Error occurs while Obfuscating beacause",exception);
			
		}
		return obfuscatedData;
	}

	/**
	 * getColumnDataMap method is used for pairing the keyName and keyValue with
	 * the update status
	 * 
	 * @param String
	 *            headerRecord
	 * @param String
	 *            valuesRecord
	 * @return Map< String, String > keyPairSet
	 */

	public Map<String, String> getKeyPairData(String headerRecord,
			String valuesRecord) {
		
		String currentColumnValue = null;
		String currentHeader = null;
		String[] keyName = null;
		String[] values = null;
		Map<String, String> keyPairSet = null;

		try {

			keyPairSet = new HashMap<String, String>();
			keyName = headerRecord.split(Constants.COMMA_SEPERATOR);
		
			values = valuesRecord.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
        
			for (int valuesCount = 0; valuesCount < values.length; valuesCount++) {

				if (values[valuesCount].indexOf("\"") != -1
						|| values[valuesCount].indexOf("$") != -1) {
					values[valuesCount] = values[valuesCount].replaceAll(
							"[$ \" , ]+", "");
				}
			}
		
			for (int keyNumber = 0; keyNumber < keyName.length; keyNumber++) {
				
				currentHeader = keyName[keyNumber];
				currentColumnValue = values.length <= keyNumber?"":values[keyNumber];				
				
				if (currentHeader.equalsIgnoreCase(Constants.CSV_COL_ABA) && Constants.ISOBFUSCATION_REQUIRED) {
					currentColumnValue = getObfuscatedValue(currentColumnValue);
				}
				keyPairSet.put(currentHeader,currentColumnValue);				
			}
			if (keyPairSet.get(Constants.CSV_COL_CheckImage).equalsIgnoreCase(
					keyPairSet.get(Constants.CSV_COL_InvoiceImage))) {
				keyPairSet.put(Constants.CSV_COL_InvoiceImage, "");
			}

		}

		catch (Exception exception) {
			log.error("Error in setting keyPair while reading CSV File record: {"+valuesRecord+"} because of the error : ",exception);
			if(exitCode>0){
				exitCode = exitCode!=Constants.EXITCODE_CSVRECORDS_PROCESSERRORS?Constants.EXITCODE_CSVFILE_READISSUES:exitCode;					
			} else {
				exitCode = Constants.EXITCODE_CSVRECORDS_PROCESSERRORS;
			}

		}

		return keyPairSet;
	}
	
	/**
	 * getNumberOfLines method is used to return number of lines present in a file
	 * @param filePath String
	 * @return linesCount int
	 */
	public int getNumberOfLines(String filePath){
		int numberOfLines = 0;
		LineNumberReader reader;
		
		try {
			reader = new LineNumberReader(new FileReader(filePath));
			while (reader.readLine() != null) {
			}
			numberOfLines = reader.getLineNumber();
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return numberOfLines;
	}
}
