export class LockboxNumDropDown {

  public id: number;
  public name: string;
}
