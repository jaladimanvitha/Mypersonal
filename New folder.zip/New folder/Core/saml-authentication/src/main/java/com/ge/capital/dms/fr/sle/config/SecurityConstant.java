package com.ge.capital.dms.fr.sle.config;

/**
 * @author slemoine
 */
public class SecurityConstant {

    public static final String JWT_SECRET = "yeWAgVDfb$!MFn@MCJVN7uqkznHbDLR#";

    private SecurityConstant(){}


}
