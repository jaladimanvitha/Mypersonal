package com.ge.alfrs.alfrescouploader.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "lockboxid", "lockboxbusiness", "country",
        "securitypolicyid", "bankname" })
@XmlRootElement(name = "lockbox")
public class Lockbox {

    @XmlElement(name = "lockboxid", nillable = false, namespace = "http://www.ge.com/CashMapping")
    protected String lockboxid;
    @XmlElement(name = "lockboxbusiness", nillable = false, namespace = "http://www.ge.com/CashMapping")
    private String lockboxbusiness;
    @XmlElement(name = "country", nillable = false, namespace = "http://www.ge.com/CashMapping")
    private String country;
    @XmlElement(name = "securitypolicyid", nillable = false, namespace = "http://www.ge.com/CashMapping")
    private String securitypolicyid;
    @XmlElement(name = "bankname", nillable = false, namespace = "http://www.ge.com/CashMapping")
    private String bankname;

    public String getSecuritypolicyid() {
        return securitypolicyid;
    }

    public void setSecuritypolicyid(String securitypolicyid) {
        this.securitypolicyid = securitypolicyid;
    }

    public String getLockboxid() {
        return lockboxid;
    }

    public void setLockboxid(String lockboxid) {
        this.lockboxid = lockboxid;
    }

    public String getLockboxbusiness() {
        return lockboxbusiness;
    }

    public void setLockboxbusiness(String lockboxbusiness) {
        this.lockboxbusiness = lockboxbusiness;
    }

    public String getBankname() {
        return bankname;
    }

    public void setBankname(String bankname) {
        this.bankname = bankname;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

}
