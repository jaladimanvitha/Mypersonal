@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.ge.com/CashMapping")
package com.ge.alfrs.alfrescouploader.common;