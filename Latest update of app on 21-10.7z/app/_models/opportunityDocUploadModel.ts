export class OpportunityDocUploadModel {
    public partyNumber4: string;
    public partyName4: string;
    public sfdcAccountId4: string;
    public sfdcAccountName4: string;
    public sfdcopportunityId4: string;
    
}
