import {Component} from '@angular/core';

/**
 * @title Basic DateTime Picker
 */
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'datepicker-component',
  templateUrl: 'datepicker.component.html'

})


export class DatePickerComponent {}
