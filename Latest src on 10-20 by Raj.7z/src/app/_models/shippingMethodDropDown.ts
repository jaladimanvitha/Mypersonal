export class ShippingMethodDropDown {

    public id: number;
    public name: string;

}
