import { TypeIdDropDown } from '../_models/TypeIdDropDown';
import { Component, OnInit } from '@angular/core';
import { HFSdocumentModel } from '../_models/HFSdocumentModel';
import { HFSdocumentDetails } from '../_models/HFSdocumentDetails';
import { InvoiceService } from '../_services';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from '../_services/dateformat';
import { NgForm } from '@angular/forms';
import { SubtypeIdDropDown } from '../_models/SubtypeIdDropDown';

@Component({
  selector: 'app-hfsdocument',
  templateUrl: './hfsdocument.component.html',
  styleUrls: ['./hfsdocument.component.css'],
  providers: [
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
  ]
})
export class HFSdocumentComponent implements OnInit {

  typeId: HFSdocumentModel = new HFSdocumentModel();
  subtypeid1: SubtypeIdDropDown[] = [
    { id: 0, name: 'sub id 1' },
    { id: 1, name: 'sub id 2' },

  ];
  typeids: TypeIdDropDown[] = [
    { id: 0, name: 'TypeID 1' },
    { id: 1, name: 'TypeID 2' },
  ];




  hfsdoc: HFSdocumentModel = new HFSdocumentModel();
  public searchData: Array<object> = [];
  submitted = false;
  searchModel: HFSdocumentDetails = new HFSdocumentDetails();
  hfsModel: HFSdocumentModel = new HFSdocumentModel();

  constructor(private _invoiceService: InvoiceService) {
  }
  ngOnInit() {

  }

  public getSearchData() {

    this.searchModel.hfsModel = this.hfsModel;
    this._invoiceService.searchHfsDocument(this.searchModel).subscribe((data: Array<object>) => {
      this.searchData = data['metadataList'];
      console.log('entered');
      // console.log(data);
      console.log(this.searchModel);
      console.log(this.searchData);

    });
  }
  valid(userForm: NgForm) {
    console.log(userForm);
  }
  onSubmit() {
    this.getSearchData();
    document.getElementById('displaytable').style.display = 'inline-table';
    return true;
  }
}
