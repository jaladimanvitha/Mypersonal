export class AccountDocUploadModel {

    public sfdcAccountId1: string;
    public sfdcAccountName1: string;
  
    
}
