package com.ge.alfrs.alfrescouploader.helper;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.Date;
import java.util.List;
import javax.imageio.ImageIO;
import org.apache.log4j.Logger;

import com.ge.alfrs.alfrescouploader.constants.Constants;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Image;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.RandomAccessFileOrArray;
import com.lowagie.text.pdf.codec.TiffImage;


/**
 * PDFGenerator class is used for converting the document into pdf
 * 
 * @author mahindraSatyam, VS60636
 */


public class PDFGenerator {

	private int pagesCount = 0;
	

	Document document;
	PdfWriter writer;
	boolean isScalingRequired;
	ByteArrayOutputStream byteArrayOutputStream = null;
	private static Logger log = Logger.getLogger(PDFGenerator.class);
	
	
	/**
	 * @return the pagesCount
	 */
	public int getPagesCount() {
		return pagesCount;
	}

	
	/**
	 * Constructor for PDFGenerator class for initializing PDF writer object
	 */
	public PDFGenerator() {
		
		document = new Document();
		try {
			isScalingRequired = Constants.PDFIMAGE_ISSCALING_REQUIRED;
			byteArrayOutputStream = new ByteArrayOutputStream();
			writer = PdfWriter.getInstance(document, byteArrayOutputStream);
			writer.setStrictImageSequence(true);
			document.open();
		}  catch (DocumentException e) {
			log.error("Error while initializing the PDF writer because of the reason: ",e);
		}
	}

	/**
	 * imageToPDF method is used for converting JPG image to PDF
	 * 
	 * @param imageFilePath String
	 * @return boolean
	 */
	public boolean imageToPDF(String imageFilePath) {
		boolean isImageAddedToDocument = false;
		BufferedImage bufferedImage;
		ByteArrayOutputStream outStream;
		Image image;
		
		try {
			long startTime1 = new Date().getTime();
			bufferedImage = ImageIO.read(new File(imageFilePath));
			
			
			log.info("Inmage to Read method :: imageToPDF");
			
			
			log.debug("Time taken for image to buffered image writing: "+(new Date().getTime() - startTime1));
			outStream = new ByteArrayOutputStream();
			
			long startTime = new Date().getTime();
			ImageIO.write(bufferedImage, "jpg", outStream);
	        log.debug("Time taken for image to stream writing: "+(new Date().getTime() - startTime));
						
			long writeStartTime = new Date().getTime();
			image = Image.getInstance(outStream.toByteArray());
			isImageAddedToDocument = addImageToDocument(image, isScalingRequired);
			log.debug("Time taken for pdf writing: "+(new Date().getTime() - writeStartTime));
			
			return isImageAddedToDocument;
		} catch (Exception e) {
			log.error("Error while converting the image: "+imageFilePath +" to PDF because of the reason ",e);
		}
		return false;
	}

	/**
	 * tiffToPDF method is used for converting TIFF image passed as the input parameter to the PDF
	 * 
	 * @param tiffImageFilePath String
	 * @return boolean
	 * @throws DocumentException
	 * @throws IOException
	 */
	public boolean tiffToPDF(String tiffImageFilePath)
			throws DocumentException, IOException {
	    
	    Image image;
		
		RandomAccessFileOrArray ra = new RandomAccessFileOrArray(
				tiffImageFilePath);
				
		int pages = TiffImage.getNumberOfPages(ra);

		for (int i = 1; i <= pages; i++) {
			image = TiffImage.getTiffImage(ra, i);
			addImageToDocument(image, isScalingRequired);
		}
		this.pagesCount = pages;
		return true;

	}

	/**
	 * addImageToDocument method is used for adding the Image object which is passed as input parameter to the
	 * PDF document will return the PDF document as an output stream
	 * 
	 * @param image Image
	 * @param isScalingRequired boolean
	 * @return OutputStream
	 */
	public boolean addImageToDocument(Image image,boolean isScalingRequired){
		int pos = 0;
		float percent = 100;
		Rectangle pageSize;
		try {
			
			
			
			if(isScalingRequired){
				if (image.getWidth() > Constants.PDFIMAGE_SCALING_WIDTH){
					percent = ((Constants.PDFIMAGE_SCALING_WIDTH) * 100 / (image.getWidth()));
					image.scalePercent(percent); 
				} if(image.getScaledHeight() > Constants.PDFIMAGE_SCALING_HEIGHT){
					percent = ((Constants.PDFIMAGE_SCALING_HEIGHT) * 100 / (image.getHeight()));
					image.scalePercent(percent); 
				}
				pos = (int) (Constants.PDFPAGE_HEIGHT - image.getScaledHeight());
		        
				
				log.info("Inmage1 to Read method :: addImageToDocument");
				
				
				document.newPage();
			} else{
				pageSize = new Rectangle(image.getWidth(), image.getHeight());
		     	document.setPageSize(pageSize);
		     	
		     	log.info("Inmage2 to Read method :: addImageToDocument");
		     	
		     	document.newPage();
			}
			
			       
			log.info("Inmage3 to Read method :: addImageToDocument");
			
	        image.setAbsolutePosition(0, pos-Constants.PDFIMAGE_POSITIONING_SPACE);
			document.add(image);			
			
		} catch (Exception e) {
			log.error("Error while adding the image to PDF because of the reason ",e);
			return false;
		}
		return true;
	}
	

	/**
	 * convertToPDF method is a method exposed to other classes which will be used for converting the
	 * list of image files path sent to it as input parameters into a PDF and returns the generated PDF file as an
	 * input stream
	 * 
	 * @param imageFilePaths List<String>
	 * @return InputStream
	 */
	public InputStream convertToPDF(List<String> imageFilePaths, boolean isTiffImage) {
		boolean isImageConvertedToPDF = false;
		InputStream inputStream = null;
        try {
        	
        	log.info("Inmage1 to Read method :: convertToPDF");
        	
        	for (String currentFilePath : imageFilePaths) {        		
    			if(currentFilePath.endsWith(".jpg")){
    				isImageConvertedToPDF = imageToPDF(currentFilePath);
    				if(!isImageConvertedToPDF){
    					log.info("Inmage32 to Read method :: convertToPDF");
    					return null;
    					
    				}
    			} else if(currentFilePath.endsWith(".tif") || isTiffImage){
    				tiffToPDF(currentFilePath);   
    				log.info("Inmage33 to Read method :: convertToPDF");
    			}			
    		}
        	
        	document.close();
        	if(byteArrayOutputStream.size()>0){
        		log.info("Inmage34 to Read method :: convertToPDF");
        		inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
        	} else{
        		return null;
        	}
			
		} catch (Exception e) {
		    e.printStackTrace();
			log.error("Error while converting image to PDF because of the reason: ",e);
		}  
		return inputStream;
	}
	
	/**
	 * convertToPDF method is a method exposed to other classes which will be used for converting the
	 * an image file path sent to it as input parameters into a PDF and returns the generated PDF file as an
	 * input stream
	 * 
	 * @param imageFilePath String
	 * @return InputStream
	 */
	public InputStream convertToPDF(String imageFilePath, boolean isTiffImage) {
		boolean isImageConvertedToPDF = false;
		InputStream inputStream = null;
        try {
        	
        	log.info("Inmage43 to Read method :: convertToPDF");
        	        		
			if(imageFilePath.endsWith(".jpg")){
				isImageConvertedToPDF = imageToPDF(imageFilePath);
				if(!isImageConvertedToPDF){
					log.info("Inmage34 to Read method :: convertToPDF STRING");
					return null;
				}
			} else if(imageFilePath.endsWith(".tif") || isTiffImage){
				log.info("Inmage44 to Read method :: convertToPDF STRING");
				tiffToPDF(imageFilePath);    				
			}			
    		
        	
        	document.close();
        	if(byteArrayOutputStream.size()>0){
        		log.info("Inmage44 to Read method :: convertToPDF STRING");
        		inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
        	} else{
        		return null;
        	}
			
		} catch (Exception e) {
		    e.printStackTrace();
			log.error("Error while converting image to PDF because of the reason: ",e);
		}  
		return inputStream;
	}
	
	/**
	 * convertRBCImageToPDF method is used for 
	 * @param imageFilePath String
	 * @return InputStream
	 */
	public InputStream convertRBCImageToPDF(String imageFilePath){
		int startByteRange;
		int rangeLength;
		boolean isImageConvertedToPDF = false;
		InputStream inputStream = null;
		String imageFileLocation = null;
		
		String[] imageOffsetLengths = null;
		byte[] imageByteArray = null;
		byte[] imageBytesToBeProcessed = null;
		
		RandomAccessFile imageFile = null;
		
		Image image = null;
		
        try {
        	
        	log.info("Inmage54 to Read method :: convertRBCImageToPDF");
        	
           	imageFileLocation = imageFilePath.substring(0,imageFilePath.indexOf(Constants.CSV_VALUE_SEPARATOR));
        	imageFilePath = imageFilePath.replace(imageFileLocation+Constants.CSV_VALUE_SEPARATOR, "");
        	
        	imageOffsetLengths = imageFilePath.split(Constants.RBC_CONS_OFFSETDATA_ENDCHAR+Constants.RBC_CONS_OFFSETDATA_SEPERATOR);
        
        	imageFile = new RandomAccessFile(imageFileLocation, "r");
        	imageByteArray = new byte[(int)imageFile.length()];
        	imageFile.read(imageByteArray);
        	
        	for(String currentImageOffsetLength : imageOffsetLengths){
        	 
        		log.info("Inmage64 to Read method :: convertRBCImageToPDF");
        		
        	 	currentImageOffsetLength = currentImageOffsetLength.replace(Constants.RBC_CONS_OFFSETDATA_STARTCHAR,"");
        		currentImageOffsetLength = currentImageOffsetLength.replace(Constants.RBC_CONS_OFFSETDATA_ENDCHAR,"");
        		
        		startByteRange = Integer.parseInt(currentImageOffsetLength.split(Constants.CSV_VALUE_SEPARATOR)[0]);
        		rangeLength = Integer.parseInt(currentImageOffsetLength.split(Constants.CSV_VALUE_SEPARATOR)[1]);
        		
        		imageBytesToBeProcessed = copyOfRange(imageByteArray, startByteRange, startByteRange+rangeLength);
        		image = Image.getInstance(imageBytesToBeProcessed);
        		isImageConvertedToPDF = addImageToDocument(image, isScalingRequired);
        		if(!isImageConvertedToPDF){
        			log.info("Inmage65 to Read method :: convertRBCImageToPDF");
        			break;
        		}
        	}
        	
        	if(isImageConvertedToPDF){
	        	document.close();
	        	if(byteArrayOutputStream.size()>0){
	        		log.info("Inmage70 to Read method :: convertRBCImageToPDF");
	        		inputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
	        	} else{
	        		return null;
	        	}
	        } else{
	        	log.info("Inmage70 to Read method :: convertRBCImageToPDF");
	        	return inputStream;
	        }
			
		} catch (Exception exception) {
			log.error("Error while converting image to PDF because of the reason: ",exception);
			exception.printStackTrace();
		}  
		return inputStream;
	}
	
	/**
	 * copyOfRange method used for copying the range of bytes into sub array
	 * 
	 * @param original byte[]
	 * @param from int
	 * @param to int
	 * @return byte[]
	 */
	public static byte[] copyOfRange(byte[] original, int from, int to) {
	    int newLength = to - from;
	    log.info("Inmage70 to Read method :: copyOfRange");
	    if (newLength < 0)
	        throw new IllegalArgumentException(from + " > " + to);
	    byte[] copy = new byte[newLength];
	    System.arraycopy(original, from, copy, 0,
	                     Math.min(original.length - from, newLength));
	    log.info("Inmage70 to Read method :: copyOfRange");
	    return copy;
	}
	
}
