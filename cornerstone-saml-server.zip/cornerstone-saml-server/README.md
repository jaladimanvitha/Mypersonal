# saml-jwt-sample

This repo hosts a sample of SAML2.0 WEBSSO configuration with JWT supports for mobile app.

This sample mainly relies on Spring Boot and Java-based Spring Security Saml 2.0 configuration.

The JWT part relies on nimbus jose  jwt which provides a nice all-in-one library for JWT
and JWE (Encrypted JWT) even if JWE is not covered here.
