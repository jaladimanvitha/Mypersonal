package com.ge.capital.dms.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;

import com.ge.capital.dms.dao.DocumentServiceDAO;

@Component
public class DocumentService {

	@Autowired
	DocumentServiceDAO documentServiceDAO;
	
	@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
	public HashMap<String, String> getDocumentProperties(String docType, String documentId) {
		System.out.println("Entering DocumentService in Service...");

		return documentServiceDAO.getDocumentProperties(docType, documentId);

	}
	
	public void deleteDoc(String docId, String docType) {
		System.out.println(docId);
		System.out.println(docType);
		documentServiceDAO.deleteDoc(docId,docType);
	}
	
	public void updateAuditInfo(String docId, String event, String docType, String loggedinUser, String status,
			String message) {
		// TODO Auto-generated method stub
		documentServiceDAO.updateAuditInfo(docId, event, docType, loggedinUser, status, message);
	}
}
