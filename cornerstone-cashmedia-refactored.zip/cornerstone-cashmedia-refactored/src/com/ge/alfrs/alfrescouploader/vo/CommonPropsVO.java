package com.ge.alfrs.alfrescouploader.vo;

import java.util.Date;

/**
 * This Bean is used to set the Property name and Property Values.
 * @author  mahindraSatyam, VS60636
 */
public class CommonPropsVO {

	
	private String propName;	
	private String proptype;	
	private String propValue;
	private Date propValue_Date;
	private boolean isMultiValued;

	/**
	 * @return
	 */
	public String getPropName() {
		return propName;
	}

	/**
	 * @param propName
	 */
	public void setPropName(String propName) {
		this.propName = propName;
	}

	/**
	 * @return
	 */
	public String getProptype() {
		return proptype;
	}

	/**
	 * @param proptype
	 */
	public void setProptype(String proptype) {
		this.proptype = proptype;
	}

	/**
	 * @return
	 */
	public String getPropValue() {
		return propValue;
	}
	
	/**
	 * @param propValue
	 */
	public void setPropValue(String propValue) {
		this.propValue = propValue;
	}
	
	public void setPropValue(Date propValue_Date) {
		this.propValue_Date = propValue_Date;
	}
	
	/**
	 * @return
	 */
	public Date getPropValue_Date(){
		return propValue_Date;
	}

	/**
	 * @return
	 */
	public boolean isMultiValued() {
		return isMultiValued;
	}

	/**
	 * @param isMultiValued
	 */
	public void setMultiValued(boolean isMultiValued) {
		this.isMultiValued = isMultiValued;
	}

}
