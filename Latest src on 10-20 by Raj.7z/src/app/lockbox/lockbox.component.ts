import { ImageTypeDropDown } from '../_models/ImageTypeDropDown';
import { Component, OnInit } from '@angular/core';
import { LockboxModel } from '../_models/LockboxModel';
import { MetadataModel } from '../_models/MetadataModel';
import { SearchDetails } from '../_models';
import { SearchService, InvoiceService } from '../_services';
import { LockboxDetails } from '../_models/LockBoxDetails';
import { LockboxNumDropDown } from '../_models/LockboxNumDropDown';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from '../_services/dateformat';

@Component({
  selector: 'app-lockbox',
  templateUrl: './lockbox.component.html',
  styleUrls: ['./lockbox.component.css'],
  providers: [
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
  ]
})
export class LockboxComponent implements OnInit {

  imageType: LockboxModel = new LockboxModel();

  image1: ImageTypeDropDown[] = [
    { id: 0, name: 'Check Image' },
    { id: 1, name: 'Envelope' },
    { id: 2, name: 'Remittance' },
  ];

  lockboxNum: LockboxNumDropDown[] = [
    { id: 0, name: 'PGH-641419' },
    { id: 1, name: 'PGH-630137' },
    { id: 2, name: 'T09498C' },
  ];

  public searchData: Array<object> = [];
  submitted = false;
  searchModel: LockboxDetails = new LockboxDetails();
  lockboxModel: LockboxModel = new LockboxModel();

  constructor(private _invoiceService: InvoiceService) {
  }
  ngOnInit() {

  }

  public getSearchData() {

    this.searchModel.metadata = this.lockboxModel;
    this._invoiceService.searchLockbox(this.searchModel).subscribe((data: Array<object>) => {
      this.searchData = data['metadataList'];
      console.log('entered');
      console.log(this.searchData);

    });
  }
  onSubmit() {
    this.getSearchData();
    document.getElementById('displaytable').style.display = 'inline-table';
    return true;
  }

}
