package com.ge.alfrs.cashmedia.boadatatransformer.constants;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
* The Messages Class will load the property file for BOA Bank
* 
* @author  PadmaKiran Vajjala
* @version 1.0
* @since   2017-04-31 
*/

public class Messages {

	private static final String BUNDLE_NAME = "config/BOADataTransformerUtil";
	private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle
			.getBundle(BUNDLE_NAME);

/**
* This method will find the property value for the given key.
* @param key.
* @return String.
*/
	
	public static String getString(String key) {
		try {
			return RESOURCE_BUNDLE.getString(key);
		} catch (MissingResourceException e) {
			return '!' + key + '!';
		}
	}
}
