package fr.sle.controllers;

import org.joda.time.DateTime;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.saml.SAMLCredential;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import fr.sle.config.SecurityConstant;
import fr.sle.dto.ApiToken;

/**
 * @author slemoine
 */
@CrossOrigin(origins = "*",exposedHeaders = "usersso")
@RestController
@RequestMapping("/auth")
public class AuthController {

    @GetMapping("/token")
    public ResponseEntity<ApiToken> token() throws JOSEException {

    	System.out.println("Inside Auth Controller###");
        final DateTime dateTime = DateTime.now();
        ResponseEntity<ApiToken> token = null;
        try {
	        //build claims
	        JWTClaimsSet.Builder jwtClaimsSetBuilder = new JWTClaimsSet.Builder();
	        jwtClaimsSetBuilder.expirationTime(dateTime.plusMinutes(120).toDate());
	        jwtClaimsSetBuilder.claim("APP", "SAMPLE");
	
	        //signature
	        SignedJWT signedJWT = new SignedJWT(new JWSHeader(JWSAlgorithm.HS256), jwtClaimsSetBuilder.build());
	        signedJWT.sign(new MACSigner(SecurityConstant.JWT_SECRET));
	        HttpHeaders headers = new HttpHeaders();
	        
	        SAMLCredential credential = (SAMLCredential)SecurityContextHolder.getContext().getAuthentication().getCredentials();
	        System.out.println("User ID in AuthController:"+credential.getAttributeAsString("ssoid"));
	        
	        //headers.add("Access-Control-Allow-Origin", "http://g2422usdwgpa02v.logon.ds.ge.com:7070/*");
	        //headers.add("Access-Control-Allow-Origin", "http://commoncmsapp.dev.ge.com/*");
	        ////headers.add("Access-Control-Allow-Origin", "http://commoncmsapp.qa.ge.com/*");
	        //headers.add("Access-Control-Allow-Origin", "https://commoncmsapp-qa.sites.ge.com/*");
	        headers.add("Access-Control-Allow-Origin", "https://commoncmsapp-uat.sites.ge.com/*");
	        headers.add("usersso", credential.getAttributeAsString("ssoid"));
	        //headers.add("Access-Control-Allow-Origin", true);
	        token = new ResponseEntity<ApiToken>(new ApiToken(signedJWT.serialize()),headers,HttpStatus.OK); 
	        System.out.println("Token value without entity === "+signedJWT.serialize());
	        System.out.println("Token generated ==="+token.getBody().getToken());
	        
        }catch(Exception e) {
        	System.out.println("Error occured in the Auth controller xxxxx");
        	e.printStackTrace();
        }
        return token;
        //return new ApiToken(signedJWT.serialize());
    }
    
    
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurerAdapter() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
            	registry.addMapping("/**").allowedOrigins("*");
            }
        };
    }
    
}
