import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpportunityDocumentUploadComponent } from './opportunity-document-upload.component';

describe('OpportunityDocumentUploadComponent', () => {
  let component: OpportunityDocumentUploadComponent;
  let fixture: ComponentFixture<OpportunityDocumentUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpportunityDocumentUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpportunityDocumentUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
