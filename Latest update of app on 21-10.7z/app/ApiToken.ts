export interface ApiToken{
  token: string
}
