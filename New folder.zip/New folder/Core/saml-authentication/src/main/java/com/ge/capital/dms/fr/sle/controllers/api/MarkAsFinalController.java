package com.ge.capital.dms.fr.sle.controllers.api;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ge.capital.dms.api.MarkasfinalApi;
import com.ge.capital.dms.api.MarkasfinalApiController;
import com.ge.capital.dms.fr.sle.config.DecodeSSO;
import com.ge.capital.dms.model.MarkAsFinalIVO;
import com.ge.capital.dms.service.UpdateService;
import com.ge.capital.dms.utility.DmsUtilityConstants;
import com.ge.capital.dms.utility.DmsUtilityService;
import com.google.gson.Gson;

import io.swagger.annotations.ApiParam;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-08-14T22:22:38.380+05:30")

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/secure")
public class MarkAsFinalController implements MarkasfinalApi{
	
	@Autowired
	MarkAsFinalRestController markAsFinalRestController;
	
	@Autowired
	UpdateService updateService;
	
	@Autowired
	private DmsUtilityService dmsUtilityService;	
	
	@Autowired
	HttpServletRequest request;
	
	@Autowired
	DecodeSSO decodeSSO;
		
	private static final Logger log = LoggerFactory.getLogger(MarkasfinalApiController.class);
	
	
	@RequestMapping(value = "/markasfinal", method = RequestMethod.POST)
	@ResponseBody
	public Object markasfinalMetadataPost(
			@ApiParam(value = "", required = true) @Valid @RequestBody List<MarkAsFinalIVO> multipleMetadata, @RequestHeader HttpHeaders headers) {
		
		String URL_MarkasFinal_Update=null;
		boolean respflg = false;
		String respMsg = null;
		try
		{
			List<String> header = headers.get("Authorization");
			
			System.out.println("Header Info is " + header);
		
			String loggedinUser=decodeSSO.getDecodedSSO(request.getHeader("loggedinuser"));
			
			log.info(loggedinUser);
			
			log.info("Entered into markasfinal service...");
			RestTemplate restTemplate = new RestTemplate();
			
			Properties props = dmsUtilityService.loadPropertiesFile(DmsUtilityConstants.applicationConstantsResource);
	
			URL_MarkasFinal_Update = props.getProperty("updateMetadaUri");
			
			if(multipleMetadata.isEmpty())
			{
				try {
						respflg = false;
					log.info("metadata in updateService is empty...");	
					//return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
					//throw new Exception("metadata in UpdateService is empty");
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			else
			{
				for(Iterator<MarkAsFinalIVO> i = multipleMetadata.iterator(); i.hasNext(); ) {
					
					MarkAsFinalIVO metadata = i.next();				
		
					Map<String, String> inputMetadataMap = (Map<String, String>) metadata.getMetadata();
						
					Date commenceDate = new Date();
					Date newRetentionDate=getRetentionDate(commenceDate,10);
					
				    DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				    
				    inputMetadataMap.put("permName","Capital_ALF_HEF_FINAL_MANAGER");
					inputMetadataMap.put("docState","FINAL");
					inputMetadataMap.put("retentionDate",df.format(newRetentionDate));		
					inputMetadataMap.put("modifier", loggedinUser);
					inputMetadataMap.put("modifyDate", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
					markAsFinalRestController.markAsFinalUpdate(URL_MarkasFinal_Update, multipleMetadata);
					respflg = true;
					log.debug("Updated metadata for docid..."+inputMetadataMap.get("docId"));
				}
				//return new ResponseEntity<Integer>(HttpStatus.OK);
			}			
		
		} catch (Exception e) {
			respflg = false;
			log.error("Couldn't serialize response for content type application/json", e);
			//return new ResponseEntity<Integer>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		if (respflg == true)
			respMsg = "Updated successfully";
		else
			respMsg = "Something went wrong could not process 'Mark as Final'";
		
		Gson g = new Gson();
		String Jsonstr = g.toJson(respMsg);
		return Jsonstr;
	}

	private Date getRetentionDate(Date commenceDate, int years){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(commenceDate);
		calendar.add(Calendar.YEAR, years);
		return calendar.getTime();
	}

	@Override
	public ResponseEntity<Void> markasfinalMetadataPost(MarkAsFinalIVO metadata) {
		// TODO Auto-generated method stub
		return null;
	}

}
