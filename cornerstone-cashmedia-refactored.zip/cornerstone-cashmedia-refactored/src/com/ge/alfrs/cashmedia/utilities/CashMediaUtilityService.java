package com.ge.alfrs.cashmedia.utilities;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.StringPart;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.xml.sax.InputSource;

import com.ge.alfrs.alfrescouploader.constants.Constants;

import eu.medsea.mimeutil.MimeUtil;

/**
 * The CashMediaUtilityService program uploads the checkImages that are
 * converted to pdf documents into Alfresco Repository with the provided
 * metadata by invoking Restful service.
 *
 * @author PadmaKiran Vajjala
 * @version 1.0
 * @since 2017-05-06
 */

public class CashMediaUtilityService {

	private static int documentCnt = 0;
	private static int batchCnt = 1;
	private static String tmplbnchk = "";

	private static Logger log = Logger.getLogger(CashMediaUtilityService.class);

	public boolean alfrescoUpload(InputStream contentInputStream, String metaData, String fileNm, String lockBoxNo,
			String datevalue) throws IOException {

		File fileObj = null;
		boolean uploadStatus = false;
		try {
			fileObj = new File(fileNm);
			FileUtils.copyInputStreamToFile(contentInputStream, fileObj);
			/*
			 * String alfTicket = getAlfrescoTicket(Constants.ALF_TICKET_REST_URL);
			 * uploadStatus = uploadDocument(alfTicket, metaData, fileObj, lockBoxNo,
			 * datevalue);
			 */
			uploadStatus = uploadDocument(metaData, fileObj, lockBoxNo, datevalue);
			return uploadStatus;
		} catch (Exception ex) {
			log.error("Error occured while uploading the document to alfresco repository " + ex);
			return uploadStatus;
		} finally {
			contentInputStream.close();
			fileObj.delete();
		}
	}

	public boolean uploadDocument(String propertiesJson, File file, String lockBoxNo, String dateValue) {

		boolean uploadStatus = false;
		try {

			String boxUploadURL = Constants.BOX_UPLOAD_URL;
			String docType = "lockbox.cashmedia";
			// String folderPath = createFolderStructure(lockBoxNo, dateValue);
			PostMethod mPost = null;
			MimeUtil.registerMimeDetector("eu.medsea.mimeutil.detector.MagicMimeMimeDetector");
			String mimeType = MimeUtil.getMimeTypes(file).toString();

			Part[] parts = { new StringPart("docType", docType), new StringPart("uploadMetadata", propertiesJson),
					new FilePart("files", file.getName(), file, mimeType, null), };
			MultipartRequestEntity multipartRequestEntity = new MultipartRequestEntity(parts, new HttpMethodParams());
			HttpClient client = new HttpClient();
			mPost = new PostMethod(boxUploadURL);
			mPost.setRequestEntity(multipartRequestEntity);
			mPost.setRequestHeader("Authorization", "Basic YWRtaW46YWRtaW4=");
			//mPost.setRequestHeader("loggedinuser", "HEF_DMS_USER");
			mPost.setRequestHeader("loggedinuser", "NDQ0NDQ0NDQ0");
			int statusCode = client.executeMethod(mPost);
			log.info("Response Code from Alfresco:::" + statusCode);
			if (statusCode == 200)
				uploadStatus = true;

			String responseBody = mPost.getResponseBodyAsString();
			System.out.println("Response::: " + responseBody);
			return uploadStatus;

		} catch (Exception ex) {
			log.error("Exception occured in parsing:", ex);
			return uploadStatus;

		}
	}

	// Creates the document folder structure hierarchy
	public String createFolderStructure(String lockBoxNo, String dateValue) {

		String folderPath = null;
		int year = Calendar.getInstance().get(Calendar.YEAR);
		String month = new SimpleDateFormat("MMMM").format(new Date());
		String today = new SimpleDateFormat("ddMMyyyy").format(new Date());

		if (documentCnt >= 10) {
			batchCnt += 1;
			documentCnt = 0;
		}

		if (!tmplbnchk.equals(lockBoxNo))
			batchCnt = 1;

		if (dateValue != null) {
			folderPath = Constants.FOLDER_PATH + lockBoxNo + "/" + year + "/" + month + "/" + dateValue + "/" + "B"
					+ batchCnt;
		} else {
			folderPath = Constants.FOLDER_PATH + lockBoxNo + "/" + year + "/" + month + "/" + today + "/" + "B"
					+ batchCnt;
		}

		tmplbnchk = lockBoxNo;

		return folderPath;
	}

	// *******************-----------------------------------//
	// Box migration for cashmedia

}