export class EntityDropDown {

  public id: number;
  public name: string;
}
