package com.ge.capital.dms.fr.sle.controllers.api;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;

import java.net.Proxy.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.websocket.ClientEndpointConfig;
import javax.websocket.DeploymentException;
import javax.websocket.Endpoint;
import javax.websocket.Extension;
import javax.websocket.Session;
import javax.websocket.WebSocketContainer;

import org.apache.commons.lang.NullArgumentException;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.box.sdk.BoxAPIConnection;
import com.box.sdk.BoxAPIException;
import com.box.sdk.BoxFile;
import com.box.sdk.BoxFolder;
import com.box.sdk.BoxItem;
import com.box.sdk.BoxItem.Info;
import com.eclipsesource.json.JsonArray;
import com.eclipsesource.json.JsonObject;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.capital.dms.api.SearchApiController;
import com.ge.capital.dms.dao.DocumentServiceDAO;
import com.ge.capital.dms.entity.UserDetails;
import com.ge.capital.dms.fr.sle.config.DecodeSSO;
import com.ge.capital.dms.model.DocumentOVO;
import com.ge.capital.dms.model.FileMetadata;
import com.ge.capital.dms.repository.UploadContractRepository;
import com.ge.capital.dms.repository.UploadLOCRepository;
import com.ge.capital.dms.service.UpdateService;
import com.ge.capital.dms.utility.AkanaToken;
import com.ge.capital.dms.utility.CommonConstants;
import com.ge.capital.dms.utility.DmsUtilityConstants;
import com.ge.capital.dms.utility.DmsUtilityService;
import com.google.common.collect.Iterators;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * MultiFileUploadController is defined as REST Service which is used to upload
 * the content i.e single or multiple documents of any type into Ge-box server.
 * Along with the file content it updates the metadata of those uploaded
 * documents into the database.
 *
 * @author PadmaKiran Vajjala & Varun Abbireddy
 * @version 1.0
 * @since 2018-11-11
 */

@SessionAttributes("UserLoginDetails")
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/secure")
public class MultiFileUploadController {

	@Value("${upload.path}")
	private String UPLD_DIR;

	@Value("${upload.docstate.final}")
	private String UPLD_DOC_ST_FINAL;

	@Value("${upload.lockboxCashmedia}")
	private String UPLD_DOC_CASH;

	@Value("${upload.lockboxwires}")
	private String UPLD_DOC_WIRES;

	@Value("${upload.lockboxpnc}")
	private String UPLD_DOC_PNC;
	
	@Value("${upload.reportscash}")
	private String UPLD_DOC_CASH_REPORT;
	
	@Value("${upload.reportscheck}")
	private String UPLD_DOC_CHECK;
	
	@Value("${upload.docstate.default}")
	private String UPLD_DOC_ST_DEFAULT;

	@Value("${upload.max.file.count}")
	private String MAX_FILE_CNT;

	@Value("${upload.rootFolderId}")
	private String UPLD_RT_FLDR_ID;

	@Value("${upload.partyFolderId}")
	private String UPLD_PA_FLDR_ID;

	@Value("${upload.accountFolderId}")
	private String UPLD_ACC_FLDR_ID;

	@Value("${upload.opportunityFolderId}")
	private String UPLD_OPP_FLDR_ID;

	@Value("${upload.locFolderId}")
	private String UPLD_LOC_FLDR_ID;

	@Value("${upload.ctrtFolderId}")
	private String UPLD_CTRT_FLDR_ID;

	@Value("${upload.corptaxRootFolderId}")
	private String UPLD_CT_FLDR_ID;

	// Start - Mapping Corptax County Group keys to properties

	@Value("${upload.corptaxAKFolderId}")
	private String UPLD_CT_AK_FLDR_ID;

	@Value("${upload.corptaxALFolderId}")
	private String UPLD_CT_AL_FLDR_ID;

	@Value("${upload.corptaxALFolderId}")
	private String UPLD_CT_AR_FLDR_ID;

	@Value("${upload.corptaxAZFolderId}")
	private String UPLD_CT_AZ_FLDR_ID;

	@Value("${upload.corptaxCAFolderId}")
	private String UPLD_CT_CA_FLDR_ID;

	@Value("${upload.corptaxCOFolderId}")
	private String UPLD_CT_CO_FLDR_ID;

	@Value("${upload.corptaxCTFolderId}")
	private String UPLD_CT_CT_FLDR_ID;

	@Value("${upload.corptaxDCFolderId}")
	private String UPLD_CT_DC_FLDR_ID;

	@Value("${upload.corptaxFLFolderId}")
	private String UPLD_CT_FL_FLDR_ID;

	@Value("${upload.corptaxGAFolderId}")
	private String UPLD_CT_GA_FLDR_ID;

	@Value("${upload.corptaxHIFolderId}")
	private String UPLD_CT_HI_FLDR_ID;

	@Value("${upload.corptaxIAFolderId}")
	private String UPLD_CT_IA_FLDR_ID;

	@Value("${upload.corptaxIDFolderId}")
	private String UPLD_CT_ID_FLDR_ID;

	@Value("${upload.corptaxILFolderId}")
	private String UPLD_CT_IL_FLDR_ID;

	@Value("${upload.corptaxINFolderId}")
	private String UPLD_CT_IN_FLDR_ID;

	@Value("${upload.corptaxKSFolderId}")
	private String UPLD_CT_KS_FLDR_ID;

	@Value("${upload.corptaxKYFolderId}")
	private String UPLD_CT_KY_FLDR_ID;

	@Value("${upload.corptaxLAFolderId}")
	private String UPLD_CT_LA_FLDR_ID;

	@Value("${upload.corptaxMAFolderId}")
	private String UPLD_CT_MA_FLDR_ID;

	@Value("${upload.corptaxMDFolderId}")
	private String UPLD_CT_MD_FLDR_ID;

	@Value("${upload.corptaxMEFolderId}")
	private String UPLD_CT_ME_FLDR_ID;

	@Value("${upload.corptaxMIFolderId}")
	private String UPLD_CT_MI_FLDR_ID;

	@Value("${upload.corptaxMNFolderId}")
	private String UPLD_CT_MN_FLDR_ID;

	@Value("${upload.corptaxMOFolderId}")
	private String UPLD_CT_MO_FLDR_ID;

	@Value("${upload.corptaxMSFolderId}")
	private String UPLD_CT_MS_FLDR_ID;

	@Value("${upload.corptaxMTFolderId}")
	private String UPLD_CT_MT_FLDR_ID;

	@Value("${upload.corptaxNCFolderId}")
	private String UPLD_CT_NC_FLDR_ID;

	@Value("${upload.corptaxNDFolderId}")
	private String UPLD_CT_ND_FLDR_ID;

	@Value("${upload.corptaxNEFolderId}")
	private String UPLD_CT_NE_FLDR_ID;

	@Value("${upload.corptaxNHFolderId}")
	private String UPLD_CT_NH_FLDR_ID;

	@Value("${upload.corptaxNJFolderId}")
	private String UPLD_CT_NJ_FLDR_ID;

	@Value("${upload.corptaxNMFolderId}")
	private String UPLD_CT_NM_FLDR_ID;

	@Value("${upload.corptaxNVFolderId}")
	private String UPLD_CT_NV_FLDR_ID;

	@Value("${upload.corptaxNYFolderId}")
	private String UPLD_CT_NY_FLDR_ID;

	@Value("${upload.corptaxOHFolderId}")
	private String UPLD_CT_OH_FLDR_ID;

	@Value("${upload.corptaxOKFolderId}")
	private String UPLD_CT_OK_FLDR_ID;

	@Value("${upload.corptaxORFolderId}")
	private String UPLD_CT_OR_FLDR_ID;

	@Value("${upload.corptaxPAFolderId}")
	private String UPLD_CT_PA_FLDR_ID;

	@Value("${upload.corptaxRIFolderId}")
	private String UPLD_CT_RI_FLDR_ID;

	@Value("${upload.corptaxSCFolderId}")
	private String UPLD_CT_SC_FLDR_ID;

	@Value("${upload.corptaxSDFolderId}")
	private String UPLD_CT_SD_FLDR_ID;

	@Value("${upload.corptaxTNFolderId}")
	private String UPLD_CT_TN_FLDR_ID;

	@Value("${upload.corptaxTXFolderId}")
	private String UPLD_CT_TX_FLDR_ID;

	@Value("${upload.corptaxUTFolderId}")
	private String UPLD_CT_UT_FLDR_ID;

	@Value("${upload.corptaxVAFolderId}")
	private String UPLD_CT_VA_FLDR_ID;

	@Value("${upload.corptaxVTFolderId}")
	private String UPLD_CT_VT_FLDR_ID;

	@Value("${upload.corptaxWAFolderId}")
	private String UPLD_CT_WA_FLDR_ID;

	@Value("${upload.corptaxWIFolderId}")
	private String UPLD_CT_WI_FLDR_ID;

	@Value("${upload.corptaxWVFolderId}")
	private String UPLD_CT_WV_FLDR_ID;

	@Value("${upload.corptaxWYFolderId}")
	private String UPLD_CT_WY_FLDR_ID;

	// END - Mapping Corptax County Group keys to properties

	@Autowired
	private Environment env;

	@Autowired
	UpdateService updateService;

	@Autowired
	DmsUtilityService dmsUtilityService;

	@Autowired
	DocumentServiceDAO documentServiceDAO;

	@Autowired
	UploadContractRepository uploadContractRepository;

	@Autowired
	UploadLOCRepository uploadLOCRepository;

	@Autowired
	HttpSession session;

	@Autowired
	DecodeSSO decodeSSO;
	
	private static final Logger log = LoggerFactory.getLogger(MultiFileUploadController.class);

	@RequestMapping(value = "/uploadFiles", method = RequestMethod.POST)
	public Object handleFileUpload(HttpServletRequest request, @FormDataParam("files") MultipartFile[] files,
			@FormDataParam("docType") String docType, @FormDataParam("fileMetadata") FileMetadata fileMetadata) {
		// boolean respflg = false;
		String nodeId = "";
		String boxId;
		String respMsg = "";
		String Jsonstr = null;
		List<String> boxFileExistsList = new ArrayList<String>();
		List<String> failureFilesList = new ArrayList<String>();
		Map<String, String> uploadDataMap = new HashMap<String, String>();
		
		String loggedinUser = decodeSSO.getDecodedSSO(request.getHeader("loggedinuser"));
		Gson gson = null;
		log.info("Inside the MultiFile Upload Controller :" + docType + " " + fileMetadata);
		try {
			

			log.info(loggedinUser);

			// UserLoginDetails userloginDetails = (UserLoginDetails)
			// session.getAttribute("UserLoginDetails");
			System.out.println("Metadata : " + fileMetadata.getUploadMetadata());
			String[] updateMetadataStrArray = fileMetadata.getUploadMetadata().split("},");
			String[] updateMetadataStrArray1 = updateMetadataStrArray;
			for (int i = 0; i < updateMetadataStrArray.length - 1; i++) {
				updateMetadataStrArray[i] = updateMetadataStrArray[i] + "}";
			}
			JSONParser parser = new JSONParser();
			// START - Storing Upload Filemetadata Values into hashmap
			for (String keyValue : updateMetadataStrArray) {

				JSONObject json = (JSONObject) parser.parse(keyValue);
				for (Object key : json.keySet()) {

					String metaKey = (String) key;
					String metaValue = "";
					System.out.println("Key :" + metaKey);
					if (json.get(metaKey).getClass() == (java.lang.Long.class)) {
						metaValue = (String) json.get(metaKey).toString();
						System.out.println("Value :" + metaValue);
					} else {
						metaValue = (String) json.get(metaKey);
						System.out.println(metaValue);
					}
					log.info(metaKey + " " + metaValue);

					uploadDataMap.put(metaKey, metaValue);

				}
			}
			// END

			String entityTypeValue = null;

			Iterator it = uploadDataMap.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry metadataentry = (Map.Entry) it.next();

				String metakey = new String((metadataentry.getKey()).toString());

				if (metakey.equals("legalEntityType")) {
					entityTypeValue = metadataentry.getValue().toString();
				}
			}

			log.info("LEGAL ENTITY TYPE : " + entityTypeValue);

			Properties docIdprops = dmsUtilityService.loadPropertiesFile(DmsUtilityConstants.docIdMappingResource);

			if (files.length != 0) {
				AkanaToken akanaToken = dmsUtilityService.generateAkanaAccessToken();
				JSONObject boxTokenJSON = dmsUtilityService.generateBoxAccessToken(akanaToken.getAccess_token());
				String boxToken = boxTokenJSON.get("accessToken").toString();

				if (!boxToken.isEmpty()) {
					// box connectivity
					BoxAPIConnection api = new BoxAPIConnection(boxToken);
					java.net.Proxy proxy = new java.net.Proxy(Type.HTTP,
							new InetSocketAddress("PITC-Zscaler-Americas-Cincinnati3PR.proxy.corporate.ge.com", 80));
					api.setProxy(proxy);

					FileInputStream stream = null;
					String entityTypeNumBoxId = null;

					// START - Folder restructuring logic from here based on type of upload i.e.,
					// party, account, opportunity, etc.,
					if (docType != null && docType.equalsIgnoreCase("dealDoc")) {
						if (uploadDataMap.get("legalEntityType").equals("Party")) {

							/*
							 * BoxFolder.Info partyFolderInfo = parentFolder1.createFolder("Party10");
							 * entityTypeBoxId = partyFolderInfo.getID();
							 */

							/* BoxFolder partyFolder = new BoxFolder(api, entityTypeBoxId); */
							String subFolderName = null;
							boolean flag = false;
							boolean partyNumFolderExists = false;

							BoxFolder partyfolder = new BoxFolder(api, UPLD_PA_FLDR_ID);

							for (BoxItem.Info itemInfo : partyfolder) {
								if (flag == false) {
									if (itemInfo instanceof BoxFolder.Info) {
										partyNumFolderExists = true;
										subFolderName = (itemInfo.getName());
										BoxFolder.Info partyFolderInfo = (BoxFolder.Info) itemInfo;

										BoxFolder partyNumfolder = new BoxFolder(api, partyFolderInfo.getID());

										if (subFolderName.equals("PA_" + uploadDataMap.get("partyNumber"))) {
											entityTypeNumBoxId = partyNumfolder.getID();
											log.info("PartyNumberFolder BoxID is " + entityTypeNumBoxId);
											flag = true;
											break;
										} else {
											partyNumFolderExists = false;
										}

									}
								}
							}

							if (partyNumFolderExists == false) {
								BoxFolder partyFolder = new BoxFolder(api, partyfolder.getID());

								BoxFolder.Info partychildFolderInfo = partyFolder
										.createFolder("PA_" + uploadDataMap.get("partyNumber"));
								entityTypeNumBoxId = partychildFolderInfo.getID();
								log.info("PartyNumberFolder BoxID is " + entityTypeNumBoxId);
							}

						}

						if (uploadDataMap.get("legalEntityType").equals("Account")) {

							String subFolderName = null;
							boolean flag = false;
							boolean accNumFolderExists = false;

							BoxFolder accfolder = new BoxFolder(api, UPLD_ACC_FLDR_ID);

							for (BoxItem.Info itemInfo : accfolder) {
								if (flag == false) {
									if (itemInfo instanceof BoxFolder.Info) {
										accNumFolderExists = true;
										subFolderName = (itemInfo.getName());
										BoxFolder.Info partyFolderInfo = (BoxFolder.Info) itemInfo;

										BoxFolder partyNumfolder = new BoxFolder(api, partyFolderInfo.getID());

										if (subFolderName.equals("AC_" + uploadDataMap.get("sfdcAccountId"))) {
											entityTypeNumBoxId = partyNumfolder.getID();
											log.info("AccountNumberFolder BoxID is " + entityTypeNumBoxId);
											flag = true;
											break;
										} else {
											accNumFolderExists = false;
										}

									}
								}
							}

							if (accNumFolderExists == false) {
								BoxFolder accFolder = new BoxFolder(api, accfolder.getID());

								BoxFolder.Info accchildFolderInfo = accFolder
										.createFolder("AC_" + uploadDataMap.get("sfdcAccountId"));
								entityTypeNumBoxId = accchildFolderInfo.getID();
								log.info("AccountNumberFolder BoxID is " + entityTypeNumBoxId);
							}

						}

						if (uploadDataMap.get("legalEntityType").equals("Opportunity")) {

							String subFolderName = null;
							boolean flag = false;
							boolean oppNumFolderExists = false;

							BoxFolder oppfolder = new BoxFolder(api, UPLD_OPP_FLDR_ID);

							for (BoxItem.Info itemInfo : oppfolder) {
								if (flag == false) {
									if (itemInfo instanceof BoxFolder.Info) {
										oppNumFolderExists = true;
										subFolderName = (itemInfo.getName());
										BoxFolder.Info oppFolderInfo = (BoxFolder.Info) itemInfo;

										BoxFolder oppNumfolder = new BoxFolder(api, oppFolderInfo.getID());

										if (subFolderName.equals("OP_" + uploadDataMap.get("sfdcopportunityId"))) {
											entityTypeNumBoxId = oppNumfolder.getID();
											log.info("OpportunityNumberFolder BoxID is " + entityTypeNumBoxId);
											flag = true;
											break;
										} else {
											oppNumFolderExists = false;
										}

									}
								}
							}

							if (oppNumFolderExists == false) {
								BoxFolder oppFolder = new BoxFolder(api, oppfolder.getID());

								BoxFolder.Info oppChildFolderInfo = oppFolder
										.createFolder("OP_" + uploadDataMap.get("sfdcopportunityId"));
								entityTypeNumBoxId = oppChildFolderInfo.getID();
								log.info("OpportunityNumberFolder BoxID is " + entityTypeNumBoxId);
							}

						}

						if (uploadDataMap.get("legalEntityType").equals("LOC")) {
							if (uploadDataMap.get("sfdcopportunityId") != null
									|| uploadDataMap.get("sfdcopportunityId") != "") {
								// DB Logic for updating credit number and opportunity ID if provided
								uploadLOCRepository.updateLocOppotunityID(uploadDataMap.get("lineofcreditNumber"),
										uploadDataMap.get("sfdcopportunityId"));
							}

							String subFolderName = null;
							boolean flag = false;
							boolean locNumFolderExists = false;

							BoxFolder locfolder = new BoxFolder(api, UPLD_LOC_FLDR_ID);

							for (BoxItem.Info itemInfo : locfolder) {
								if (flag == false) {
									if (itemInfo instanceof BoxFolder.Info) {
										locNumFolderExists = true;
										subFolderName = (itemInfo.getName());
										BoxFolder.Info locFolderInfo = (BoxFolder.Info) itemInfo;

										BoxFolder locNumfolder = new BoxFolder(api, locFolderInfo.getID());

										if (subFolderName.equals("LC_" + uploadDataMap.get("lineofcreditNumber"))) {
											entityTypeNumBoxId = locNumfolder.getID();
											log.info("LOCNumberFolder BoxID is " + entityTypeNumBoxId);
											flag = true;
											break;
										} else {
											locNumFolderExists = false;
										}

									}
								}
							}

							if (locNumFolderExists == false) {
								BoxFolder locFolder = new BoxFolder(api, locfolder.getID());

								BoxFolder.Info locChildFolderInfo = locFolder
										.createFolder("LC_" + uploadDataMap.get("lineofcreditNumber"));
								entityTypeNumBoxId = locChildFolderInfo.getID();
								log.info("LOCNumberFolder BoxID is " + entityTypeNumBoxId);
							}

						}

						if (uploadDataMap.get("legalEntityType").equalsIgnoreCase("Contract")) {

							String subFolderName = null;
							boolean flag = false;
							boolean ctrtNumFolderExists = false;

							BoxFolder ctrtfolder = new BoxFolder(api, UPLD_CTRT_FLDR_ID);

							for (BoxItem.Info itemInfo : ctrtfolder) {
								if (flag == false) {
									if (itemInfo instanceof BoxFolder.Info) {
										ctrtNumFolderExists = true;
										subFolderName = (itemInfo.getName());
										BoxFolder.Info ctrtFolderInfo = (BoxFolder.Info) itemInfo;

										BoxFolder ctrtNumfolder = new BoxFolder(api, ctrtFolderInfo.getID());

										if (subFolderName.equals("CT_" + uploadDataMap.get("lwSeqNumber"))) {
											entityTypeNumBoxId = ctrtNumfolder.getID();
											log.info("ContractNumberFolder BoxID is " + entityTypeNumBoxId);
											flag = true;
											break;
										} else {
											ctrtNumFolderExists = false;
										}

									}
								}
							}

							if (ctrtNumFolderExists == false) {
								BoxFolder partyFolder = new BoxFolder(api, ctrtfolder.getID());

								BoxFolder.Info partychildFolderInfo = partyFolder
										.createFolder("CT_" + uploadDataMap.get("lwSeqNumber"));
								entityTypeNumBoxId = partychildFolderInfo.getID();
								log.info("ContractNumberFolder is " + entityTypeNumBoxId);
							}

						}
					}
					log.info("DocType :" + docType);
					if (docType != null && docType.equals("lockbox.cashmedia")) {
						log.info("Inside Locbox Block");
						BoxFolder lockBoxFolder = new BoxFolder(api, UPLD_DOC_CASH);

						BoxFolder oppFolder = new BoxFolder(api, lockBoxFolder.getID());
						String folderName = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
						String finalFolderName = "";
						for (Info bx : oppFolder.getChildren()) {
							if (bx.getName().equalsIgnoreCase(folderName)) {
								finalFolderName = bx.getID();
							}
						}
						if (finalFolderName == "") {
							BoxFolder.Info oppChildFolderInfo = oppFolder.createFolder(folderName);
							entityTypeNumBoxId = oppChildFolderInfo.getID();
						} else {
							entityTypeNumBoxId = finalFolderName;
						}
						log.info("Folder ID :" + entityTypeNumBoxId);
					}
					if (docType.equals("lockbox.wireslb") || docType.equals("lockbox.pnc")) {
						log.info("Inside CashArchival Block");
						if (docType.equals("lockbox.wireslb")) {
							BoxFolder wiresBoxFolder = new BoxFolder(api, UPLD_DOC_WIRES);
							BoxFolder oppFolder = new BoxFolder(api, wiresBoxFolder.getID());

							if (uploadDataMap.get("folderPath") != null) {
								String folderName = uploadDataMap.get("folderPath");
								String finalFolderName = "";
								for (Info bx : oppFolder.getChildren()) {
									if (bx.getName().equalsIgnoreCase(folderName)) {
										finalFolderName = bx.getID();
									}
								}
								if (finalFolderName == "") {
									BoxFolder.Info oppChildFolderInfo = oppFolder.createFolder(folderName);
									entityTypeNumBoxId = oppChildFolderInfo.getID();
								} else {
									entityTypeNumBoxId = finalFolderName;
								}
								log.info("Folder ID :" + entityTypeNumBoxId);
							} else {
								throw new NullArgumentException("folderPath");
							}

						}

						if (docType.equals("lockbox.pnc")) {
							BoxFolder pncBoxFolder = new BoxFolder(api, UPLD_DOC_PNC);
							BoxFolder oppFolder = new BoxFolder(api, pncBoxFolder.getID());
							
							if (uploadDataMap.get("folderPath") != null) {
								String folderName = uploadDataMap.get("folderPath");
								String finalFolderName = "";
								for (Info bx : oppFolder.getChildren()) {
									if (bx.getName().equalsIgnoreCase(folderName)) {
										finalFolderName = bx.getID();
									}
								}
								if (finalFolderName == "") {
									BoxFolder.Info oppChildFolderInfo = oppFolder.createFolder(folderName);
									entityTypeNumBoxId = oppChildFolderInfo.getID();
								} else {
									entityTypeNumBoxId = finalFolderName;
								}
								log.info("Folder ID :" + entityTypeNumBoxId);
							} else {
								throw new NullArgumentException("folderPath");
							}

						}

					}
					if (docType.equals("reports.cash") || docType.equals("reports.check")) {
						String id = "";
						if(docType.equals("reports.cash")) {
							id = UPLD_DOC_CASH_REPORT; 
						}
						else if(docType.equals("reports.check")) {
							id = UPLD_DOC_CHECK;
						}
						BoxFolder repportsBoxFolder = new BoxFolder(api, id);
						BoxFolder oppFolder = new BoxFolder(api, repportsBoxFolder.getID());
						
						if (uploadDataMap.get("folderPath") != null) {
							String[] folderName = uploadDataMap.get("folderPath").split("/");
							String finalFolderName = "";
							String finalFolderName1 = "";
							for (Info bx : oppFolder.getChildren()) {
								if (bx.getName().equalsIgnoreCase(folderName[0])) {
									finalFolderName = bx.getID();
								}
							}
							if(!finalFolderName.isEmpty()) {
								BoxFolder oppFolder1 = new BoxFolder(api, finalFolderName);
								for (Info bx : oppFolder1.getChildren()) {
									if (bx.getName().equalsIgnoreCase(folderName[1])) {
										finalFolderName1 = bx.getID();
									}
								}
								if(finalFolderName1.isEmpty()) {
									BoxFolder childFolder = new BoxFolder(api, finalFolderName);
									BoxFolder.Info childFolderInfo = childFolder.createFolder(folderName[1]);
									finalFolderName1 = childFolderInfo.getID();
								}
								entityTypeNumBoxId = finalFolderName1;
							}
							if (finalFolderName == "") {
								BoxFolder.Info oppChildFolderInfo = oppFolder.createFolder(folderName[0]);
								BoxFolder childFolder = new BoxFolder(api, oppChildFolderInfo.getID());
								BoxFolder.Info childFolderInfo = childFolder.createFolder(folderName[1]);
								entityTypeNumBoxId = childFolderInfo.getID();
								
							}
							log.info("Folder ID :" + entityTypeNumBoxId);
						} else {
							throw new NullArgumentException("folderPath");
						}
					}
					// if (uploadDataMap.get("legalEntityType").equals("corptax"))
					if (docType != null && docType.equals("corptax")) {
						String subFolderName = null;
						boolean flag = false;
						boolean countynameFolderExists = false;

						BoxFolder copTaxfolder = getCorpTaxCGUploadFolder(uploadDataMap, api);

						for (BoxItem.Info itemInfo : copTaxfolder) {

							if (flag == false) {
								if (itemInfo instanceof BoxFolder.Info) {
									countynameFolderExists = true;
									subFolderName = (itemInfo.getName());
									BoxFolder.Info oppFolderInfo = (BoxFolder.Info) itemInfo;

									BoxFolder oppNumfolder = new BoxFolder(api, oppFolderInfo.getID());

									if (subFolderName.equals(uploadDataMap.get("ctCountyName"))) {
										entityTypeNumBoxId = oppNumfolder.getID();
										log.info("Countyname BoxID is " + entityTypeNumBoxId);
										flag = true;
										break;
									} else {
										countynameFolderExists = false;
									}

								}
							}
						}

						if (countynameFolderExists == false) {
							BoxFolder oppFolder = new BoxFolder(api, copTaxfolder.getID());
							BoxFolder.Info oppChildFolderInfo = oppFolder
									.createFolder(uploadDataMap.get("ctCountyName"));
							entityTypeNumBoxId = oppChildFolderInfo.getID();
							log.info("Countyname BoxID is " + entityTypeNumBoxId);
						}

					}
					// END
					int indx = 0;
					String entityID = entityTypeNumBoxId;

					for (MultipartFile multipartFile : files) {

						boxId = null;
						File file = null;
						try {
							// Folder Nesting..
							int subFolderNum = 0;
							boolean flag = false;
							boolean subFolderExists = false;
							String subFolderId = null;
							BoxFolder fldr = new BoxFolder(api, entityID);

							for (BoxItem.Info itemInfo : fldr) {
								if (flag == false) {
									if (itemInfo instanceof BoxFolder.Info) {
										subFolderExists = true;
										subFolderNum = Integer.parseInt(itemInfo.getName());
										BoxFolder.Info folderInfo = (BoxFolder.Info) itemInfo;
										// Do something with the folder.
										BoxFolder folder = new BoxFolder(api, folderInfo.getID());
										int count = Iterators.size(folder.iterator());
										log.info("MAX_FILE_CNT: " + MAX_FILE_CNT);
										log.info("No of files: " + count);
										if (count >= Integer.parseInt(MAX_FILE_CNT)) {
											flag = false;
											subFolderExists = false;
										} else {
											subFolderId = folder.getID();
											flag = true;
											break;
										}

									}
								}
							}

							if (subFolderExists == false) {
								if (!(docType.contains("lockbox") || docType.contains("reports")) ) {
								BoxFolder parentFolder = new BoxFolder(api, fldr.getID());
								subFolderNum += 1;
								BoxFolder.Info childFolderInfo = parentFolder
										.createFolder(Integer.toString(subFolderNum));
								subFolderId = childFolderInfo.getID();
								}
							}

							if (docType.contains("reports") || docType.equalsIgnoreCase("lockbox.cashmedia") || docType.equalsIgnoreCase("lockbox.wireslb") || docType.equalsIgnoreCase("lockbox.pnc")) {
								log.info("SubFolder ID has been set to Entity ID: " + subFolderId);
								subFolderId = entityID;
							}

							BoxFolder uploadFolder = new BoxFolder(api, subFolderId);
							log.info(multipartFile.getOriginalFilename() + ": " + multipartFile.getContentType());
							//file = new File(UPLD_DIR + "\\" + multipartFile.getOriginalFilename());

							file = new File(UPLD_DIR + "\\"
									+ java.nio.file.Paths.get(multipartFile.getOriginalFilename()).getFileName());

							multipartFile.transferTo(file);
							stream = new FileInputStream(file);
							log.info("Upload Directory :" + UPLD_DIR);
							log.info(api + " : Api With boxtoken : " + boxToken);
							BoxFile.Info newFileInfo = uploadFolder.uploadFile(stream,
									multipartFile.getOriginalFilename());
							boxId = newFileInfo.getID();
							
							nodeId = newFileInfo.getID();
							log.info(newFileInfo.getName() + ":uploaded to box successfully...");

							Map<String, String> documentDetails = new HashMap<String, String>();
							// update specific docType metadata in commonDoc
							Map<String, String> metadataMap = new HashMap<String, String>();
							ObjectMapper mapperMetadata = new ObjectMapper();
							metadataMap = mapperMetadata.readValue(updateMetadataStrArray[indx].concat("}"),
									new TypeReference<HashMap<String, String>>() {
									});

							documentDetails.put("docId", boxId);
							documentDetails.put("docVersionId", newFileInfo.getVersion().getVersionID());
							documentDetails.put("docName", newFileInfo.getName());
							documentDetails.put("docTitle", newFileInfo.getName());
							if (docType.equals("lockbox.wireslb")) {
								documentDetails.put("docType", "lockbox.wireslb");
								documentDetails.put("isMigrated", "");
								documentDetails.put("docSource", "");
								documentDetails.put("retentionDate", "");
							} else if(docType.equals("lockbox.pnc")) {
								documentDetails.put("docType", "lockbox.pnc");
								documentDetails.put("isMigrated", "");
								documentDetails.put("docSource", "");
								documentDetails.put("retentionDate", "");
							} else if (docType.equals("lockbox.cashmedia")) {
								System.out.println("Inside the Lockbox");
								documentDetails.put("docType", "lockbox");
								documentDetails.put("isMigrated", "");
								documentDetails.put("docSource", "");
								documentDetails.put("retentionDate", "");
								System.out.println("Document Details :" + documentDetails.toString());
							} else if (docType.equals("reports.cash") || docType.equals("reports.check")) {
								documentDetails.put("docType", "reports");
								documentDetails.put("isMigrated",
										metadataMap.get(docIdprops.getProperty(docType + ".isMigrated")));
								documentDetails.put("docSource",
										metadataMap.get(docIdprops.getProperty(docType + ".docSource")));
								documentDetails.put("retentionDate", metadataMap
										.get(docIdprops.getProperty(docType + ".retentionDate")).replace('T', ' '));
							} else {
								documentDetails.put("docType", docType);
								documentDetails.put("isMigrated", "");
								documentDetails.put("docSource", uploadDataMap.get("sourceSystem"));
								documentDetails.put("retentionDate", "");
							}

							documentDetails.put("mimeType", multipartFile.getContentType());
							documentDetails.put("permName", "");
							documentDetails.put("realmName", "");

							if (loggedinUser != null)
								documentDetails.put("ownerName", loggedinUser);
							else
								documentDetails.put("ownerName", "HEF_DMS_USER");

							documentDetails.put("createDate",
									(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(newFileInfo.getCreatedAt())));

							if (loggedinUser != null)
								documentDetails.put("creator", loggedinUser);
							else
								documentDetails.put("creator", "HEF_DMS_USER");

							documentDetails.put("modifyDate",
									(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(newFileInfo.getModifiedAt())));

							if (loggedinUser != null)
								documentDetails.put("modifier", loggedinUser);
							else
								documentDetails.put("modifier", "HEF_DMS_USER");

							documentDetails.put("isDeleted", "");
							documentDetails.put("isCurrent", "");
							documentDetails.put("versionNum", newFileInfo.getVersionNumber());
							if (uploadDataMap.get("legalEntityType") != null) {
								if (uploadDataMap.get("legalEntityType").equalsIgnoreCase("Contract")) {
									String ctrtNumber = uploadDataMap.get("lwSeqNumber");

									// contract number lookup for checking contract commencement
									Integer uploadctrtCount = uploadContractRepository.getCount(ctrtNumber);
									System.out.println("The Contract Number is :" + ctrtNumber);
									System.out.println("The count is :"+ uploadctrtCount);
									if (uploadctrtCount > 0) {
										documentDetails.put("docState", UPLD_DOC_ST_FINAL);
									} else
										documentDetails.put("docState", UPLD_DOC_ST_DEFAULT);
								}
								if (!(uploadDataMap.get("legalEntityType").equalsIgnoreCase("Contract"))) {
									documentDetails.put("docState", UPLD_DOC_ST_DEFAULT);
								}
								documentDetails.put("contentRef", "");
								documentDetails.put("isLocked", "");
								documentDetails.put("folderRef", "");
							}

							updateService.updateDocumentMetadata(docType, documentDetails, loggedinUser);

							// metadata update for Party doc upload
							if (docType.equals(docIdprops.getProperty(docType + ".multi.upload"))) {
								String tableName = docIdprops.getProperty(docType + ".multi.upload.table");
								Map<String, String> updateParams = new HashMap<String, String>();
								ObjectMapper mapper = new ObjectMapper();

								// convert JSON string to Map
								updateParams = mapper.readValue(updateMetadataStrArray1[indx].concat("}"),
										new TypeReference<HashMap<String, String>>() {
										});
								updateParams.put("documentId", boxId);
								updateParams.entrySet().removeIf(entry -> "fileName".equalsIgnoreCase(entry.getKey()));

								// setting physicalStorageNotSent
								if (docType.equals("dealDoc")) {
									if (updateParams.get("physicalStorageStatus").equals("1"))
										updateParams.put("physicalStorageNotSent", "1");
									else if (updateParams.get("physicalStorageStatus").equals("0"))
										updateParams.put("physicalStorageNotSent", "0");

									updateParams.entrySet()
											.removeIf(entry -> "sourceSystem".equalsIgnoreCase(entry.getKey()));
								}

								if (docType.equals("corptax")) {
									updateParams.remove("legalEntityType");
									updateParams.remove("sourceSystem");
								}
								if (docType.equals("lockbox.cashmedia")) {
									updateParams.remove("legalEntityType");
									updateParams.remove("sourceSystem");
									if (updateParams.get("gecap_date_loaded") != null) {
										updateParams.put("gecap_date_loaded",
												updateParams.get("gecap_date_loaded").concat(" 00:00:00"));
									}
								}
								if (docType.equals("lockbox.pnc")) {
									updateParams.remove("legalEntityType");
									updateParams.remove("sourceSystem");
									if (updateParams.get("folderPath") != null) {
										updateParams.put("date_loaded",
												updateParams.get("folderPath").concat(" 00:00:00"));
									}
									updateParams.put("cash_archival_type","PNC Lockbox");
									updateParams.remove("folderPath");
									updateParams.remove("docType");
									
								}
								if (docType.equals("lockbox.wireslb")) {
									updateParams.remove("legalEntityType");
									updateParams.remove("sourceSystem");
									if (updateParams.get("folderPath") != null) {
										updateParams.put("date_loaded",
												updateParams.get("folderPath").concat(" 00:00:00"));
									}
									updateParams.put("cash_archival_type","Wires LB");
									updateParams.remove("folderPath");
									updateParams.remove("docType");
								}
								if (docType.equals("reports.cash") || docType.equals("reports.check")) {
									updateParams.put("gecap_reportRunDate",
											updateParams.get("gecap_reportRunDate").replace('T', ' '));
									updateParams.put("gecap_reportDate",
											updateParams.get("gecap_reportDate").replace('T', ' '));
									updateParams.entrySet().removeIf(entry -> docIdprops
											.getProperty(docType + ".isMigrated").equalsIgnoreCase(entry.getKey()));
									updateParams.entrySet().removeIf(entry -> docIdprops
											.getProperty(docType + ".docSource").equalsIgnoreCase(entry.getKey()));
									updateParams.entrySet().removeIf(entry -> docIdprops
											.getProperty(docType + ".retentionDate").equalsIgnoreCase(entry.getKey()));
									updateParams.remove("legalEntityType");
									updateParams.remove("folderPath");
								}
								updateService.updateDocumentTypeMetadata(docType, tableName, updateParams);
								indx += 1;
							}

						} catch (BoxAPIException boxAPIException) {
							if (boxAPIException.getResponseCode() == CommonConstants.FILE_ALREADY_EXISTS)
								boxFileExistsList.add(multipartFile.getOriginalFilename());
							else
							failureFilesList.add(multipartFile.getOriginalFilename());
							System.out.println(boxAPIException.getMessage());
							boxAPIException.printStackTrace();
							log.info("Inside BoxAPIException catch block");
						} catch (NullPointerException e) {
							System.out.println("Inside NullPointer Catch block");
							e.printStackTrace();
							failureFilesList.add(multipartFile.getOriginalFilename());
							/*
							 * BoxFile boxFile = new BoxFile(api, boxId); boxFile.delete();
							 * documentServiceDAO.deleteDoc(boxId, docType);
							 */
							e.printStackTrace();
						} catch (Exception e) {
							e.printStackTrace();
						} finally {
							try {
								if (stream != null)
									stream.close();
								if (file != null)
									file.delete();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}

					}

				}

			}
			if(docType != null ) {
				if(docType.equalsIgnoreCase("lockbox.pnc") || docType.equalsIgnoreCase("lockbox.wireslb") || docType.equalsIgnoreCase("reports.cash") || docType.equalsIgnoreCase("reports.check")) {
					Map<String, String> statusObj = new HashMap<String, String>();
					System.out.println("Result JSON Block");
					if(nodeId == "") {
						statusObj.put("code","400");
						statusObj.put("nodeId", nodeId);
						statusObj.put("message", "Unable to upload the document to Box");
					} else {
						statusObj.put("code","200");
						statusObj.put("nodeId", nodeId);
						statusObj.put("message", "Document uploaded to box Successfully");
					}
					JSONObject metaJson = new JSONObject(statusObj);
					System.out.println(metaJson);
					return metaJson.toString();
				}
			}
		}
		catch (BoxAPIException boxAPIException) {
			System.out.println("Error Uploading to Box");
			if (boxAPIException.getResponseCode() == CommonConstants.UNAUTHORIZED) {
				
				boxAPIException.printStackTrace();
			}
		} catch (NullPointerException ex) {
			// TODO: handle exception
			System.out.println("Null Pointer Exception");
			failureFilesList.add(files[0].getOriginalFilename());
			ex.printStackTrace();
		} catch (Exception ex) {
			// TODO: handle exception
			System.out.println("Genric Exception Block");
			failureFilesList.add(files[0].getOriginalFilename());
			ex.printStackTrace();
		}

		if (failureFilesList.isEmpty() && boxFileExistsList.isEmpty())
			respMsg = "All files are uploaded to box successfully";

		if (!failureFilesList.isEmpty()) {
			respMsg = "Something went wrong could not upload the files: ";
			log.info("Failed to upload due to API Exception");
			for (String fileFailed : failureFilesList)
				respMsg += "'" + fileFailed + "', ";
		}

		if (!boxFileExistsList.isEmpty()) {
			respMsg += "Files ";
			for (String bfeL : boxFileExistsList)
				respMsg += "'" + bfeL + "', ";
			respMsg += "have already been uploaded to this location.";
		}
		
		Gson g = new Gson();
		Jsonstr = g.toJson(respMsg);
		log.info(Jsonstr);
		return Jsonstr;

	}

	public BoxFolder getCorpTaxCGUploadFolder(Map<String, String> uploadDataMap, BoxAPIConnection api) {

		BoxFolder copTaxfolder = null;

		if (uploadDataMap.get("ctState").equals("AK")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_AK_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("AL")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_AL_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("AR")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_AR_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("AZ")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_AZ_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("CA")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_CA_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("CO")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_CO_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("CT")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_CT_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("DC")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_DC_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("FL")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_FL_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("GA")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_GA_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("HI")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_HI_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("IA")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_IA_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("ID")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_ID_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("IL")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_IL_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("IN")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_IN_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("KS")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_KS_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("KY")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_KY_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("LA")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_LA_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("MA")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_MA_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("MD")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_MD_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("ME")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_ME_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("MI")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_MI_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("MN")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_MN_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("MO")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_MO_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("MS")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_MS_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("MT")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_MT_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("NC")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_NC_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("ND")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_ND_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("NE")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_NE_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("NH")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_NH_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("NJ")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_NJ_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("NM")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_NM_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("NV")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_NV_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("NY")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_NY_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("OH")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_OH_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("OK")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_OK_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("OR")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_OR_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("PA")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_PA_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("RI")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_RI_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("SC")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_SC_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("SD")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_SD_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("TN")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_TN_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("TX")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_TX_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("UT")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_UT_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("VA")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_VA_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("VT")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_VT_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("WA")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_WA_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("WI")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_WI_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("WV")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_WV_FLDR_ID);
		}

		if (uploadDataMap.get("ctState").equals("WY")) {
			copTaxfolder = new BoxFolder(api, UPLD_CT_WY_FLDR_ID);
		}

		return copTaxfolder;
	}
}
