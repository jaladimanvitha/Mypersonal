

export class UserData{
    constructor(
      public name: string,
      public adminValue: boolean
    ){}
  }