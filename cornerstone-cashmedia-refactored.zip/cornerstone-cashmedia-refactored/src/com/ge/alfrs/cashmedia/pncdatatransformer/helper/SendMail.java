package com.ge.alfrs.cashmedia.pncdatatransformer.helper;

import java.util.Date;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.apache.log4j.Logger;

/**
 * SendMail class is used to send the mail.
 * 
 * @author CP97964
 * 
 */

public class SendMail {

	
	private static Logger log = Logger.getLogger(SendMail.class);
	
	public void sendMail(String subject,String message,String toAddress, String fromAddress, String smtpHost) throws Exception
    {
		Transport bus=null;
          try{
        
               Properties mailProps=new Properties();
               mailProps.put("mail.smtp.host",smtpHost);
               mailProps.put("mail.debug", "false");
               Session session = Session.getInstance(mailProps);
                bus = session.getTransport("smtp");
               bus.connect();
               MimeMessage msg = new MimeMessage(session);
               msg.setFrom(new InternetAddress(fromAddress));
               InternetAddress address[]= InternetAddress.parse(toAddress);
               msg.setRecipients(Message.RecipientType.TO, address);
               msg.setSubject(subject);
               msg.setSentDate(new Date());
               msg.setText(message);
               msg.setContent(message, "text/plain");
               msg.saveChanges();
               bus.sendMessage(msg, address);
               bus.close();
          }catch(Exception e){
        	  
        	  log.info("Exception while sending email ",e);
        

          }   
          finally
          {
        	  if (bus!=null)
        	  {
        		  bus.close();
        	  }
          }

    }
}
