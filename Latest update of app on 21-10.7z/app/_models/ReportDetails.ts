import { ReportModel } from '.';


export class ReportDetails {

    public docType = 'Gec';
    public reportModel: ReportModel;

}
