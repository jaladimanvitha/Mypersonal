export class SyndicationDropDown {

  public id: number;
  public name: string;
}
