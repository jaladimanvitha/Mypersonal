package com.ge.alfrs.alfrescouploader.helper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.ge.alfrs.alfrescouploader.constants.Constants;

/**
 * CSVReader class is used for reading CSV file
 * 
 * @author mahindraSatyam, VS60636
 */
public class CSVReader {

	private static Logger log = Logger.getLogger(CSVReader.class);

	/**
	 * readCSV method is used for reading the CSV File and creates a list with
	 * the data received from csvFilePath and returns the List contains CSV
	 * records this method takes CSV file path as the input parameter
	 * 
	 * @param String
	 *            csvFilePath
	 * @return List<Map<String, String>>
	 */
	public List<Map<String, String>> readCSV(String csvFilePath) {

		String csvHeaderColumns = null;
		String csvRecordString = null;

		BufferedReader csvFileBufferedReader = null;
		FileReader csvFileFileReader = null;
		List<Map<String, String>> csvFileRecordsList = null;
		Map<String, String> csvDataMap = null;

		try {
			csvFileRecordsList = new ArrayList<Map<String, String>>();
			csvFileFileReader = new FileReader(csvFilePath);
			csvFileBufferedReader = new BufferedReader(csvFileFileReader);
			csvHeaderColumns = csvFileBufferedReader.readLine();

			csvRecordString = csvFileBufferedReader.readLine();

			while (csvRecordString != null) {
				csvDataMap = getKeyPairData(csvHeaderColumns, csvRecordString);

				csvFileRecordsList.add(csvDataMap);

				csvRecordString = csvFileBufferedReader.readLine();

			}
		} catch (Exception exception) {
			log.error("Error while readin the CSV file data: ", exception);
		} finally {
			try {
				if (csvFileFileReader != null) {
					csvFileFileReader.close();
				}
				if (csvFileBufferedReader != null) {
					csvFileBufferedReader.close();
				}
			} catch (IOException e) {
				log.error("Error while closing the csv fle reader: ", e);
			}
		}

		return csvFileRecordsList;
	}

	/**
	 * readCSV method is another overloaded method used for reading the CSV File
	 * and creates a list with the data received from csvFilePath and returns
	 * the List contains CSV records this method takes list of CSV file records
	 * & header columns as the input parameters. This method is used for
	 * processing unprocessed records
	 * 
	 * @param csvFileRecords
	 * @param csvHeaderColumns
	 * @return List<Map<String, String>>
	 */
	public List<Map<String, String>> readCSV(List<String> csvFileRecords, String csvHeaderColumns) {

		List<Map<String, String>> csvFileRecordsList = null;
		Map<String, String> csvDataMap = null;

		try {
			csvFileRecordsList = new ArrayList<Map<String, String>>();
			for (String csvRecordString : csvFileRecords) {
				if (csvRecordString.trim().length() > 0) {
					csvDataMap = getKeyPairData(csvHeaderColumns, csvRecordString);

					csvFileRecordsList.add(csvDataMap);
				}
			}
		} catch (Exception exception) {
			log.error("Error while readin the CSV file data: ", exception);
		}
		return csvFileRecordsList;
	}

	/**
	 * readCSV method is another overloaded method used for reading the CSV File
	 * and creates a list with the data received from csvFilePath and returns
	 * the List contains CSV records this method takes CSV File object & a
	 * boolean which says the passed file is a Failure CSV or not as the input
	 * parameters This method is used for finding the unprocessed records
	 * 
	 * @param csvFile
	 * @param isFailureCSV
	 * @return List<Map<String, String>>
	 */
	public List<String> readCSV(File csvFile, boolean isFailureCSV) {

		String csvRecordString = null;

		BufferedReader csvFileBufferedReader = null;
		FileReader csvFileFileReader = null;
		List<String> csvFileRecordsList = null;
		try {
			csvFileRecordsList = new ArrayList<String>();
			if (csvFile.exists()) {
				csvFileFileReader = new FileReader(csvFile);
				csvFileBufferedReader = new BufferedReader(csvFileFileReader);
				csvRecordString = csvFileBufferedReader.readLine();
				while (csvRecordString != null) {
					if (isFailureCSV) {
						csvRecordString = csvRecordString.substring(0,
								csvRecordString.lastIndexOf(Constants.CSV_COLUMN_SEPARATOR));
					}
					csvFileRecordsList.add(csvRecordString);
					csvRecordString = csvFileBufferedReader.readLine();
				}
				csvFileRecordsList.remove(0);
			}
		} catch (Exception exception) {
			log.error("Error while reading the CSV file data: ", exception);
		} finally {
			try {
				if (csvFileFileReader != null) {
					csvFileFileReader.close();
				}
				if (csvFileBufferedReader != null) {
					csvFileBufferedReader.close();
				}
			} catch (IOException e) {
				log.error("Error while closing the csv fle reader: ", e);
			}
		}
		return csvFileRecordsList;
	}

	/**
	 * getUnprocessedRecords will take the paths of 3 CSV files Success, Failure
	 * & metadata CSV file's and finds the unprocessed records by checking all
	 * the 3 CSV files and return's the unprocessed records list object
	 * 
	 * @param successCSVFilePath
	 * @param failureCSVFilePath
	 * @param metadataCSVFilePath
	 * @return List<String>
	 */
	public List<String> getUnprocessedRecords(String successCSVFilePath, String failureCSVFilePath,
			String metadataCSVFilePath) {
		List<String> successCSVRecords = null;
		List<String> failureCSVRecords = null;
		List<String> metaDataCSVRecords = null;

		successCSVRecords = readCSV(new File(successCSVFilePath), false);
		failureCSVRecords = readCSV(new File(failureCSVFilePath), true);
		metaDataCSVRecords = readCSV(new File(metadataCSVFilePath), isFailreCSVFile(metadataCSVFilePath));

		metaDataCSVRecords.removeAll(successCSVRecords);
		metaDataCSVRecords.removeAll(failureCSVRecords);

		return metaDataCSVRecords;
	}

	/**
	 * isFailreCSVFile method is used to find whether a CSV file is a failure
	 * CSV or not by reading its header
	 * 
	 * @param csvFilePath
	 *            String
	 * @return boolean
	 */
	public boolean isFailreCSVFile(String csvFilePath) {
		String csvRecordString;
		boolean isFailureCSVFile = false;
		BufferedReader csvFileReader = null;
		try {
			csvFileReader = new BufferedReader(new FileReader(csvFilePath));
			csvRecordString = csvFileReader.readLine();
			if (csvRecordString != null) {
				isFailureCSVFile = csvRecordString.endsWith("," + Constants.FAILURE_CSV_EXTRAHEADER) ? true : false;
			}
		} catch (Exception exception) {
			log.error("Error while readin the CSV file in isFailureCSVFile method because of the error: ", exception);
		} finally {
			try {
				if (csvFileReader != null) {
					csvFileReader.close();
				}
			} catch (IOException e) {
				log.error("Error while closing the csv fle reader in isFailureCSVFile method: ", e);
			}
		}
		return isFailureCSVFile;
	}

	/**
	 * getCSVRecordsCount is used for getting count of the records present in
	 * the CSV file
	 * 
	 * @param csvFilePath
	 *            String
	 * @return int
	 */
	public static int getCSVRecordsCount(String csvFilePath) {
		int csvRecordsCount = -1;
		String csvRecordString = null;
		BufferedReader csvFileReader = null;
		try {
			if (new File(csvFilePath).exists()) {
				csvFileReader = new BufferedReader(new FileReader(csvFilePath));
				csvRecordString = csvFileReader.readLine();
				while (csvRecordString != null) {
					csvRecordsCount++;
					csvRecordString = csvFileReader.readLine();
				}
			} else {
				csvRecordsCount = 0;
			}
		} catch (Exception exception) {
			log.error("Error while readin the CSV file records count: ", exception);
		} finally {
			try {
				if (csvFileReader != null) {
					csvFileReader.close();
				}
			} catch (IOException e) {
				log.error("Error while closing the csv fle reader: ", e);
			}
		}
		return csvRecordsCount;
	}

	/**
	 * getColumnDataMap method is used for pairing the keyName and keyValue with
	 * the update status
	 * 
	 * @param String
	 *            headerRecord
	 * @param String
	 *            valuesRecord
	 * @return Map<String, String>
	 */

	private Map<String, String> getKeyPairData(String headerRecord, String valuesRecord) {
		int keyNumber = 0;
		String[] keyName = null;
		String[] value = null;
		Map<String, String> keyPairSet = null;

		try {
			keyPairSet = new HashMap<String, String>();
			keyName = headerRecord.split(Constants.CSV_COLUMN_SEPARATOR);
			value = valuesRecord.split(Constants.CSV_COLUMN_SEPARATOR + "(?=([^\"]*\"[^\"]*\")*[^\"]*$)");

			for (keyNumber = 0; keyNumber < keyName.length; keyNumber++) {
				if (keyNumber < value.length) {
					keyPairSet.put(keyName[keyNumber], value[keyNumber]);
				} else {
					keyPairSet.put(keyName[keyNumber], "");
				}
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return keyPairSet;
	}

}
