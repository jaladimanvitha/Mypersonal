import { Component, OnInit } from '@angular/core';
import { GecDocumentSearchModel } from '../_models/GecDocumentSearchModel';
import { SearchDetails } from '../_models';
import { SearchService, InvoiceService } from '../_services';
import { GecDocumentSearchDetails } from '../_models/GecDocumentSearchDetails';
import { TypeIdDropDown } from '../_models/TypeIdDropDown';
import { SubtypeIdDropDown } from '../_models/SubtypeIdDropDown';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from '../_services/dateformat';


@Component({
  selector: 'app-gecdocument',
  templateUrl: './gecdocumentsearch.component.html',
  styleUrls: ['./gecdocumentsearch.component.css'],
  providers: [
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
  ]
})

export class GecDocumentSearchComponent implements OnInit {


  typeid1: TypeIdDropDown[] = [
    { id: 0, name: 'id1' },
    { id: 1, name: 'id2' },

  ];

  subtypeid1: SubtypeIdDropDown[] = [
    { id: 0, name: 'sub id 1' },
    { id: 1, name: 'sub id 2' },

  ];

  public searchData;
  gecdocumentsearch: GecDocumentSearchModel = new GecDocumentSearchModel();
  searchDetails: GecDocumentSearchDetails = new GecDocumentSearchDetails();

  constructor(private _invoiceService: InvoiceService) { }

  ngOnInit() {
  }


  public getSearchData() {


    this._invoiceService.searchGecDocument(this.gecdocumentsearch).subscribe((data: Array<object>) => {
      this.searchData = data['metadataList'];
      console.log('entered');
      // console.log(data);
      // console.log(this.searchModel);
      console.log(this.searchData);

    });


  }

  onSubmit() {

    console.log('search data started');


    console.log(this.gecdocumentsearch);
    // this.metadata =  this._searchService.metadataIntialization(this.metadata);
    this.searchData = this.getSearchData();
    console.log(this.gecdocumentsearch);
    console.log(this.searchData);
    console.log('search data finished');
    document.getElementById('displaytable').style.display = 'inline-table';
    return true;
  }

}
