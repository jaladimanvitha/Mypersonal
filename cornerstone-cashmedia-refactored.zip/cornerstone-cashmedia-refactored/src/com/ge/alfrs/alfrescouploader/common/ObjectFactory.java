package com.ge.alfrs.alfrescouploader.common;

import javax.xml.bind.annotation.XmlRegistry;

/**
 * @author SK339124
 * 
 */

@XmlRegistry
public class ObjectFactory {

    public ObjectFactory() {
        //
    }

    public Lockbox createLockbox() {
        return new Lockbox();
    }

    public Mappings createMapping() {
        return new Mappings();
    }

}
