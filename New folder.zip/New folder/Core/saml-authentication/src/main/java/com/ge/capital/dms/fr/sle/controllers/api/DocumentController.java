package com.ge.capital.dms.fr.sle.controllers.api;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy.Type;
import java.util.HashMap;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.box.sdk.BoxAPIConnection;
import com.box.sdk.BoxAPIException;
import com.box.sdk.BoxFile;
import com.box.sdk.BoxFolder;
import com.ge.capital.dms.api.DocumentApi;
import com.ge.capital.dms.api.SearchApiController;
import com.ge.capital.dms.fr.sle.config.DecodeSSO;
import com.ge.capital.dms.model.DocumentIVO;
import com.ge.capital.dms.model.DocumentOVO;
import com.ge.capital.dms.service.DocumentService;
import com.ge.capital.dms.utility.AkanaToken;
import com.ge.capital.dms.utility.DmsUtilityConstants;
import com.ge.capital.dms.utility.DmsUtilityService;
import com.google.gson.Gson;

import io.swagger.annotations.ApiParam;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-08-14T22:22:38.380+05:30")

@CrossOrigin(origins = "*", exposedHeaders = "fileName")
@RestController
@RequestMapping("/secure")

public class DocumentController implements DocumentApi {

	private static final Logger log = LoggerFactory.getLogger(SearchApiController.class);

	@Value("${download.path}")
	private String DIRECTORY;

	@Autowired
	private ServletContext servletContext;

	@Autowired
	DmsUtilityService dmsUtilityService;

	@Autowired
	DocumentService documentService;
	
	@Autowired
	DecodeSSO decodeSSO;

	@Override
	
	@RequestMapping(value = "/documentProperties", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<DocumentOVO> documentPropertiesPost(
			@ApiParam(value = "", required = true) @Valid @RequestBody DocumentIVO documentIVO) {
		// TODO Auto-generated method stub

		HashMap<String, String> dopPropertiesMap;

		try {
			String docType = documentIVO.getDocType();
			String documentId = documentIVO.getDocId();

			dopPropertiesMap = documentService.getDocumentProperties(docType, documentId);
			DocumentOVO documentOVO = new DocumentOVO();
			documentOVO.setMetadataList(dopPropertiesMap);
			return new ResponseEntity<DocumentOVO>(documentOVO, HttpStatus.OK);

		} catch (Exception e) {
			log.error("Couldn't serialize response for content type application/json", e);
			return new ResponseEntity<DocumentOVO>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	
	@RequestMapping("/deleteDoc")
	public ResponseEntity<String> deleteDoc(HttpServletRequest request,
			@ApiParam(value = "", required = true) @Valid @RequestBody String[] document) {
		String loggedinUser = decodeSSO.getDecodedSSO(request.getHeader("loggedinuser"));
		AkanaToken akanaToken = dmsUtilityService.generateAkanaAccessToken();
		JSONObject boxTokenJSON = dmsUtilityService.generateBoxAccessToken(akanaToken.getAccess_token());
		String boxToken = boxTokenJSON.get("accessToken").toString();
		// System.out.println(document +" is of length :"+ document.length);

		if (!boxToken.isEmpty()) {
			// box connectivity
			BoxAPIConnection api = new BoxAPIConnection(boxToken);
			java.net.Proxy proxy = new java.net.Proxy(Type.HTTP,
					new InetSocketAddress("PITC-Zscaler-Americas-Cincinnati3PR.proxy.corporate.ge.com", 80));
			api.setProxy(proxy);
			for (int i = 0; i < document.length; i++) {
				System.out.println(document[0]);
				String[] docDetails = document[i].split(",");
				String[] docType = docDetails[0].split(":");
				String[] docId = docDetails[1].split(":");
				String temp = docId[1].replace('}', ' ').replace('"', ' ').trim();
				String dT = docType[1].replace('}', ' ').replace('"', ' ').trim();
				try {
					BoxFile file = new BoxFile(api, temp);
					file.delete();
					documentService.deleteDoc(docId[1].replace('}', ' ').replace('"', ' ').trim(),
							docType[1].replace('}', ' ').replace('"', ' ').trim());
					documentService.updateAuditInfo(temp, "deleteDoc", dT, loggedinUser, "SUCCESS",
							"document deleted successfully");
					// return new ResponseEntity<String>("files deleted successfully",
					// HttpStatus.OK);

				} catch (Exception e) {
					documentService.updateAuditInfo(temp, "deleteDoc", dT, loggedinUser, "FAILED","Failed to delete document with status"+HttpStatus.BAD_REQUEST);
					e.printStackTrace();
					return new ResponseEntity<String>("File doesnot esist", HttpStatus.BAD_REQUEST);
				}
			}
		}

		return new ResponseEntity<String>("files deleted successfully", HttpStatus.OK);

	}
	
	@SuppressWarnings("deprecation")
	
	@RequestMapping(value = "/downloadDocument", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Resource> documentDownloadPost(HttpServletRequest request,
			@ApiParam(value = "", required = true) @Valid @RequestBody String boxId) {
		// TODO Auto-generated method stub
		BoxFile file = null;
		MediaType mediaType = null;
		File _file = null;
		String fileName = null;
		BoxFile.Info info = null;
		FileOutputStream stream = null;
		InputStreamResource resource = null;
		String loggedinUser = decodeSSO.getDecodedSSO(request.getHeader("loggedinuser"));
		
		AkanaToken akanaToken = dmsUtilityService.generateAkanaAccessToken();
		JSONObject boxTokenJSON = dmsUtilityService.generateBoxAccessToken(akanaToken.getAccess_token());
		String boxToken = boxTokenJSON.get("accessToken").toString();
		JSONObject jsonboxId = (JSONObject) JSONValue.parse(boxId);
		String box_Id = jsonboxId.get("boxId").toString();

		System.out.println("boxToken: " + boxToken);

		Properties props = dmsUtilityService.loadPropertiesFile(DmsUtilityConstants.applicationConstantsResource);

		if (!boxToken.isEmpty()) {
			// box connectivity
			BoxAPIConnection api = new BoxAPIConnection(boxToken);
			java.net.Proxy proxy = new java.net.Proxy(Type.HTTP,
					new InetSocketAddress("PITC-Zscaler-Americas-Cincinnati3PR.proxy.corporate.ge.com", 80));
			api.setProxy(proxy);
			file = new BoxFile(api, box_Id);
			info = file.getInfo();
			fileName = info.getName();

			try {
				stream = new FileOutputStream(DIRECTORY + "\\" + fileName);
				file.download(stream);
				_file = new File(DIRECTORY + "\\" + fileName);
				resource = new InputStreamResource(new FileInputStream(_file));
				mediaType = DmsUtilityService.getMediaTypeForFileName(this.servletContext, _file);
				documentService.updateAuditInfo(box_Id, "download", "", loggedinUser, "SUCCESS",
						"user successfully downloaded the document");
			} catch (BoxAPIException e) {
				System.out.println("The API returned a code of 404 for the docID: "+box_Id);
			} catch(Exception e) {
				documentService.updateAuditInfo(box_Id, "download", "", loggedinUser, "FAILED",
						"user is not able to download the document");
				e.printStackTrace();
			}finally {
				// delete file from server
				try {
					stream.close();
					new File(DIRECTORY + "\\" + fileName).delete();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}
		return ResponseEntity.ok()
				// Content-Disposition
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;").header("fileName", fileName)
				// Content-Type
				.contentType(mediaType)
				// Contet-Length
				.contentLength(_file.length()) //
				.body(resource);
	}
	
	
	
	@Override
	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> documentUploadPost(MultipartFile files) {
		// TODO Auto-generated method stub
		String respMsg = null;

		boolean respflg = false;
		AkanaToken akanaToken = dmsUtilityService.generateAkanaAccessToken();
		JSONObject boxTokenJSON = dmsUtilityService.generateBoxAccessToken(akanaToken.getAccess_token());
		String boxToken = boxTokenJSON.get("accessToken").toString();

		if (!boxToken.isEmpty()) {
			// box connectivity
			BoxAPIConnection api = new BoxAPIConnection(boxToken);
			java.net.Proxy proxy = new java.net.Proxy(Type.HTTP,
					new InetSocketAddress("PITC-Zscaler-Americas-Cincinnati3PR.proxy.corporate.ge.com", 80));
			api.setProxy(proxy);

			FileInputStream stream = null;
			String folderID = "55532162174";
			BoxFolder folder = new BoxFolder(api, folderID);
			// BoxFolder folder = BoxFolder.getRootFolder(api);

			System.out.println(files.getOriginalFilename() + ": " + files.getContentType());
			File file = new File("D:\\GEGDC\\PV477886\\temp\\upload" + "\\" + files.getOriginalFilename());
			try {
				files.transferTo(file);
				stream = new FileInputStream(file);
				BoxFile.Info newFileInfo = folder.uploadFile(stream, files.getOriginalFilename());
				System.out.println(newFileInfo.getName() + ":uploaded to box successfully...");
				respflg = true;
			} catch (IllegalStateException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				respflg = false;
			} finally {
				try {
					stream.close();
					file.delete();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					respflg = false;
				}
			}

			if (respflg == true)
				respMsg = "Document uploaded to box successfully";
			else
				respMsg = "Something went wrong and could not upload the document";
		}

		Gson g = new Gson();
		String Jsonstr = g.toJson(respMsg);

		return new ResponseEntity<String>(Jsonstr, HttpStatus.OK);
	}
	
	

	@Override
	public ResponseEntity<Resource> documentDownloadPost(String boxId) {
		// TODO Auto-generated method stub
		return null;
	}

}
