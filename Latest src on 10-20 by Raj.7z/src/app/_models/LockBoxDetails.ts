import { LockboxModel } from './LockboxModel';

export class LockboxDetails {

    public docType = 'lockbox';
    public metadata: LockboxModel;

}
