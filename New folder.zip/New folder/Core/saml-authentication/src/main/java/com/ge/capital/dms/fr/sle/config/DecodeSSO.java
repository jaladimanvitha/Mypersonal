package com.ge.capital.dms.fr.sle.config;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;
import org.springframework.context.annotation.Configuration;


@Configuration
public class DecodeSSO {
	
	public String getDecodedSSO(String encodedLoggedinUser)
	{
		String loggedDecodedValue = StringUtils.newStringUtf8(Base64.decodeBase64(encodedLoggedinUser));
		//long number = Long.parseLong(loggedDecodedValue);
		//String loggedinUser = Long.toString(number);
		System.out.println("The Frist Value is : "+ encodedLoggedinUser);
		System.out.println("Decoded Value is : "+ loggedDecodedValue);
		//System.out.println("Decoded Value is : "+ loggedinUser);
		return loggedDecodedValue;
	}

}
