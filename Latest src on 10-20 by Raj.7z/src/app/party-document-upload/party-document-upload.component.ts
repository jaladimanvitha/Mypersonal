import { Component, OnInit } from '@angular/core';
import { PartyDealDropDown } from '../_models/PartyDealDropDown';
import { PartyDocUploadModel } from '../_models/PartyDocUploadModel';
import {Router, ActivatedRoute} from '@angular/router';
import { FileSelectDirective, FileUploader} from 'ng2-file-upload';
import {  FormControl, NgForm, FormBuilder } from '@angular/forms';
import {NgbModal, ModalDismissReasons, NgbActiveModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import { InvoiceService } from '../_services';

@Component({
  selector: 'app-party-document-upload',
  templateUrl: './party-document-upload.component.html',
  styleUrls: ['./party-document-upload.component.css']
})




export class PartyDocumentUploadComponent implements OnInit {

public searchData: Array<object> = [];
submitted = false;
   uploadArray = [];
   modalReference: NgbModalRef;
   closeResult: string;
  constructor(private _invoiceService: InvoiceService,private modalService: NgbModal,private router:Router, private activatedRoute:ActivatedRoute) { }

  ngOnInit() {
  this.partyUpload.partyNumber5 = this.activatedRoute.snapshot.queryParamMap.get('partyNumber5');
    this.partyUpload.partyName5 = this.activatedRoute.snapshot.queryParamMap.get('partyName5');
    this.partyUpload.partyDealType5 = this.activatedRoute.snapshot.queryParamMap.get('partyDealType5');
  }
  partyUpload : PartyDocUploadModel = new PartyDocUploadModel();
party1: PartyDealDropDown[] = [
    { id: 0, name: 'Customer' },
    { id: 1, name: 'Funder' },
    { id: 2, name: 'Vendor' },
  ];
  
  public partyData = [
{
 "documentSubType" : "",
  "welcomePackage" : "",
  "syndicationPackage": "",
  "physicalStorageStatus": "",
  "fileName": "87225521.pdf",
  "progress": "10%",
 
}];

  upload(userForm: NgForm) {
  if(userForm.form.value.docSubType == null){
      alert('Document SubType cannot be Empty');
     return false;
   }
   
   else{
    if(userForm.form.value.partyNumber5 == null) {
     alert('Party Number cannot be Empty');
     return false;
      
   }
   }
   
  console.log(userForm.form.value);
  return true;
  }
  
  open(content) {
    
   this.modalReference = this.modalService.open(content);
   this.modalReference.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }
  close() {
    this.modalReference.close();
     this.router.navigate(['/home']);
    }
}
