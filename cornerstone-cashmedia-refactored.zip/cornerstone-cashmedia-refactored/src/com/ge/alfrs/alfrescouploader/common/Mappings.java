package com.ge.alfrs.alfrescouploader.common;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * @author SK339124
 * 
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "lockboxList" })
@XmlRootElement(name = "mappings")
public class Mappings {

    @XmlElement(name = "lockbox", nillable = false, namespace = "http://www.ge.com/CashMapping")
    private List<Lockbox> lockboxList;

    public List<Lockbox> getLockbox() {
        if (lockboxList == null) {
            lockboxList = new ArrayList<Lockbox>();
        } 
        return this.lockboxList;
    }

}