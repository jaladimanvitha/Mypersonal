package com.ge.alfrs.cashmedia.boadatatransformer.constants;

import com.ge.alfrs.cashmedia.boadatatransformer.constants.Messages;

	/**
	 This is the interface contains all the String constants which we 
	 have used in the application. In a Interface all the variables are by default public static final  */


	public interface Constants {	
	
		public static final String LOG_FILEPATH = Messages.getString("logFilePath");
		public static final String LOG_FILENAME_DATEFORMAT = Messages.getString("logFileNameDateFormat");
		
	    public static final String LOCKBOX_PATH = Messages.getString("LOCKBOX_PATH");
		public static final String REQUIRED_CSV_PROPERTY_NAMES = Messages.getString("REQUIRED_CSV_PROPERTY_NAMES");
		public static final String CSV_FILEPATH_TO_WRITE= Messages.getString("CSV_FILEPATH_TO_WRITE");
		
		public static final String COMMA_SEPERATOR = Messages.getString("COMMA_SEPERATOR");
		public static final String SEMICOLON_SEPERATOR = Messages.getString("SEMICOLON_SEPERATOR");
		public static final String CURRENT_DATE_FORMAT = Messages.getString("CURRENT_DATE_FORMAT");
		public static final String CSV_EXTENSION = Messages.getString("CSV_EXTENSION");
	    public static final String DETAIL_CSV_EXTENSION = Messages.getString("DETAIL_CSV_EXTENSION");
	    
	    
	    public static final String CSV_COL_MULTIIVALUEDENTIFIER =Messages.getString("CSV_COL_MULTIIVALUEDENTIFIER");
	    public static final String CSV_MULTIVALUED_COLUMNNAMES = Messages.getString("CSV_MULTIVALUED_COLUMNNAMES");
	    public static final String CSV_MULTIVALUED_COLUMNNAMES_SEPARATOR = Messages.getString("CSV_MULTIVALUED_COLUMNNAMES_SEPARATOR");
	    
	    public static final String COLUMN_VALUES_TOBE_DEFAULTED = Messages.getString("COLUMN_VALUES_TOBE_DEFAULTED");
		public static final String COLUMN_VALUES_TO_ELIMINATE_TRAILINGZEROS = Messages.getString("COLUMN_VALUES_TO_ELIMINATE_TRAILINGZEROS");
		public static final String COLUMN_VALUES_TOBE_DEFAULTED_SEPARATOR = Messages.getString("COLUMN_VALUES_TOBE_DEFAULTED_SEPARATOR");
		public static final String COLUMN_VALUES_TOBE_DEFAULTED_VALUESEPARATOR = Messages.getString("COLUMN_VALUES_TOBE_DEFAULTED_VALUESEPARATOR");
		public static final String COLUMN_VALUES_TO_ELIMINATE_TRAILINGZEROS_SEPARATOR = Messages.getString("COLUMN_VALUES_TO_ELIMINATE_TRAILINGZEROS_SEPARATOR");
	    
	    public static final boolean ISOBFUSCATION_REQUIRED = Boolean.parseBoolean(Messages.getString("ISOBFUSCATION_REQUIRED"));
	    
	    public static final String SUCCESS_CSV_FILEPATH = Messages.getString("SUCCESS_CSV_FILEPATH");
		public static final String FAILURE_CSV_FILEPATH = Messages.getString("FAILURE_CSV_FILEPATH");
		public static final String METADATA_CSV_FILESPATH = Messages.getString("METADATA_CSV_FILESPATH");
		
		public static final String CSV_COL_ImagePath = Messages.getString("CSV_COL_ImagePath");
		public static final String CSV_COL_Check = Messages.getString("CSV_COL_Check");
		public static final String CSV_COL_CheckImage = Messages.getString("CSV_COL_CheckImage");
		public static final String CSV_COL_EnvelopeImage =Messages.getString("CSV_COL_EnvelopeImage");
		public static final String CSV_COL_InvoiceImage=Messages.getString("CSV_COL_InvoiceImage");
		public static final String BOA_ImagesFolderName = Messages.getString("BOA_ImagesFolderName");
		public static final String Date_Name = Messages.getString("Date_Name");
		public static final String BOA_ImageExtension =Messages.getString("BOA_ImageExtension");
		public static final String CSV_COL_SourceBankName = Messages.getString("CSV_COL_SourceBankName");
		public static final String CSV_COL_ABA = Messages.getString("CSV_COL_ABA");
		public static final String CSV_RecordsLimit =Messages.getString("CSV_RecordsLimit");
		public static final String CSV_COL_TargetDC =Messages.getString("CSV_COL_TargetDC");
		public static final String CSV_COL_InvoiceNumber = Messages.getString("CSV_COL_InvoiceNumber");
		public static final String INVOICE_NUM_DEFAULTVALUE = Messages.getString("INVOICE_NUM_DEFAULTVALUE");
		public static final String INVOICE_IMAGE_DEFAULTVALUE = Messages.getString("INVOICE_IMAGE_DEFAULTVALUE");
		public static final String CSV_COL_CheckNumber = Messages.getString("CSV_COL_CheckNumber");
		public static final String CSV_COL_CheckAmount = Messages.getString("CSV_COL_CheckAmount");
		public static final String METADATA_CSV_HEADERS = Messages.getString("METADATA_CSV_HEADERS");
		
		public static final int EXITCODE_ROOTFOLDER_NOTFOUND = Integer.parseInt(Messages.getString("EXITCODE_ROOTFOLDER_NOTFOUND"));
		public static final int EXITCODE_NOLOCKBOXS = Integer.parseInt(Messages.getString("EXITCODE_NOLOCKBOXS"));
		public static final int EXITCODE_CSVHEADERS_INCORRECT = Integer.parseInt(Messages.getString("EXITCODE_CSVHEADERS_INCORRECT"));
		public static final int EXITCODE_CSVRECORDS_PROCESSERRORS = Integer.parseInt(Messages.getString("EXITCODE_CSVRECORDS_PROCESSERRORS"));
		public static final int EXITCODE_DETAILCSV_NOTFOUND = Integer.parseInt(Messages.getString("EXITCODE_DETAILCSV_NOTFOUND"));
		public static final int EXITCODE_METADATACSV_NOTGENERATED = Integer.parseInt(Messages.getString("EXITCODE_METADATACSV_NOTGENERATED"));
		public static final int EXITCODE_CSVFILE_READISSUES = Integer.parseInt(Messages.getString("EXITCODE_CSVFILE_READISSUES"));
		
	
	}


