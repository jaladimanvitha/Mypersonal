export class OriginDocSearchModel {

    public proposalId: string;
    public customerName: string;
    public transactionId: string;
    public userAdded: string;
    public eFileCreateDate: string;
    public documentType: string;
    public siebleUpdateDate: string;
    public dockey1: string;
    public platform: string;
    public region: string;
    public entityType: string;
    public entityTypeId: string;
    public contractId: string;
    public creditId: string;
    public isFinalDoc: string;
    public QuoteId: string;
    public sumId: string;
    public sumStatus: string;
    public systemId: string;
    public retentionCode: string;
    public statusDrop: string;
    public originationsDocSource: string;
    public originationsSourceType: string;
    public partyNumber: string;
    public partyName: string;
    public sfdcAccountId: string;
    public sfdcOpportunityId: string;
    public lineOfCreditNumber: string;
    public lwContractSequenceNumber: string;
    public statusdropdown: string;
    public contract: string;
    public retentiondate: string;
    public welcomePackage: string;
    public syndicationPackage: string;
    public fileNetGuid: string;
    public name: string;
    public title: string;



}
