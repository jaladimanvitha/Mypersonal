package com.ge.alfrs.alfrescouploader.helper;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

import com.ge.alfrs.alfrescouploader.common.Lockbox;
import com.ge.alfrs.alfrescouploader.common.Mappings;
import com.ge.alfrs.alfrescouploader.constants.Constants;

/**
 * @author SK339124
 * 
 */
public class CashMediaXMLReader {

    /**
     * 
     */

    private static Logger log = Logger.getLogger(CashMediaXMLReader.class);

    List<Lockbox> list;

    /**
     * This method is to read the Cash Media Business mappings and apply the
     * security policy based on the bank and business
     * 
     * @return
     */
    public List<Lockbox> lockBox() {

        try {

            File file = new File(Constants.CASHMEDIA_BUSINESS_MAPPINGS);
            JAXBContext jaxbContext = JAXBContext.newInstance(Mappings.class
                    .getPackage().getName(), Mappings.class.getClassLoader());
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            Mappings que = (Mappings) jaxbUnmarshaller.unmarshal(file);
            list = que.getLockbox();

        } catch (JAXBException e) {
            e.printStackTrace();
            log.error("Error wile parsing the xml in method--parseXML " + e);

        }
        return list;

    }

}
