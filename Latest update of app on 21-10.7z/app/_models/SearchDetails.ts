import { MetadataModel } from './MetadataModel';

export class SearchDetails {

    public docType = 'invoices';
    public metadata: MetadataModel;

}
