package com.ge.capital.dms.entity;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "cornerstone_message")
public class CornerstoneMessage implements Serializable {

	private static final long serialVersionUID = 4L;

	@Id
	private int attempt_count;
	private String error_cause;
	private String message_json;
	private String message_type;
	private Timestamp modified_date;
	private String status;
	private String entity_id;
	public int getAttempt_count() {
		return attempt_count;
	}
	public void setAttempt_count(int attempt_count) {
		this.attempt_count = attempt_count;
	}
	public String getError_cause() {
		return error_cause;
	}
	public void setError_cause(String error_cause) {
		this.error_cause = error_cause;
	}
	public String getMessage_json() {
		return message_json;
	}
	public void setMessage_json(String message_json) {
		this.message_json = message_json;
	}
	public String getMessage_type() {
		return message_type;
	}
	public void setMessage_type(String message_type) {
		this.message_type = message_type;
	}
	public Timestamp getModified_date() {
		return (Timestamp) modified_date.clone();
	}
	public void setModified_date(Timestamp modified_date) {
		this.modified_date = (Timestamp) modified_date.clone();
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEntity_id() {
		return entity_id;
	}
	public void setEntity_id(String entity_id) {
		this.entity_id = entity_id;
	}
	
}
