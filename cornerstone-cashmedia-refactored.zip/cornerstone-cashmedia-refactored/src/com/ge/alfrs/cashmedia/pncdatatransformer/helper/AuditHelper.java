package com.ge.alfrs.cashmedia.pncdatatransformer.helper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.ge.alfrs.cashmedia.pncdatatransformer.constants.Constants;

/**
 * AuditHelper class is used to make the file audit.
 * 
 * @author CP97964
 * 
 */

public class AuditHelper {

	private static Logger log = Logger.getLogger(AuditHelper.class);

	private boolean hasAuditError = false;
	private String auditEmailMessage = "";
	private Map<String, String> imageTypeCount = null;


	public Map<String, String> readInfotxtfile(String lockboxInputPath)
			throws IOException {

		String infoFileName = lockboxInputPath + File.separator + "info.txt";
		imageTypeCount = new HashMap<String, String>();
		BufferedReader bufferedReader = null;
		try {

			FileReader fileReader = new FileReader(infoFileName);
			String infoTxt[] = { "NumChecks", "NumImages", "TotalAmount" };
			List<String> infoTxtList = Arrays.asList(infoTxt);
			bufferedReader = new BufferedReader(fileReader);
			String line = null;

			while ((line = bufferedReader.readLine()) != null) {

				String name = "";
				if (line.split("=").length > 0) {
					name = line.split("=")[0];
				}

				if (infoTxtList.contains(name)) {
					String value = line.split("=")[1];
					imageTypeCount.put(name, value);

				}

			}

			bufferedReader.close();

		} catch (IOException ioe) {
			log.info(" Exception while reading info.txt ", ioe);
		} finally {
			if (bufferedReader != null) {
				bufferedReader.close();
			}

		}

		return imageTypeCount;
	}

	public void startAuditProcess(List<Map<String, String>> csvFileRecordsList,
			String csvFilePath) throws Exception {

		log.info(" Processing  lockbox folder "+csvFilePath);
		String lockboxInputPath = csvFilePath.substring(0,
				csvFilePath.lastIndexOf(File.separator));

		String lockboxFolderName = csvFilePath.substring(
				csvFilePath.lastIndexOf(File.separator) + 1,
				csvFilePath.length()).replace(".csv", "");
		lockboxFolderName = lockboxFolderName.substring(4,
				lockboxFolderName.length());

		log.info("Validation lockbox # " + lockboxFolderName);
		Map<String, String> imageTypeCount = readInfotxtfile(lockboxInputPath);

		String imageDirName = lockboxInputPath + File.separator + "images";
		File imageDir = new File(imageDirName);
		int imgFilesCount = 0;
		if (imageDir != null) {
			if (imageDir.listFiles() != null) {
				imgFilesCount = imageDir.listFiles().length;
			}

		}

		Set<String> imageSet = new HashSet<String>();
		Set<String> checkImageSet = new HashSet<String>();

		Set<String> checkAmounts = null;

		Map<String, Set<String>> checkAmountsMap = new HashMap<String, Set<String>>();

		for (Map<String, String> csvFileRecords : csvFileRecordsList) {

			String checkImage = csvFileRecords.get("Check Image");
			if (!checkImage.trim().equals("")) {
				imageSet.add(checkImage);
				checkImageSet.add(checkImage);
			}

			String envelopeImage = csvFileRecords.get("Envelope Image");

			if (!envelopeImage.trim().equals("")) {
				imageSet.add(envelopeImage);
			}

			String invoiceImage = csvFileRecords.get("Invoice Image");

			if (!invoiceImage.trim().equals(""))
				imageSet.add(invoiceImage);

			String allPageImage = csvFileRecords.get("All Page Images");

			if (!allPageImage.trim().equals("")) {
				String[] allPageImages = allPageImage.split(";");

				for (String allPageImageName : allPageImages) {
					imageSet.add(allPageImageName);
				}

			}
			// Check amount is unique for a combination of Batch item and Batch
			// in the boxnumber.csv file
			String batchItem = csvFileRecords.get("Batch Item");
			String batch = csvFileRecords.get("Batch");
			String checkAmount = csvFileRecords.get("Amount");
			String checkAmountKey = batch + "_" + batchItem;

			if (checkAmountsMap.get(checkAmountKey) == null) {
				checkAmounts = new HashSet<String>();
				checkAmounts.add(checkAmount);
				checkAmountsMap.put(checkAmountKey, checkAmounts);
			}

			// checkAmounts.add(checkAmount);
		}

		log.info(" Total number of images in CSV file -" + imageSet.size());
		log.info(" Total number of images in image folder -" + imgFilesCount);
		// Validation Step 2 -validate # of images in csv file with no of images
		// received

		if (imageSet.size() != imgFilesCount) {
			this.hasAuditError = true;
			auditEmailMessage = auditEmailMessage
					.concat(Constants.IMAGE_COUNT_ERROR_MSG_2);
			log.info("Number of images in the CSV file," + imageSet.size()
					+ " does not match number of images in the image folder ,"
					+ imgFilesCount);
		}

		// Validation Step 4 - Total Amount Validation

		double totalAmount=0.0;
		if(!imageTypeCount.isEmpty()){
		    totalAmount = Double.parseDouble(imageTypeCount
				.get("TotalAmount"));
		totalAmount = totalAmount / 100.00;

		log.info(" Total formatted amount from info.txt " + totalAmount);
		}
		BigDecimal totalCsvCheckAmount = null;
		Set<String> keys = checkAmountsMap.keySet();

		for (String key : keys) {
			Set<String> checkAmountsList = checkAmountsMap.get(key);

			for (String checkAmount : checkAmountsList) {

				if (totalCsvCheckAmount == null) {
					totalCsvCheckAmount = new BigDecimal(checkAmount);
				} else {
					totalCsvCheckAmount = totalCsvCheckAmount
							.add(new BigDecimal(checkAmount));
				}

			}

		}

		totalCsvCheckAmount = totalCsvCheckAmount.setScale(2,
				RoundingMode.CEILING);

		log.info(" Total formatted check amount from CSV "
				+ totalCsvCheckAmount);

		if (totalCsvCheckAmount.doubleValue() != totalAmount && totalAmount>0.1) {
			hasAuditError = true;
			auditEmailMessage = auditEmailMessage
					.concat(Constants.AMOUNT_ERROR_MSG);
			log.info(" Total amount in info.txt " + totalAmount
					+ " does not match total amount, " + totalCsvCheckAmount
					+ " in boxnumber csv file.");
		}

		// Validation Step 3 - Validate check images in csv to checkimages in
		// info.txt
		int numChecks=0;
		if(!imageTypeCount.isEmpty()){
		numChecks = Integer.parseInt(imageTypeCount.get("NumChecks"));
		

		log.info("No of check Images in csv = " + checkImageSet.size()
				+ " number of checks in info.txt " + numChecks);
		}
		if (numChecks != checkImageSet.size() && numChecks>0 ) {
			hasAuditError = true;
			auditEmailMessage = auditEmailMessage
					.concat(Constants.CHECK_COUNT_ERROR_MSG);
			log.info(" Number of check images in CSV file," + numChecks
					+ " does not match check count" + checkImageSet.size()
					+ " in info.txt");
		}

		if (hasAuditError) {
			SendMail sendMail = new SendMail();
			auditEmailMessage = auditEmailMessage
					.concat("Please check logs for additional information .");
			sendMail.sendMail("Error:Lockbox # -" + lockboxFolderName + " "
					+ Constants.SUBJECT_AUDIT_ERR_MSG, auditEmailMessage,
					Constants.TO_ADDRESS, Constants.FROM_ADDRESS,
					Constants.SMTPHOST);
		}

	}

	public void validateExtraction(File lockBoxFolder) {
		
		log.info(" Start validating extraction ");
		boolean hasBoxNumberCSV = false;
		String lockboxNumber = "";
		int numberOfFiles = 0;

		boolean hasExtractionError = false;

		boolean hasDetailCSV = false;
		boolean hasInfotxt = false;
		boolean hasSummary= false;
		boolean hasCorresp= false;

		try {

			String lockBoxFolderPath = lockBoxFolder.toString().trim();
			log.info(lockBoxFolderPath);
			int beginIndex = lockBoxFolderPath.lastIndexOf(File.separator) + 1;
			int endIndex = lockBoxFolderPath.length();

			lockboxNumber = lockBoxFolderPath.substring(beginIndex, endIndex);
			
			String tempLockBoxNumber=lockboxNumber.replaceAll("[.]", "_");
			
			lockboxNumber=StringUtils.split(tempLockBoxNumber, '_')[1];
	

			if (lockboxNumber.contains("_")) {
				String[] splitLockboxNumber = lockboxNumber.split("_");
				lockboxNumber = splitLockboxNumber[0];
			}

			
			File[] lockboxFiles = lockBoxFolder.listFiles();
			numberOfFiles = lockboxFiles.length;

			List<String> lockboxNames = new ArrayList<String>();

			for (File lockboxFile : lockboxFiles) {
				String lockboxFileName = lockboxFile.getName().trim();
				if (lockboxFileName.contains(lockboxNumber)) {
					hasBoxNumberCSV = true;
				} else if (lockboxFileName.equals("info.txt")) {
					hasInfotxt = true;
				} else if (lockboxFileName.equals("detail.csv")) {
					hasDetailCSV = true;
				}
				else if (lockboxFileName.equals("summary.csv")) {
					hasSummary = true;
				}
				else if (lockboxFileName.equals("corresp.csv")) {
					hasCorresp = true;
				}

				lockboxNames.add(lockboxFileName);

			}

			String imageDirectoryPath = lockBoxFolder + File.separator
					+ "images";

			File imageDirectory = new File(imageDirectoryPath);
			boolean isImageDirPresent = imageDirectory.exists();

			int imageCount = 0;
			if (isImageDirPresent) {
				imageCount = imageDirectory.listFiles().length;
			}
	
			if (!isImageDirPresent) {
				log.info("  No image directory present in " + lockboxNumber);
				auditEmailMessage = auditEmailMessage
						.concat(Constants.IMAGE_DIRECTORY_MISSING);

				hasExtractionError = true;
			}
			if (numberOfFiles == 0) {
				log.info(" No files have been extracted in " + lockboxNumber);
				auditEmailMessage = auditEmailMessage
						.concat(Constants.ALL_FILES_MISSING);
				hasExtractionError = true;
			} 
			
			if (!hasInfotxt) {
				log.info(" Info.txt not extracted in " + lockboxNumber);
				auditEmailMessage = auditEmailMessage
						.concat(Constants.INFOTXT_MISSING);
				hasExtractionError = true;
			} 
			if (imageCount == 0) {
				log.info(" No images extracted in " + lockboxNumber);
				auditEmailMessage = auditEmailMessage
						.concat(Constants.IMAGE_FILES_MISSING);
				hasExtractionError = true;
			} 
			if (!hasBoxNumberCSV) {
				log.info(" BoxNumber csv not extracted in " + lockboxNumber);
				auditEmailMessage = auditEmailMessage
						.concat(Constants.BOXNUMBER_CSV_MISSING);
				hasExtractionError = true;
			} 
			
			if (isImageDirPresent && imageCount == 0 && hasInfotxt  && hasDetailCSV && !hasBoxNumberCSV)
			{
				if (hasSummary && hasCorresp)
				{
					hasExtractionError = false;
					
					log.info(" No Transaction for this lockbox for today ");
				}
				
			}
			
			

			if (hasExtractionError) {
				SendMail sendMail = new SendMail();

				sendMail.sendMail("Error:Lockbox # -" + lockboxNumber + " "
						+ Constants.SUBJECT_AUDIT_ERR_MSG, auditEmailMessage,
						Constants.TO_ADDRESS, Constants.FROM_ADDRESS,
						Constants.SMTPHOST);
			}

		} catch (Exception e) {
			log.info(" Error while validating extraction ", e);
		}

		
		log.info(" End validating extraction ");
	}
}
