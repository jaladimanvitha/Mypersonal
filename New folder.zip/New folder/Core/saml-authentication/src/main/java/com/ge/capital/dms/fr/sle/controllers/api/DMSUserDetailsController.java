package com.ge.capital.dms.fr.sle.controllers.api;

import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.ge.capital.dms.entity.DMSUserDetails;
import com.ge.capital.dms.exception.CustomGenericException;
import com.ge.capital.dms.fr.sle.config.DecodeSSO;
import com.ge.capital.dms.repository.DMSUserDetailsRepository;
import com.ge.capital.dms.service.DocumentService;
import com.ge.capital.dms.service.UpdateService;
import com.ge.capital.dms.service.UserRealmService;
import com.ge.capital.dms.utility.CommonConstants;

import io.swagger.annotations.ApiParam;

/**
 * @author VA460440
 */

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/getDMSUserdetails")


public class DMSUserDetailsController {

	@Autowired
	DMSUserDetailsRepository dmsUserDetailsRepository;

	@Autowired
	UserRealmService userRealmService;
	
	@Autowired
	DocumentService documentService;
	
	@Autowired
	DecodeSSO decodeSSO;
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@RequestMapping(value = "/getByUserId", method = RequestMethod.POST)
	public List<DMSUserDetails> getByUserId(@RequestBody String ssoId) {
		List<DMSUserDetails> dmsUserdetails;

		logger.info("Service call for getting the firstname and lastname Values by userid");
		try {
			String userSSO = decodeSSO.getDecodedSSO(ssoId);
			dmsUserdetails = (List<DMSUserDetails>) dmsUserDetailsRepository.findFirstNameAndLastname(userSSO);

		} catch (Exception e) {
			logger.error("Exception occured :" + e);
			throw new CustomGenericException(CommonConstants.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		System.out.println("Service call for getting the firstname and lastname Values by userid is Ended");
		return dmsUserdetails;

	}
	
	@RequestMapping("/userRealm")
	public List<String> getUserRealm(@ApiParam(value = "", required = true) @Valid @RequestBody String userId) {
		//System.out.println(userId);
		List<String> userRealmList;
		try {
			System.out.println(userId);
			String userSSO = decodeSSO.getDecodedSSO(userId);
		//userRealmList=(List<DMSGroup>) userRealmRepository.findUserRealm(userId);
			userRealmList = userRealmService.userRealm(userSSO);
		} catch(Exception e) {
			throw new CustomGenericException(CommonConstants.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		return userRealmList;
		
	}
	
	@RequestMapping("/userDetails")
	public List<HashMap<String, String>> getUserDetails(@ApiParam(value = "", required = true) @Valid @RequestBody String userId) {
		System.out.println("The encrypted String is :"+userId);
		
		
		String decodedUserId = decodeSSO.getDecodedSSO(userId);
		List<HashMap<String, String>> userRealmList;
		try {
			System.out.println(userId);	
		//userRealmList=(List<DMSGroup>) userRealmRepository.findUserRealm(userId);
			userRealmList = userRealmService.userDetails(decodedUserId);
		} catch(Exception e) {
			throw new CustomGenericException(CommonConstants.INTERNAL_SERVER_ERROR, e.getMessage());
		}
		return userRealmList;
		
	}
	
	@RequestMapping(value = "/trackSession", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public String sessionTrack(@RequestBody String userSSO) {
		String str = "";
		try {
			String decodedUserId = decodeSSO.getDecodedSSO(userSSO);
			System.out.println("Inside SessionTracking Method");
			documentService.updateAuditInfo("", "Login", "", decodedUserId, "SUCCESS",
					"User has been successfully loggedin");
			str = "User has been logged in";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return str;
	}
	
	 @Bean
	    public WebMvcConfigurer corsConfigurer() {
	        return new WebMvcConfigurerAdapter() {
	            @Override
	            public void addCorsMappings(CorsRegistry registry) {
	            	registry.addMapping("/**").allowedOrigins("*");
	            }
	        };
	    }

}
