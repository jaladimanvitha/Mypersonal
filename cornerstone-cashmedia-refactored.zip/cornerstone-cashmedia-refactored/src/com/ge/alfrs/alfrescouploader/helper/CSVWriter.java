package com.ge.alfrs.alfrescouploader.helper;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import org.apache.log4j.Logger;

/**
 * CSVWriter class is used for writing the data to a CSV file
 * 
 * @author mahindraSatyam, VS60636
 */

public class CSVWriter {
	
	private static Logger log = Logger.getLogger(CSVWriter.class);
	private FileWriter writer;
	
	/**
	 * constructor for initializing the CSVWriter class used to initialize the variables headerColumns & csvFilePath
	 * 
	 * @param headerColumns String
	 * @param csvFilePath String
	 */
	public CSVWriter(String headerColumns,String csvFilePath){
		File csvFile = null;
		
		log.info("CSV File Path received ====="+csvFilePath);
		
		try {
		    csvFile = new File(csvFilePath);
			writer = new FileWriter(csvFile, true);			
			if(csvFile.length()==0){
				writer.write(headerColumns+System.getProperty("line.separator"));
			}
			
		} catch (IOException exception) {
			log.error("Error while creating the CSV file: ",exception);
		}
		
	}
	
	/**
	 * writeRecordToCSV method is used for writing a record to the CSV file which is passed as the
	 * input parameter and returns a boolean stating whether the writing process is successful or not
	 * 
	 * @param record String
	 * @return boolean
	 */
	public boolean writeRecordToCSV(String record) {
		
		try {
			    
		   writer.write(record+System.getProperty("line.separator"));		
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		} finally {
			try {
				writer.flush();
				writer.close();
			} catch (IOException e) {
				log.error("Error while flushing and closing the file writer ",e);
			}
		}
		return true;

	}
}
