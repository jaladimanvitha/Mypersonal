import { ReportDropDown } from '../_models/ReportDropDown';
import { Component, OnInit } from '@angular/core';
import { ReportModel } from '../_models/ReportModel';
import { ReportDetails } from '../_models/ReportDetails';
import { InvoiceService } from '../_services';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from '../_services/dateformat';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css'],
  providers: [
    {provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter}
   ]
})
export class ReportsComponent implements OnInit {


  report: ReportModel = new ReportModel();
  reportids: ReportDropDown[] = [
    { id: 0, name: ''},
    { id: 1, name: 'ACHHEF10 - ACH SUMMARY REPORT FOR HEF'},
    { id: 2, name: 'ACHPAHEF - ACH REPORT FOR HEF PA'},
    { id: 3, name: 'ACHPANON - Summary report of current days Non-UBB ACH files in PA Region'},
    { id: 4, name: 'ACHPAUBB - Summary report of current days UBB ACH files in PA Region'},
    { id: 5, name: 'ACHPBNON - Summary report of current days Non-UBB ACH files in PB Region'},
    { id: 6, name: 'ACHPBUBB - Summary report of current days UBB ACH files in PB Region'},
    { id: 7, name: 'ACHUpdateCashReport'},
    { id: 8, name: 'CDKASSET - CDK Asset Report'},
    { id: 9, name: 'CDKFNCAN - Canada Funding data for CDK'},
    { id: 10, name: 'CDKFNIPN - IPNS funding data for CDK'},
    { id: 11, name: 'CDKFNSUM - Funding summary data for CDK'},
    { id: 12, name: 'CDKFNUSA - US Funding data for CDK'},
    { id: 13, name: 'CDKLEASE - CDK Active Lease/Loan Report'},
    { id: 14, name: 'CHECKHEF - CHECK REPORT FOR HEF PA'},
    { id: 15, name: 'COLCHGPA - Summary report of collateral codes changes of current day'},
    { id: 16, name: 'COLCHGPB - Summary report of collateral codes changes of current day'},
    { id: 17, name: 'DALYAUDT - Global Audit Report'},
    { id: 18, name: 'DECUMS02 - DECUM WIRE Funded report'},
    { id: 19, name: 'DECUMS03 - DECUM ACH Funded report'},

  ];
  public searchData:  Array<object> = [];
  submitted = false;
  searchModel: ReportDetails = new ReportDetails();
  reportModel: ReportModel = new ReportModel();

  constructor(private _invoiceService: InvoiceService) {
  }
  ngOnInit() {

  }

public  getSearchData() {

        this.searchModel.reportModel = this.reportModel;
        this._invoiceService.searchGeReports(this.searchModel).subscribe((data:  Array<object>) => {
        this.searchData  =  data['metadataList'];
        console.log('entered');
        // console.log(data);
        // console.log(this.searchModel);
            console.log(this.searchData);

    });
}
  onSubmit() {
    this.getSearchData();
    document.getElementById('displaytable').style.display = 'inline-table';
    return true;
  }
}
