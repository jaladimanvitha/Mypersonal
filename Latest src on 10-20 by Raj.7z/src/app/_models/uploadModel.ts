export class UploadModel {
  
  public fileName: string;
  public amount: string;
  public checkRequest: string;
  public check: string;
  public year: string;
  public documentName: string;
  public jusrisdiction: string;
 
}