package com.ge.alfrs.cashmedia.boadatatransformer.helper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import org.apache.log4j.Logger;

import com.ge.alfrs.cashmedia.boadatatransformer.constants.Constants;

/**
 * CSVWriter class is used to generate a CSV File.
 * 
 * @author CP97964
 * 
 */
public class CSVWriter {

	private static Logger log = Logger.getLogger(CSVWriter.class);

	int csvFileNumber = 0;
	int rowNumber = 0;

	/**
	 * writeRecordToCSV method is used to write the record data into the csv
	 * File
	 * 
	 * @param String
	 *            record
	 * @param String
	 *            filePath
	 * @return boolean
	 * @throws FileNotFoundException
	 */

	public boolean writeRecordToCSV(String record, String csvFilePath) {
		
		String csvHeaderLine;
		PrintWriter csvFileWriter = null;
		BufferedReader csvFileReader = null;
	
		try {

			File file = new File(csvFilePath);
			if (!file.exists()) {
				file = new File(csvFilePath);
			}
			csvFileWriter = new PrintWriter(new FileWriter(file, true));
			csvFileReader = new BufferedReader(new FileReader(file));
			
			csvHeaderLine = csvFileReader.readLine();

			if (csvHeaderLine == null || csvHeaderLine.equalsIgnoreCase("")) {
				csvFileWriter.print(Constants.METADATA_CSV_HEADERS+System.getProperty("line.separator"));
					}
				csvFileWriter.print(record+System.getProperty("line.separator"));
			
		} catch (Exception exception) {
			exception.printStackTrace();
			log.error("Error while writing the record data to CSV File, because of the error:"
							,  exception);
			return false;
			
		} finally {
			csvFileWriter.flush();
			csvFileWriter.close();
			csvFileReader = null;
		}
		return true;
	}
}
