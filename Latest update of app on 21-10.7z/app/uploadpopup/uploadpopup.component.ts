import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap';
import { CorptaxModel } from '../_models';
import { CorporationDropDown } from '../_models/corporationDropDown';
import { StatesDropDown } from '../_models/statesDropDown';
import { CountyDropDown } from '../_models/countyDropDown';
import { state } from '@angular/animations';

@Component({
  selector: 'app-uploadpopup',
  templateUrl: './uploadpopup.component.html',
  styleUrls: ['./uploadpopup.component.css']
})
export class UploadpopupComponent implements OnInit {

  title: string;
  corptaxModel: CorptaxModel = new CorptaxModel();
  corporations: CorporationDropDown[] = [

    { id: 0, name: '0-Unknown' },
    { id: 1, name: '001-GENERAL ELECTRIC CAPITAL CORPORATION' },
    { id: 2, name: '002-GENERAL ELECTRIC CREDIT CORP OF GA' },
    { id: 3, name: '003-GENERAL ELECTRIC CREDIT AND LEASING CORP' },
    { id: 4, name: '013-GENERAL ELECTRIC CREDIT CORP OF TENNESSE' },
    { id: 5, name: '014-GENERAL ELECTRIC CREDIT EQUITIES INC' },
    { id: 6, name: '016-FULL SERVICE LEASING CORPORATION' },

  ];
  states: StatesDropDown[] = [
    { id: 0, name: 'Chicago' },
    { id: 1, name: 'Texas' },
    { id: 2, name: 'New Jersey' },
    { id: 3, name: 'New York' },
    { id: 4, name: 'Florida' },
    { id: 5, name: 'Illinois' },
    { id: 6, name: 'Minnesota' },

  ];

  counties: CountyDropDown[];
  getCounty(Event) {

    const state: string = Event.target.value;
    switch (state) {
      case "New Jersey": {
        this.counties = [
          { id: 0, name: 'Atlantic county' },
          { id: 1, name: 'Bergen County' },
          { id: 2, name: 'Cape May County' },
        ];
        break;
      }
      case "Chicago": {
        this.counties = [
          { id: 0, name: 'Cook County' },
          { id: 1, name: 'Lake County' },
          { id: 2, name: 'Newton County' },
        ];
        break;
      }
      case "Texas": {
        this.counties = [
          { id: 0, name: 'Anderson County' },
          { id: 1, name: 'Bailey County' },
          { id: 2, name: 'Carson County' },
        ];
        break;
      }
      case "New York": {
        this.counties = [
          { id: 0, name: 'Albany County' },
          { id: 1, name: 'Bronx County' },
          { id: 2, name: 'Chemung County' },
        ];
        break;
      }
      case "Florida": {
        this.counties = [
          { id: 0, name: 'Baker County' },
          { id: 1, name: 'Bay County' },
          { id: 2, name: 'Citrus County' },
        ];
        break;
      }
      case "Illinois": {
        this.counties = [
          { id: 0, name: 'Will County' },
          { id: 1, name: 'DuPage County' },
          { id: 2, name: 'Cook County' },
        ];
        break;
      }
      case "Minnesota": {
        this.counties = [
          { id: 0, name: 'Anoka County' },
          { id: 1, name: 'Becker County' },
          { id: 2, name: 'Brown County' },
        ];
        break;
      }
      default: {
        this.counties = [
        ];
        break;
      }

    }
  }

  constructor(public bsModalRef: BsModalRef) { }
  ngOnInit() {
    sessionStorage.setItem('state', this.corptaxModel.state);
    sessionStorage.setItem('county', this.corptaxModel.county);
  }

  accept() {
    document.getElementById('display').style.display = 'block';
    sessionStorage.setItem('state', this.corptaxModel.state);
    sessionStorage.setItem('county', this.corptaxModel.county);
    this.bsModalRef.hide();
    console.log(this.corptaxModel.county);
    console.log(this.corptaxModel.state);
  }
}


