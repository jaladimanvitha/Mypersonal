
export class ReportsDropDown {

    public id: number;
    public name: string;
   
}
