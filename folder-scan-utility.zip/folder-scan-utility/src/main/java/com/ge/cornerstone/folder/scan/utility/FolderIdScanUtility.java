package com.ge.cornerstone.folder.scan.utility;

import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy.Type;
import java.util.Properties;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.box.sdk.BoxAPIConnection;
import com.box.sdk.BoxFolder;
import com.box.sdk.BoxItem;
import com.opencsv.CSVWriter;

/**
 * The FolderNavigationUtility program connects to the Ge-Box server with given
 * folder-id and extracts all the document id's and its names to the complete
 * level of folder depth and write them to a csv file.
 * 
 * @input should be defined in app-constants.properties file as example:
 *        folderIds=55532162174, comma i.e , is mandatory for single or multiple
 *        folder scans
 *
 * @author PadmaKiran Vajjala
 * @version 1.0
 * @since 2018-11-15
 */

public class FolderIdScanUtility {

	private static int cnt = 1;
	private static BoxAPIConnection api;
	private static Properties props = loadPropertiesFile("app-constants.properties");

	public static void main(String[] args) {

		CSVWriter writer = null;
		String folderIds[] = null;
		String folderIdStr = props.getProperty("folderIds");
		if (folderIdStr != null && folderIdStr.contains(",")) {
			folderIds = folderIdStr.split(",");
		}
		if (folderIds.length >= 1) {
			String f_path = props.getProperty("csvFilePath");
			FileWriter outputfile = null;
			try {
				outputfile = new FileWriter(f_path + "_folderDetails");
				writer = new CSVWriter(outputfile);
				String[] header = { "FolderId", "FolderName" };
				writer.writeNext(header);
			} catch (IOException ex) {
				// TODO Auto-generated catch block
				System.out.println(ex.getMessage());
			}
			try {
				for (int k = 0; k < folderIds.length; k++) {
					String folderId = folderIds[k];
					JSONObject akanaTokenJSON = generateAkanaAccessToken();
					String akanaToken = akanaTokenJSON.get("access_token").toString();
					JSONObject boxTokenJSON = generateBoxAccessToken(akanaToken);
					String boxToken = boxTokenJSON.get("accessToken").toString();
					if (!boxToken.isEmpty()) {
						// folder navigation
						scanFolder(folderId, boxToken, writer);
					}
				}

			} catch (Exception ex) {
				// TODO: handle exception
				System.out.println(ex.getMessage());
				String[] errMsg = { "Error occured", "something went wrong..." };
				writer.writeNext(errMsg);
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Error occured something went wrong...");
				System.exit(2);
			} finally {
				// closing writer connection
				try {
					writer.close();
				} catch (IOException ex) {
					// TODO Auto-generated catch block
					System.out.println(ex.getMessage());
				}
			}
		}

		System.out.println("Execution finished...");
	}

	public static void scanFolder(String folderId, String boxToken, CSVWriter writer) {
		// box connectivity
		try {
			api = new BoxAPIConnection(boxToken);
			java.net.Proxy proxy = new java.net.Proxy(Type.HTTP,
					new InetSocketAddress("PITC-Zscaler-Americas-Cincinnati3PR.proxy.corporate.ge.com", 80));
			api.setProxy(proxy);

			BoxFolder folder = new BoxFolder(api, folderId);
			System.out.println("scanning folderId: " + folderId);
			for (BoxItem.Info itemInfo : folder) {
				try {
					if (itemInfo instanceof BoxFolder.Info) {
						BoxFolder.Info folderInfo = (BoxFolder.Info) itemInfo;
						// Do something with the folder.
						System.out.println(cnt + ": " + "FolderId: " + folderInfo.getID() + ", FolderName: "
								+ folderInfo.getName());
						String[] csvData = { folderInfo.getID(), folderInfo.getName() };
						writer.writeNext(csvData);
						cnt += 1;
					}
				} catch (Exception ex) {
					// TODO: handle exception
					String[] errMsg = { "Error occured", "could not process all the folders..." };
					writer.writeNext(errMsg);
					writer.close();
					System.out.println("Error occured could not process all the folders...");
					System.exit(1);
				}

			}
		} catch (Exception ex) {
			// TODO: handle exception
			System.out.println(ex.getMessage());
		}
	}

	public static JSONObject generateAkanaAccessToken() {

		String akanaUrl = null;
		RestTemplate restTemplate = new RestTemplate();
		String akanaToken;

		akanaUrl = props.getProperty("akanaUri");
		// Send request with POST method and default Headers.
		ResponseEntity<String> respEntity = restTemplate.exchange(akanaUrl, HttpMethod.POST, null, String.class);
		akanaToken = respEntity.getBody();
		JSONObject jsonObject = (JSONObject) JSONValue.parse(akanaToken);
		return jsonObject;
	}

	public static JSONObject generateBoxAccessToken(String akanaAccessToken) {

		String boxAccessToken = null;
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + akanaAccessToken);
		String BOX_TOKEN_REQUEST = props.getProperty("boxTokenUri");
		HttpEntity<String> entityReq = new HttpEntity<String>(headers);
		ResponseEntity<String> respEntity = restTemplate.exchange(BOX_TOKEN_REQUEST, HttpMethod.GET, entityReq,
				String.class);
		boxAccessToken = respEntity.getBody();
		JSONObject jsonObject = (JSONObject) JSONValue.parse(boxAccessToken);
		return jsonObject;

	}

	public static Properties loadPropertiesFile(String resourceName) {

		Properties properties = new Properties();
		try {
			ClassLoader loader = Thread.currentThread().getContextClassLoader();

			InputStream resourceStream = loader.getResourceAsStream(resourceName);
			properties.load(resourceStream);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return properties;
	}

}
