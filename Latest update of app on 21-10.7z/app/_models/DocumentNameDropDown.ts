export class DocumentNameDropDown {

  public id: number;
  public name: string;
}
