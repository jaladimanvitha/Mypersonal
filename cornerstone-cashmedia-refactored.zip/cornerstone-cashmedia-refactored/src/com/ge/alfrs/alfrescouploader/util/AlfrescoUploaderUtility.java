package com.ge.alfrs.alfrescouploader.util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
//Removed CommonUtils import
import com.ge.alfrs.alfrescouploader.constants.Constants;
import com.ge.alfrs.alfrescouploader.helper.DocumentsUploadHelper;

/**
 * This class is the main class used for starting the upload utility for
 * uploading the documents into Alfresco.
 * 
 * @author mahindraSatyam, VS60636
 * @author mahindraSatyam, PV477886
 * 
 */
public class AlfrescoUploaderUtility {

	private static Logger log;
	private int dataTransModuleExitCode = 0;

	/**
	 * Constructor for AlfrescoUploaderUtility class
	 */
	public AlfrescoUploaderUtility(int dataTransModuleExitCode) {
		this.dataTransModuleExitCode = dataTransModuleExitCode;
		configureLogFilePath();
		log = Logger.getLogger(AlfrescoUploaderUtility.class);
		log.info("Exit code recieved by the ingestion utility is: " + dataTransModuleExitCode);
	}

	/**
	 * configureLogFilePath method is used for configuring the log file path
	 */
	public void configureLogFilePath() {
		String logFilePath;
		String dateStr;

		try {
			Date currentDate = new Date();
			SimpleDateFormat dateFormater = new SimpleDateFormat(Constants.LOG_FILENAME_DATEFORMAT);

			dateStr = dateFormater.format(currentDate);
			logFilePath = Constants.LOG_FILEPATH + "_" + dateStr + ".log";
			System.setProperty("log.home", logFilePath);
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	/**
	 * startIngestionProcess will initiate the upload process
	 * 
	 * @return boolean
	 */
	public boolean startIngestionProcess(String successCSVFilePath, String failureCSVFilePath,
			String metadataCSVFilesPath) {
		int exitCode = 0;
		boolean isFailureCSVGenerated = false;
		List<String> metadataCSVFilePathsList = null;
		DocumentsUploadHelper documentsUploadHelper = null;

		// removed CommonUtils class object cUtils instantiation that gets the
		// connection for FileNetP8

		try {
			// removed getting the targetObjStore code
			metadataCSVFilePathsList = getCSVFiles(metadataCSVFilesPath);
			if (metadataCSVFilePathsList == null || metadataCSVFilePathsList.size() == 0) {
				if (dataTransModuleExitCode > 0) {
					exitCode = Integer.parseInt(dataTransModuleExitCode + "" + Constants.EXITCODE_METADATACSV_NOTFOUND);
				} else {
					exitCode = Constants.EXITCODE_METADATACSV_NOTFOUND;
				}
				log.info("Exit with code: " + exitCode);
				System.exit(exitCode);
			}
			for (String metadataCSVFilePath : metadataCSVFilePathsList) {

				log.info("Begin of processing CSV file: " + metadataCSVFilePath);
				documentsUploadHelper = new DocumentsUploadHelper(successCSVFilePath, failureCSVFilePath,
						metadataCSVFilePath, metadataCSVFilesPath);

				documentsUploadHelper.ingestDocuments();
				isFailureCSVGenerated = documentsUploadHelper.isFailureCSVGenerated();

				log.info("_______________________End of CSV file processing___________________________");
			}

			if (isFailureCSVGenerated) {
				if (dataTransModuleExitCode > 0) {
					exitCode = Integer.parseInt(dataTransModuleExitCode + "" + Constants.EXITCODE_FAILURECSV_GENERATED);
				} else {
					exitCode = Constants.EXITCODE_FAILURECSV_GENERATED;
				}
			} else if (dataTransModuleExitCode > 0) {
				exitCode = dataTransModuleExitCode;
			}
			log.info("Exit with code: " + exitCode);
			System.exit(exitCode);

		} catch (Exception exception) {
			exception.printStackTrace();
			log.error("Error while starting the ingestion process beacuase of the error: ", exception);
		}
		return true;

	}

	/**
	 * getCSVFiles method is used for retrieving the CSV files from the
	 * directory path which is passed as a input parameter
	 * 
	 * @param metaDataCSVFilePath
	 *            String
	 * @return List<String>
	 */
	public List<String> getCSVFiles(String metaDataCSVFilesPath) {

		File[] listOfFiles = null;
		File metaDataCSVFolder = null;
		List<String> metaDataCSVFilePaths = null;
		try {
			metaDataCSVFilePaths = new ArrayList<String>();
			metaDataCSVFolder = new File(metaDataCSVFilesPath);

			listOfFiles = metaDataCSVFolder.listFiles();

			for (File csvFile : listOfFiles) {
				if (csvFile.isFile() && csvFile.getName().toLowerCase().endsWith(Constants.CSV_FILE_EXTENSION)) {
					metaDataCSVFilePaths.add(csvFile.getAbsolutePath());

				}
			}

		} catch (Exception exception) {
			exception.printStackTrace();
			log.error("Error while getting CSV Files because of the error : ", exception);
		}
		return metaDataCSVFilePaths;
	}

	/**
	 * Main method for the document uploader utility
	 * 
	 * @param args
	 *            String[]
	 */
	public static void main(String args[]) {

		// Refactored all the variables from p8 to alfresco convention
		AlfrescoUploaderUtility alfrescoUploaderUtility;
		alfrescoUploaderUtility = new AlfrescoUploaderUtility(0);
		if (args.length == 0) {
			alfrescoUploaderUtility.startIngestionProcess(Constants.SUCCESS_CSV_FILEPATH,
					Constants.FAILURE_CSV_FILEPATH, Constants.METADATA_CSV_FILESPATH);
		} else {
			alfrescoUploaderUtility.startIngestionProcess(args[0], args[1], args[2]);
		}
	}
}
