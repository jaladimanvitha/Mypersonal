
export class ReportsModel {

    public reportID: string;
    public reportDate: string;
    public reportRunDate: string;
    public jobNumber: string;
    public fileNetGuid: string;
    public name: string;
    public title: string;
    public creator: string;
    public modifier: string;
    public modifiedDate: string;
}
