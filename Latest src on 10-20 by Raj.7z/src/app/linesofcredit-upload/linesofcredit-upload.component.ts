import { Component, OnInit } from '@angular/core';
import { LinesofcreditUploadModel } from '../_models/LinesofcreditUploadModel';
import {Router, ActivatedRoute} from '@angular/router';
import { FileSelectDirective, FileUploader} from 'ng2-file-upload';
import { FormControl, NgForm, FormBuilder } from '@angular/forms';
import {NgbModal, ModalDismissReasons, NgbActiveModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-linesofcredit-upload',
  templateUrl: './linesofcredit-upload.component.html',
  styleUrls: ['./linesofcredit-upload.component.css']
})
export class LinesofcreditUploadComponent implements OnInit {

  modalReference: NgbModalRef;
   closeResult: string;
   linesOfCredit: LinesofcreditUploadModel = new LinesofcreditUploadModel();


public lineofcreditData = [
{
 "documentSubType" : "",
  "welcomePackage" : "",
  "syndicationPackage": "",
  "physicalStorageStatus": "",
  "fileName": "",
  "progress": "",
 
}];
  constructor(private modalService: NgbModal,private router:Router, private activatedRoute:ActivatedRoute){ }

  ngOnInit() {
   this.linesOfCredit.partyNumber3 = this.activatedRoute.snapshot.queryParamMap.get('partyNumber3');
    this.linesOfCredit.partyName3 = this.activatedRoute.snapshot.queryParamMap.get('partyName3');
     this.linesOfCredit.sfdcAccountId3 = this.activatedRoute.snapshot.queryParamMap.get('sfdcAccountId3');
       this.linesOfCredit.sfdcopportunityId3 = this.activatedRoute.snapshot.queryParamMap.get('sfdcopportunityId3');
        this.linesOfCredit.lineofcreditNumber3 = this.activatedRoute.snapshot.queryParamMap.get('lineofcreditNumber3');
         this.linesOfCredit.lineofBusinessCode3 = this.activatedRoute.snapshot.queryParamMap.get('lineofBusinessCode3');
          this.linesOfCredit.legalEntityName3 = this.activatedRoute.snapshot.queryParamMap.get('legalEntityName3');
  }

upload(userForm: NgForm) {
   if(userForm.form.value.docSubType3 == null) {
     alert('document SubType cannot be Empty');
     return false;
   }
   else{
     if(userForm.form.value.lineofcreditNumber3 == null){
     alert('Line of credit Number cannot be Empty');
     return false;
      }
   }
  console.log(userForm.form.value);
  return true;
  
  }
   open(content) {
   this.modalReference = this.modalService.open(content);
   this.modalReference.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }
  close() {
    this.modalReference.close();
     this.router.navigate(['/home']);
    }
}
