import { GecDocumentSearchModel } from '.';

export class GecDocumentSearchDetails {

    public docType = 'Gec';
    public gecDocModel: GecDocumentSearchModel;

}
