export class ManifestModel  {

    public createdBy: string;
    public modifiedBy: string;
    public createdDateFrom: string;
    public createdDateTo: string;
    public manifestSeqNumber: string;
    public createdFromDate: string;
    public createdToDate: string;
    public createdFromDate2: string;
    public createdToDate2: String;
}
