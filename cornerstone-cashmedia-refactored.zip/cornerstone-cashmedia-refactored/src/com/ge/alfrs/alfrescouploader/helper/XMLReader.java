package com.ge.alfrs.alfrescouploader.helper;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.ge.alfrs.alfrescouploader.constants.Constants;
import com.ge.alfrs.alfrescouploader.vo.XMLPropertyVO;
/**
 * This helper class is used to read the mappings XML file and convert the node values
 * into the XMLPropertyVO objects. 
 * 
 * @author mahindraSatyam, VS60636
 * 
 */
public class XMLReader {
	private static Logger logger = Logger.getLogger(XMLReader.class);
	
	/**
	 * getPropertyMappings method returns the Map contains all the mappings of document class name to 
	 * the list of properties present in the particular document class which are mentioned in the 
	 * Property Mapping XML file 
	 * 
	 * @return Map<String, List<XMLPropertyVO>>
	 */
	public Map<String, List<XMLPropertyVO>> getPropertyMappings() {

		Document xmlDocument = null;
		NodeList objStoreNodesList = null;
		NodeList classNodesList = null;
		Element objStoreElement = null;
		Element classElement = null;
		String objSt_ClassName = null;
		List<XMLPropertyVO> propertiesList = null;
		Map<String, List<XMLPropertyVO>> propertyMappings = null;

		xmlDocument = getXMLDocument();
		if (xmlDocument != null) {
			propertyMappings = new HashMap<String, List<XMLPropertyVO>>();
			objStoreNodesList = xmlDocument
					.getElementsByTagName("ObjectStore");
			for (int nodesCount = 0; nodesCount < objStoreNodesList.getLength(); nodesCount++) {
				objStoreElement = (Element) objStoreNodesList.item(nodesCount);
				classNodesList = objStoreElement.getElementsByTagName("Class");
				for (int classNodesCount = 0; classNodesCount < classNodesList
						.getLength(); classNodesCount++) {
					classElement = (Element) classNodesList
							.item(classNodesCount);
					objSt_ClassName = objStoreElement.getAttribute("name")
							+ ":" + classElement.getAttribute("ID");				
					propertiesList = getPropertiesVOList(classElement);
					propertyMappings.put(objSt_ClassName, propertiesList);
				}
			}

		} else {

		}
		return propertyMappings;
	}

	/**
	 * getPropertiesVOList method is used for returning the list of properties to a particular class
	 * in the form of XMLPropertyVO objects
	 * 
	 * @param classElement Element
	 * @return List<XMLPropertyVO>
	 */
	public List<XMLPropertyVO> getPropertiesVOList(Element classElement) {
		NodeList propertyNodeList = null;
		Element propertyElement = null;
		XMLPropertyVO xmlPropertyVO = null;
		List<XMLPropertyVO> propertiesVOList = null;
		propertyNodeList = classElement.getElementsByTagName("Property");
		propertiesVOList = new ArrayList<XMLPropertyVO>();
		for (int propertiesCount = 0; propertiesCount < propertyNodeList
				.getLength(); propertiesCount++) {
			propertyElement = (Element) propertyNodeList.item(propertiesCount);
			xmlPropertyVO = new XMLPropertyVO();
			xmlPropertyVO.setSymbolicName(propertyElement
					.getAttribute(Constants.ATTR_SYMBOLIC_NAME));
			xmlPropertyVO.setRule(propertyElement
					.getAttribute(Constants.ATTR_RULE));
			xmlPropertyVO.setValue(propertyElement
					.getAttribute(Constants.ATTR_VALUE));
			xmlPropertyVO.setMappedTo(propertyElement
					.getAttribute(Constants.ATTR_MAPPED_TO));
			xmlPropertyVO.setDataType(propertyElement
					.getAttribute(Constants.ATTR_DATATYPE));
			xmlPropertyVO.setCardinality(propertyElement
					.getAttribute(Constants.ATTR_CARDINALITY));
			xmlPropertyVO.setIsMandatory(propertyElement
					.getAttribute(Constants.ATTR_MANDATORY));			
			propertiesVOList.add(xmlPropertyVO);
		}

		return propertiesVOList;
	}

	/**
	 * getXMLDocument method is used for converting the xml file into the Document object
	 * 
	 * @return Document
	 */
	public Document getXMLDocument() {
		Document xmlDocument = null;
		String xmlFilePath = null;
		try {
			xmlFilePath = Constants.MAPPINGRULES_XMLFILEPATH;
			File file = new File(xmlFilePath);
			if (file.exists()) {
				// Create a factory
				DocumentBuilderFactory factory = DocumentBuilderFactory
						.newInstance();
				// Use the factory to create a builder
				DocumentBuilder builder = factory.newDocumentBuilder();
				xmlDocument = builder.parse(xmlFilePath);

			} else {
				logger.error("Mapping XML File not found!");
			}
		} catch (Exception e) {
			logger.error("Failed to read the Rules Xml Document");
			System.exit(-1);
		}
		return xmlDocument;

	}

}
