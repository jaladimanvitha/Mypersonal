package com.ge.alfrs.cashmedia.pncdatatransformer.constants;

import com.ge.alfrs.cashmedia.pncdatatransformer.constants.Messages;

	/**
	 This is the interface contains all the String constants which we 
	 have used in the application. In a Interface all the variables are by default public static final  */


	public interface Constants {	
	
		public static final String LOG_FILEPATH = Messages.getString("logFilePath");
		public static final String LOG_FILENAME_DATEFORMAT = Messages.getString("logFileNameDateFormat");
		
	    public static final String LOCKBOX_PATH =Messages.getString("LOCKBOX_PATH");
		public static final String REQUIRED_CSV_PROPERTY_NAMES = Messages.getString("REQUIRED_CSV_PROPERTY_NAMES");
		public static final String CSV_FILEPATH_TO_WRITE= Messages.getString("CSV_FILEPATH_TO_WRITE");
		
		public static final String COMMA_SEPERATOR = Messages.getString("COMMA_SEPERATOR");
		public static final String SEMICOLON_SEPERATOR = Messages.getString("SEMICOLON_SEPERATOR");
		public static final String CURRENT_DATE_FORMAT = Messages.getString("CURRENT_DATE_FORMAT");
		public static final String CSV_EXTENSION=Messages.getString("CSV_EXTENSION");
	    public static final String DETAILS_CSV_FILENAME =Messages.getString("DETAILS_CSV_FILENAME");
	    public static final String METADATA_CSV_FILE =Messages.getString("METADATA_CSV_FILE");
	    public static final int DETAILS_CSV_HEADERS_COUNT = Integer.parseInt(Messages.getString("DETAILS_CSV_HEADERS_COUNT"));
	    public static final boolean IGNORE_NODATA_LOCKBOXES = Boolean.parseBoolean(Messages.getString("IGNORE_NODATA_LOCKBOXES"));	    
	    
	    public static final String CSV_COL_MULTIIVALUEDENTIFIER =Messages.getString("CSV_COL_MULTIIVALUEDENTIFIER");
	    public static final String CSV_MULTIVALUED_COLUMNNAMES = Messages.getString("CSV_MULTIVALUED_COLUMNNAMES");
	    public static final String CSV_MULTIVALUED_COLUMNNAMES_SEPARATOR = Messages.getString("CSV_MULTIVALUED_COLUMNNAMES_SEPARATOR");
	    
	    public static final boolean ISOBFUSCATION_REQUIRED = Boolean.parseBoolean(Messages.getString("ISOBFUSCATION_REQUIRED"));
	    
	    public static final String SUCCESS_CSV_FILEPATH = Messages.getString("SUCCESS_CSV_FILEPATH");
		public static final String FAILURE_CSV_FILEPATH = Messages.getString("FAILURE_CSV_FILEPATH");
		public static final String METADATA_CSV_FILESPATH = Messages.getString("METADATA_CSV_FILESPATH");
		
		public static final String CSV_COL_CheckImage = Messages.getString("CSV_COL_CheckImage");
		public static final String CSV_COL_EnvelopeImage =Messages.getString("CSV_COL_EnvelopeImage");
		public static final String CSV_COL_InvoiceImage=Messages.getString("CSV_COL_InvoiceImage");
		public static final String PNC_ImagesFolderName = Messages.getString("PNC_ImagesFolderName");
		public static final String Date_Name = Messages.getString("Date_Name");
		public static final String PNC_ImageExtension =Messages.getString("PNC_ImageExtension");
		public static final String CSV_COL_SourceBankName = Messages.getString("CSV_COL_SourceBankName");
		public static final String CSV_COL_SerialNumber = Messages.getString("CSV_COL_SerialNumber");
		public static final String CSV_COL_ABA = Messages.getString("CSV_COL_ABA");
		public static final String CSV_RecordsLimit =Messages.getString("CSV_RecordsLimit");
		public static final String CSV_COL_TargetDC =Messages.getString("CSV_COL_TargetDC");
		public static final String CSV_COL_InvoiceNumber = Messages.getString("CSV_COL_InvoiceNumber");
		public static final String CSV_COL_AccountNumber = Messages.getString("CSV_COL_AccountNumber");
		public static final String CSV_COL_AllPageImages = Messages.getString("CSV_COL_AllPageImages");
		public static final String CSV_TO_PROPERTIES_MAPPING = Messages.getString("CSV_TO_PROPERTIES_MAPPING");
		public static final String CSV_TO_PROPERTIES_MAP_SEPERATOR = Messages.getString("CSV_TO_PROPERTIES_MAP_SEPERATOR");
		public static final String CSV_TO_PROPERTIES_VALUE_SEPERATOR = Messages.getString("CSV_TO_PROPERTIES_VALUE_SEPERATOR");
		
		
		public static final String COLUMN_VALUES_TOBE_DEFAULTED = Messages.getString("COLUMN_VALUES_TOBE_DEFAULTED");
		public static final String COLUMN_VALUES_TO_ELIMINATE_TRAILINGZEROS = Messages.getString("COLUMN_VALUES_TO_ELIMINATE_TRAILINGZEROS");
		public static final String COLUMN_VALUES_TOBE_DEFAULTED_SEPARATOR = Messages.getString("COLUMN_VALUES_TOBE_DEFAULTED_SEPARATOR");
		public static final String COLUMN_VALUES_TOBE_DEFAULTED_VALUESEPARATOR = Messages.getString("COLUMN_VALUES_TOBE_DEFAULTED_VALUESEPARATOR");
		public static final String COLUMN_VALUES_TO_ELIMINATE_TRAILINGZEROS_SEPARATOR = Messages.getString("COLUMN_VALUES_TO_ELIMINATE_TRAILINGZEROS_SEPARATOR");
		
		public static final String CSV_COL_CheckNumber = Messages.getString("CSV_COL_CheckNumber");
		public static final String CSV_COL_CheckAmount = Messages.getString("CSV_COL_CheckAmount");
		public static final String METADATA_CSV_HEADERS = Messages.getString("METADATA_CSV_HEADERS");
		
		public static final int EXITCODE_ROOTFOLDER_NOTFOUND = Integer.parseInt(Messages.getString("EXITCODE_ROOTFOLDER_NOTFOUND"));
		public static final int EXITCODE_NOLOCKBOXS = Integer.parseInt(Messages.getString("EXITCODE_NOLOCKBOXS"));
		public static final int EXITCODE_CSVHEADERS_INCORRECT = Integer.parseInt(Messages.getString("EXITCODE_CSVHEADERS_INCORRECT"));
		public static final int EXITCODE_CSVRECORDS_PROCESSERRORS = Integer.parseInt(Messages.getString("EXITCODE_CSVRECORDS_PROCESSERRORS"));
		public static final int EXITCODE_DETAILCSV_NOTFOUND = Integer.parseInt(Messages.getString("EXITCODE_DETAILCSV_NOTFOUND"));
		public static final int EXITCODE_METADATACSV_NOTGENERATED = Integer.parseInt(Messages.getString("EXITCODE_METADATACSV_NOTGENERATED"));
		public static final int EXITCODE_CSVFILE_READISSUES = Integer.parseInt(Messages.getString("EXITCODE_CSVFILE_READISSUES"));
		
		
		public static final String IMAGE_COUNT_ERROR_MSG_2 = Messages.getString("IMAGE_COUNT_ERROR_MSG_2");
		public static final String AMOUNT_ERROR_MSG = Messages.getString("AMOUNT_ERROR_MSG");
		public static final String CHECK_COUNT_ERROR_MSG = Messages.getString("CHECK_COUNT_ERROR_MSG");
		public static final String SUBJECT_AUDIT_ERR_MSG = Messages.getString("SUBJECT_AUDIT_ERR_MSG");
		public static final String FROM_ADDRESS = Messages.getString("FROM_ADDRESS");
		public static final String TO_ADDRESS = Messages.getString("TO_ADDRESS");
		public static final String SMTPHOST = Messages.getString("SMTPHOST");
		
		public static final String IMAGE_DIRECTORY_MISSING = Messages.getString("IMAGE_DIRECTORY_MISSING");
		public static final String ALL_FILES_MISSING = Messages.getString("ALL_FILES_MISSING");
		public static final String INFOTXT_MISSING = Messages.getString("INFOTXT_MISSING");
		public static final String IMAGE_FILES_MISSING = Messages.getString("IMAGE_FILES_MISSING");
		public static final String BOXNUMBER_CSV_MISSING = Messages.getString("BOXNUMBER_CSV_MISSING");
		
	    
		
	
	}


