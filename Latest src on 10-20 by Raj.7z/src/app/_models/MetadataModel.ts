export class MetadataModel {

    public billingId: string;
    public customerName: string;
    public documentName: string;
    public documentTitle: string;
    public dueDate: string;
    public fileDate: string;
    public fileName: string;
    public folder: string;
    public invoiceDate: string;
    public invoiceNumber: string;
    public invoiceFolder: string;
    public transactionIdm: string;
    public customerNumber: string;
    public invoiceType: string;
    public accountNumber: string;
    public interestYear: string;
    public transactionId: string;
    public fileNetGuid: string;
    public name: string;
    public title: string;

}
