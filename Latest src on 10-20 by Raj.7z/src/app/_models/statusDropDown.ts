export class StatusDropDown {

  public id: number;
  public name: string;
}
