package com.ge.capital.dms.dao;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.ge.capital.dms.utility.DmsUtilityConstants;
import com.ge.capital.dms.utility.DmsUtilityService;


@Component
@Configuration
@EnableTransactionManagement
public class SearchDAO {

	@PersistenceUnit
	private EntityManagerFactory emf;

	@Autowired
	private DmsUtilityService dmsUtilityService;

	@Transactional
	@SuppressWarnings("unchecked")
	public List<HashMap<String, String>> searchMetadata(String docType, Map<String, String> inputMetadataMap) {
		boolean flag = false;
		System.out.println("Entering invoiceSearch() in DAO...");
		EntityManager em = emf.createEntityManager();
		HashMap<String, String> resultMap = null;
		List<HashMap<String, String>> resultMetadataList = null;
		
		try {
			Properties props = dmsUtilityService.loadPropertiesFile(DmsUtilityConstants.docTypeMappingResource);
			//Set<String> inputKeys = inputMetadataMap.keySet();
			String documentType = docType;
			String selectKey = documentType + ".select.clause";
			String fromKey = documentType + ".from.clause";
			String whereKey = documentType + ".where.clause";
			
			String orderByKey = documentType + ".orderBy.clause";
			String searchQuery = props.getProperty(selectKey) + " " + props.getProperty(fromKey) + " "
					+ props.getProperty(whereKey);
			String fromDate = "";
			String toDate = "";
			for(Map.Entry<String,String> entry : inputMetadataMap.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();
				if (key.contains("minYear"))
					searchQuery = searchQuery + " AND " + props.getProperty(documentType + "." + key) + ">=:" + key;
				else if (key.contains("maxYear"))
					searchQuery = searchQuery + " AND " + props.getProperty(documentType + "." + key) + "<=:" + key;
				else if (key.contains("minAmount"))
					searchQuery = searchQuery + " AND " + props.getProperty(documentType + "." + key) + ">=:" + key;
				else if (key.contains("maxAmount"))
					searchQuery = searchQuery + " AND " + props.getProperty(documentType + "." + key) + "<=:" + key;
				else if (key.contains("FromDate") || key.contains("DateFrom")) {
					fromDate = value;
					if(!toDate.isEmpty()) {
						if(!toDate.equals(value)) {
							searchQuery = searchQuery + " AND " + props.getProperty(documentType + "." + key) + ">=:" + key;
						} else {
							flag = true;
							searchQuery = searchQuery + " AND " + props.getProperty(documentType + "." + key) + " >= cast(:" + key + " as date) AND "+ props.getProperty(documentType + "." + key) +"< cast(:nextDate as date)";	
						}
					} else
						searchQuery = searchQuery + " AND " + props.getProperty(documentType + "." + key) + ">=:" + key;
				}
				else if (key.contains("ToDate") || key.contains("DateTo")) {
					toDate = value;
					if(!fromDate.isEmpty()) {
						if(!fromDate.equals(value)) {
							searchQuery = searchQuery + " AND " + props.getProperty(documentType + "." + key) + "<=:" + key;
						} else {
							flag = true;
							searchQuery = searchQuery + " AND " + props.getProperty(documentType + "." + key) + " >= cast(:" + key + " as date) AND "+ props.getProperty(documentType + "." + key) +"< cast(:nextDate as date)";
						}
					} else 
						searchQuery = searchQuery + " AND " + props.getProperty(documentType + "." + key) + "<=:" + key;
				}
				else if ((key.toLowerCase().contains("date") || key.equals("interestYear")) && !(key.toLowerCase().contains("from") || key.toLowerCase().contains("to"))) {
					flag = true;
					searchQuery = searchQuery + " AND " + props.getProperty(documentType + "." + key) + " >= cast(:" + key + " as date) AND "+ props.getProperty(documentType + "." + key) +"< cast(:nextDate as date)";
				}
				else if (value.contains("*")) {	
					inputMetadataMap.put(key,value.replace("*",""));
					searchQuery = searchQuery + " AND " + props.getProperty(documentType + "." + key) + " like concat('%',:" + key + ",'%')";
					
				} else if (key.contains("checkamount")) {
					System.out.println("Value in Check Amount:"+ value);
					float checkAmount = Float.parseFloat(value);
					searchQuery = searchQuery + " AND " + props.getProperty(documentType + "." + key)
					+ " like " + checkAmount;
				}				
				else {
					System.out.println("Key :"+key +" Value : "+value);
					searchQuery = searchQuery + " AND " + props.getProperty(documentType + "." + key) + "=:" + key;
				}
			}

			if (props.getProperty(orderByKey) != null) {
				searchQuery = searchQuery + " " + props.getProperty(orderByKey);
			}
			Query invoicesearchQuery = em.createQuery(searchQuery);
			
			// set the named query values for the metadata inputs
			for (final Iterator iter = inputMetadataMap.entrySet().iterator(); iter.hasNext();) {
				Map.Entry entry = (Entry) iter.next();
				final String key = (String) entry.getKey();
				
				System.out.println(inputMetadataMap.get(key)+" Value inside the key");
				
				try {
					if (key.toLowerCase().contains("date") || key.equalsIgnoreCase("interestYear")) {
							//if(key.equalsIgnoreCase("DateLoaded")) {
								final String ISO_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
								final SimpleDateFormat sdf = new SimpleDateFormat(ISO_FORMAT);
								final String input_format = "yyyy/MM/dd";
								final SimpleDateFormat ipformat = new SimpleDateFormat(input_format);
								java.util.Date date = (java.util.Date) ipformat.parse(inputMetadataMap.get(key));
								String convertedDate = sdf.format(date);
								invoicesearchQuery.setParameter(key,Timestamp.valueOf(convertedDate));
								if(flag) {
									Calendar c = Calendar.getInstance();
									c.setTime(ipformat.parse(ipformat.format(date)));
									c.add(Calendar.DATE, 1);
									invoicesearchQuery.setParameter("nextDate",Timestamp.valueOf(sdf.format(c.getTime())));
								}
							//} else {
								//String oldDate = inputMetadataMap.get(key);
								//java.util.Date date1 = new SimpleDateFormat("yyyy/MM/dd").parse(convertedDate);
								//System.out.println("some random format "+ date1);
								//invoicesearchQuery.setParameter(key, date, TemporalType.DATE);
							//}
					} else if(!key.contains("checkamount")) {
						invoicesearchQuery.setParameter(key, inputMetadataMap.get(key));
						System.out.println("Search Query :"+invoicesearchQuery);
					}						
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			invoicesearchQuery.setFirstResult(0);
			//invoicesearchQuery.setMaxResults(Integer.parseInt(props.getProperty("max-result-set")));
			invoicesearchQuery.setMaxResults(500);
			List<Object[]> invSrchResLst = invoicesearchQuery.getResultList();

			resultMetadataList = new ArrayList<HashMap<String, String>>();

			String respMtdAttrString = props.getProperty(documentType + ".metadata.respAttr");
			if (respMtdAttrString != null) {
				String respMtdAttrArry[] = respMtdAttrString.split(",");
				int respMtdAttrSize = respMtdAttrArry.length;

				// setting the search result
				for (Object[] obj : invSrchResLst) {
					resultMap = new HashMap<String, String>();
					for (int index = 0; index < respMtdAttrSize; index++) {
						if (obj[index] instanceof Date)
							resultMap.put(respMtdAttrArry[index],
									new SimpleDateFormat("MM/dd/YYYY").format((java.util.Date) obj[index]));
						else if (obj[index] instanceof Timestamp) {
							resultMap.put(respMtdAttrArry[index],
									new SimpleDateFormat("MM/dd/YYYY HH:mm:ss").format((java.util.Date) obj[index]));
						} else if (obj[index] instanceof Float) {
							resultMap.put(respMtdAttrArry[index], String.valueOf(obj[index]));
						} else
							resultMap.put(respMtdAttrArry[index], (String) obj[index]);
					}
					resultMetadataList.add(resultMap);
				}
			}
		} catch (NullPointerException e) {
			// TODO: handle exception
			System.out.println("Failed to obtain the search result");
			e.printStackTrace();

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Failed to obtain the search result");
			e.printStackTrace();

		} finally {
			System.out.println("Inside Finally block");
			//System.out.println("Result Metadata inside Finally Block: "+resultMetadataList);
			em.close();
		}
		//System.out.println("Size of Result: "+resultMetadataList.size());
		System.out.println("Result Metadata List: "+resultMetadataList);
		return resultMetadataList;
	}

}
