import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HFSdocumentComponent } from './hfsdocument.component';

describe('HFSdocumentComponent', () => {
  let component: HFSdocumentComponent;
  let fixture: ComponentFixture<HFSdocumentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HFSdocumentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HFSdocumentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
