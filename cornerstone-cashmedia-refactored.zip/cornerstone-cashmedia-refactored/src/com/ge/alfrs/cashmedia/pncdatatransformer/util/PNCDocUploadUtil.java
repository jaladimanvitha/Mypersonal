package com.ge.alfrs.cashmedia.pncdatatransformer.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.ge.alfrs.alfrescouploader.util.AlfrescoUploaderUtility;
import com.ge.alfrs.cashmedia.pncdatatransformer.constants.Constants;
import com.ge.alfrs.cashmedia.pncdatatransformer.helper.PNCDocUploadHelper;

/**
 * PNCDocUploadUtil class is used to generate a csvFile based on the required
 * properties
 * 
 * @author CP97964
 * 
 */

public class PNCDocUploadUtil {

	private static Logger log;

	
	/**
	 * configureLogFilePath method is used for configuring the log file path
	 */
	public static void configureLogFilePath(){
		String logFilePath;
		String dateStr;
		
		try{ 
			Date currentDate = new Date();
			SimpleDateFormat dateFormater = new SimpleDateFormat(Constants.LOG_FILENAME_DATEFORMAT);
			dateStr = dateFormater.format(currentDate);
			logFilePath = Constants.LOG_FILEPATH + "_" + dateStr + ".log";		
			System.setProperty("log.home", logFilePath);	
		} catch(Exception exception){
			log.error("Error occured while configuring logfile path" + exception);
		}
	}
	
	public static void main(String[] args) {
	
		//Refactored all the variables from p8 to alfresco convention
		
		boolean isMetaDataGenerated = false;
		boolean isalfrescoUploadUtilToBeInitiated = true;
		
		PNCDocUploadHelper pncDocHelper = null;
		AlfrescoUploaderUtility alfrescoUploaderUtility = null;	
		configureLogFilePath();
		log = Logger.getLogger(AlfrescoUploaderUtility.class);
	
		pncDocHelper = new PNCDocUploadHelper();
		isMetaDataGenerated = pncDocHelper.processDocuments();
		
		if(args.length > 0) {
			isalfrescoUploadUtilToBeInitiated = args[0].equalsIgnoreCase("true") ? true : false;
		}
		
		if(isMetaDataGenerated){
			log.info("Converstion process ended......"+isMetaDataGenerated);		
			if(isalfrescoUploadUtilToBeInitiated){
				alfrescoUploaderUtility = new AlfrescoUploaderUtility(pncDocHelper.getExitCode());
				alfrescoUploaderUtility.startIngestionProcess(Constants.SUCCESS_CSV_FILEPATH,Constants.FAILURE_CSV_FILEPATH,Constants.METADATA_CSV_FILESPATH);
			}
		} else{
			log.info("Metadata CSV file is not generated");
			System.exit(Constants.EXITCODE_METADATACSV_NOTGENERATED);
		}
	}
}

