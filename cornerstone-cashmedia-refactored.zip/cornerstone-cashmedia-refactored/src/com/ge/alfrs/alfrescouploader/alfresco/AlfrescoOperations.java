package com.ge.alfrs.alfrescouploader.alfresco;

//removed filenet imports
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
//import com.filenet.api.property.Property;
import com.ge.alfrs.alfrescouploader.common.Lockbox;
import com.ge.alfrs.alfrescouploader.constants.Constants;
import com.ge.alfrs.alfrescouploader.helper.PDFGenerator;
import com.ge.alfrs.alfrescouploader.vo.XMLPropertyVO;
import com.ge.alfrs.cashmedia.utilities.CashMediaUtilityService;

/**
 * This class is used to upload the document into Alfresco and to perform
 * alfresco operations
 * 
 * @author mahindraSatyam, VS60636
 * @author mahindraSatyam, PV477886
 * 
 */

public class AlfrescoOperations {

	private int pages = 0;
	private String sourceBankName;
	private String errorMessage;
	private Map<String, String> dataMap;
	private Map<String, String> displayValuesMap;
	private List<XMLPropertyVO> xmlPropertiesList;
	private CashMediaUtilityService cashMediaUtilityService;
	private String FolderName = null;
	private static Logger log = Logger.getLogger(AlfrescoOperations.class);

	/**
	 * Constructor for initializing required variables
	 * 
	 * @param resultSetMap      Map<String,String>
	 * @param xmlPropertiesList List<XMLPropertyVO>
	 * @param sourceBankName    String
	 */
	public AlfrescoOperations(Map<String, String> dataMap, List<XMLPropertyVO> xmlPropertiesList, String sourceBankName,
			String targetDC, List<Lockbox> list) {
		this.dataMap = dataMap;
		this.xmlPropertiesList = xmlPropertiesList;
		this.sourceBankName = sourceBankName;
		dataMap.get(Constants.CSV_COL_CheckNumber);
		// new ArrayList<Property>();
		displayValuesMap = new HashMap<String, String>();
		this.cashMediaUtilityService = new CashMediaUtilityService();

		for (String name : dataMap.keySet()) {

			if (name.equalsIgnoreCase("Check Image")) {
				String nameValue = dataMap.get(name);
				log.info("Name Value "+nameValue);
				FolderName = getDate(nameValue);
			}
			log.info("Datamap values read from CSV :" + name + " :: " + dataMap.get(name));
			//log.info("Datamap values read from CSV :" + name + " :: " + dataMap.get(name));
		}

		for (XMLPropertyVO name : xmlPropertiesList) {
			log.info("xmlPropertiesList values read from CSV :" + name.getSymbolicName() + " :: " + name.getMappedTo());
		}

	}

	public String getDate(String filename) {
		String finalValue = "";
	//	String[] myString = filename.split("_");
	//	String dateValue = (myString[myString.length - 1]).substring(0, 6);
		String name = filename.split("CIS_LEASEWAVE_PNC_USD_CHKIMG.*_")[1];
		
		String dateValue = name.substring(0, 6);

		try {

			String year = dateValue.substring(0, 2);
			String month = dateValue.substring(2, 4);
			String day = dateValue.substring(4, 6);
			Date date = new SimpleDateFormat("MM-dd-yy").parse(month + "-" + day + "-" + year);
			finalValue = new SimpleDateFormat("MM-dd-yyyy").format(date);
			//log.info("DateLoaded :"+finalValue);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return finalValue;
	}

	/**
	 * Getter method for making the errorMessage veriable accessible by other
	 * classes
	 * 
	 * @return String
	 */
	public String getErrorMesage() {
		return errorMessage;
	}

	/**
	 * ingestDocument method is used for preparing the document for the ingestion
	 * process by populating the properties according to the configurations made in
	 * the Properties Mapping XML file
	 * 
	 * @return boolean
	 */
	public boolean ingestDocument() {

		boolean uploadStatus = false;
		boolean isPopulated = false;
		boolean isImagePathData = false;

		String documentTitle = "";
		String mappedToColumnName = null;
		String imageColumnData = null;
		String offSetData = "";

		InputStream contentInputStream = null;
		

		for (XMLPropertyVO xmlProperty : xmlPropertiesList) {
			log.info("Rule :"+xmlProperty.getRule());
			xmlProperty.getSymbolicName();
			if (xmlProperty.getRule().equalsIgnoreCase(Constants.RULE_DEFAULT)) {
				// removed populateDefaultValues() that sets data from xml to Filenet property
				// values
				isPopulated = setMetaData(xmlProperty);
				if (!isPopulated) {
					break;
				}
			} else if (xmlProperty.getRule().equalsIgnoreCase(Constants.RULE_CSV)) {
				// removed populateMappedValues() that sets data retrieved from database to
				// FileNet Property values
				isPopulated = setMetaData(xmlProperty);
				if (!isPopulated) {
					break;
				}
			} else if (xmlProperty.getRule().equalsIgnoreCase(Constants.RULE_DISPLAY)) {
				// removed populateDisplayValues() that sets multivalued property value to the
				// FileNet Property values
				isPopulated = setMetaData(xmlProperty);
				if (!isPopulated) {
					break;
				}
			} else if (xmlProperty.getRule().equalsIgnoreCase(Constants.RULE_CONTENT)) {
				pages = 0;
				String lockBoxNo = dataMap.get(Constants.CSV_COL_LOCKBOXNUMBER);
				mappedToColumnName = xmlProperty.getMappedTo();
				// box upload code changes by kiran
				if (mappedToColumnName != null && !mappedToColumnName.isEmpty()) {
					System.out.println("Lockbox-Info: " + dataMap.get(mappedToColumnName));
					String dL = StringUtils.substring(
							StringUtils.substringBetween(dataMap.get(mappedToColumnName), "CHKIMG_", ".zip"), 0, 6);
					System.out.println("dL: " + dL);
					SimpleDateFormat sdfr = new SimpleDateFormat("MM/dd/YYYY");
					if (dL != null && !dL.isEmpty()) {
						System.out.println("month: "+dL.substring(2, 4));
						System.out.println("day: "+dL.substring(4, 6));
						System.out.println("year: "+dL.substring(0, 2));
						String dateLoaded = sdfr.format(
								new Date(dL.substring(2, 4) + "/" + dL.substring(4, 6) + "/" + dL.substring(0, 2)));
						log.info("Date Loaded "+dateLoaded);
						displayValuesMap.put("gecap_date_loaded", dateLoaded.replaceAll("/", "-"));
					}
				}
				// --
				if (mappedToColumnName.equals(Constants.CSV_COL_CheckImage)) {
					displayValuesMap.put("gecap_image_type", mappedToColumnName);
					imageColumnData = dataMap.get(Constants.CSV_COL_CheckImage);
					if (imageColumnData != null && imageColumnData.trim().length() > 0) {
						documentTitle = sourceBankName + "_" + dataMap.get(Constants.CSV_COL_LOCKBOXNUMBER) + "_"
								+ dataMap.get(Constants.CSV_COL_CheckNumber) + "_"
								+ Constants.FN_DOCTITLE_CHECK_CONSTANT + "_";
						pages = imageColumnData.split(Constants.CSV_VALUE_SEPARATOR).length;
					}
				} else if (mappedToColumnName.equals(Constants.CSV_COL_EnvelopeImage)) {
					displayValuesMap.put("gecap_image_type", mappedToColumnName);
					imageColumnData = dataMap.get(Constants.CSV_COL_EnvelopeImage);
					if (imageColumnData != null && imageColumnData.trim().length() > 0) {
						documentTitle = sourceBankName + "_" + dataMap.get(Constants.CSV_COL_LOCKBOXNUMBER) + "_"
								+ dataMap.get(Constants.CSV_COL_CheckNumber) + "_"
								+ Constants.FN_DOCTITLE_ENVELOPE_CONSTANT + "_";
						pages = imageColumnData.split(Constants.CSV_VALUE_SEPARATOR).length;
					}
				} else if (mappedToColumnName.equals(Constants.CSV_COL_InvoiceImage)) {
					displayValuesMap.put("gecap_image_type", Constants.CSV_COL_RFC_Remittance);
					imageColumnData = dataMap.get(Constants.CSV_COL_InvoiceImage);
					if (imageColumnData != null && imageColumnData.trim().length() > 0) {
						documentTitle = sourceBankName + "_" + dataMap.get(Constants.CSV_COL_LOCKBOXNUMBER) + "_"
								+ dataMap.get(Constants.CSV_COL_CheckNumber) + "_"
								+ Constants.FN_DOCTITLE_REMITTANCE_CONSTANT + "_";
						pages = imageColumnData.split(Constants.CSV_VALUE_SEPARATOR).length;
					}
				} else if (mappedToColumnName.equals(Constants.CSV_COL_Image_Path)) {
					imageColumnData = dataMap.get(Constants.CSV_COL_Image_Path);
					if (imageColumnData != null && imageColumnData.trim().length() > 0) {
						documentTitle = sourceBankName + "_" + dataMap.get(Constants.CSV_COL_LOCKBOXNUMBER) + "_"
								+ dataMap.get(Constants.CSV_COL_CheckNumber) + "_"
								+ Constants.FN_DOCTITLE_CHECK_CONSTANT + "_";
						isImagePathData = true;
						pages = 1;
					}
				}
				if (pages > 0) {
					if (isImagePathData) {

						contentInputStream = generateContentInputStream(xmlProperty, false, true);
					} else {

						contentInputStream = generateContentInputStream(xmlProperty, true, false);
					}
					if (contentInputStream != null && isPopulated) {
						// if condition is modified that checks SourceType from filenet obj
						// targetDocumentProperties
						if (displayValuesMap.get("gecap_sourceType").equals(Constants.BANK_SOURCETYPE_RBC)) {
							imageColumnData = imageColumnData.substring(0,
									imageColumnData.indexOf(Constants.CSV_VALUE_SEPARATOR));
							imageColumnData = imageColumnData.substring(imageColumnData.lastIndexOf(File.separator) + 1,
									imageColumnData.length());
							imageColumnData = imageColumnData.replaceAll(Constants.RBC_CONS_IMAGEEXTENTION_REPLACER,
									"_");
							offSetData = dataMap.get(xmlProperty.getMappedTo());
							if (offSetData != null && offSetData.length() > 0) {
								offSetData = offSetData.substring(
										offSetData.indexOf(Constants.RBC_CONS_OFFSETDATA_STARTCHAR) + 1,
										offSetData.indexOf(Constants.RBC_CONS_OFFSETDATA_ENDCHAR));
								offSetData = "_" + offSetData.replace(Constants.CSV_VALUE_SEPARATOR, "_");
							} else {
								offSetData = "";
							}
							documentTitle += imageColumnData + offSetData + ".pdf";
						} else if (pages > 1 && !isImagePathData) {
							imageColumnData = imageColumnData.substring(0,
									imageColumnData.indexOf(Constants.CSV_VALUE_SEPARATOR));
							imageColumnData = imageColumnData.substring(imageColumnData.lastIndexOf(File.separator) + 1,
									imageColumnData.length());
							imageColumnData = imageColumnData.substring(0, imageColumnData.lastIndexOf("."));
							documentTitle += imageColumnData + ".pdf";
						} else {
							imageColumnData = imageColumnData.substring(imageColumnData.lastIndexOf(File.separator) + 1,
									imageColumnData.length());
							imageColumnData = imageColumnData.substring(0, imageColumnData.lastIndexOf("."));
							documentTitle += imageColumnData + ".pdf";
						}
						JSONObject json = new JSONObject();
						json.putAll(displayValuesMap);
						json.remove("gecap_sourceType");
						try {
							for (String name : displayValuesMap.keySet()) {
								log.info("displayValuesMap values sent for alfresco Upload :" + name + " :: "
										+ displayValuesMap.get(name));
							}

							// service call to CashMedia utility that invokes Restful servie
							uploadStatus = cashMediaUtilityService.alfrescoUpload(contentInputStream, json.toString(),
									documentTitle, lockBoxNo, FolderName);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						if (!uploadStatus) {
							break;
						}
					} else {
						errorMessage = contentInputStream != null ? Constants.ERROR_MSG_METADATAFORMATION
								: Constants.ERROR_MSG_PDFGENERATION;
						uploadStatus = false;
						break;
					}
				}
			}

		}
		return uploadStatus;
	}

	// deleted method populateDefaultValues
	// deleted method populateMappedValues
	// deleted method populateDisplayValues

	/**
	 * generateContentInputStream is used for getting the PDF as a input stream. PDf
	 * will be created from the images taken from the xmlProperty passed as an input
	 * parameter
	 * 
	 * @param xmlProperty XMLPropertyVO
	 * @return InputStream
	 */
	public InputStream generateContentInputStream(XMLPropertyVO xmlProperty, boolean hasMultiImagePaths,
			boolean isTiffImage) {
		InputStream contentInputStream = null;
		PDFGenerator pdfGenerator = null;
		pdfGenerator = new PDFGenerator();

		long startTime = new Date().getTime();
		// if condition is modified that checks SourceType from filenet obj
		// targetDocumentProperties
		if (displayValuesMap.get("gecap_sourceType").equals(Constants.BANK_SOURCETYPE_RBC)) {
			contentInputStream = pdfGenerator.convertRBCImageToPDF(dataMap.get(xmlProperty.getMappedTo()));
			pages = (pages - 1) / 2;
			return contentInputStream;
		}
		if (hasMultiImagePaths) {
			contentInputStream = pdfGenerator.convertToPDF(getFilePathsList(dataMap.get(xmlProperty.getMappedTo())),
					isTiffImage);
		} else {
			contentInputStream = pdfGenerator.convertToPDF(dataMap.get(xmlProperty.getMappedTo()), isTiffImage);
			pages = pdfGenerator.getPagesCount();
		}

		log.debug("Time taken for PDF generation: " + (new Date().getTime() - startTime));

		return contentInputStream;
	}

	/**
	 * getFilePathsList method is used for splitting the multiple file path string
	 * to a individual file paths
	 * 
	 * @param multiFilesPath String
	 * @return List<String>
	 */
	public List<String> getFilePathsList(String multiFilesPath) {

		String fileNameWithPath;
		ArrayList<String> filePathsList;
		String[] individualFilePaths = null;
		String fileLocation = null;

		filePathsList = new ArrayList<String>();
		individualFilePaths = multiFilesPath.split(Constants.CSV_VALUE_SEPARATOR);

		if (individualFilePaths.length > 1) {
			fileNameWithPath = individualFilePaths[0];
			fileLocation = fileNameWithPath.substring(0, fileNameWithPath.lastIndexOf(File.separator));
			individualFilePaths[0] = individualFilePaths[0].replace(fileLocation, "");

			for (String currentFilePath : individualFilePaths) {
				filePathsList.add(fileLocation + File.separator + currentFilePath);
			}
		} else {
			filePathsList.add(multiFilesPath);
		}
		return filePathsList;
	}

	// deleted method filenetUpload that uploads document to fileNet

	/**
	 * sets the metadata from the csv file generated
	 * 
	 * @param xmlProperty the XMLPropertyVO to get the symname and populate it as
	 *                    key to the metadata value in map object.
	 */
	public boolean setMetaData(XMLPropertyVO xmlProperty) {

		try {
			displayValuesMap.put(xmlProperty.getSymbolicName(), dataMap.get(xmlProperty.getMappedTo()));

			return true;
		} catch (Exception ex) {
			log.error("Error occured while setting the metadata " + ex);
			return false;
		}

	}

}
