package com.ge.alfrs.alfrescouploader.constants;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
/**
 * 
 *	@author mahindraSatyam, VS60636
 */
public class Messages {
	
	public static Locale locale = new Locale("en", "US");
	
	private static final String BUNDLE_NAME = "config/AlfrescoUploaderUtility";
	private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle
			.getBundle(BUNDLE_NAME, locale);

	private Messages() {
	}

	public static String getString(String key) {
		try {
			return RESOURCE_BUNDLE.getString(key);
		} catch (MissingResourceException e) {
			return '!' + key + '!';
		}
	}

}