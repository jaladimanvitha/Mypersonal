import { Component, OnInit } from '@angular/core';
import { ContractUploadModel } from '../_models/ContractUploadModel';
import { ContractDealDropDown } from '../_models/ContractDealDropDown';
import { Router, ActivatedRoute } from '@angular/router';
import { FileSelectDirective, FileUploader } from 'ng2-file-upload';
import { FormControl, NgForm, FormBuilder } from '@angular/forms';
import { NgbModal, ModalDismissReasons, NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-contract-upload',
  templateUrl: './contract-upload.component.html',
  styleUrls: ['./contract-upload.component.css']
})
export class ContractUploadComponent implements OnInit {

  modalReference: NgbModalRef;
  closeResult: string;
  contractModel: ContractUploadModel = new ContractUploadModel();
  contract1: ContractDealDropDown[] = [
    { id: 0, name: 'Loan' },
    { id: 1, name: 'Lease' },
    { id: 2, name: 'Progress-Loan' },
  ];

  public partyData = [
    {
      "documentSubType": "",
      "welcomePackage": "",
      "syndicationPackage": "",
      "physicalStorageStatus": "",
      "fileName": "",
      "progress": "",

    }];

    
  constructor(private modalService: NgbModal, private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.contractModel.partyNumber2 = this.activatedRoute.snapshot.queryParamMap.get('partyNumber2');
    this.contractModel.partyName2 = this.activatedRoute.snapshot.queryParamMap.get('partyName2');
    this.contractModel.sfdcAccountId2 = this.activatedRoute.snapshot.queryParamMap.get('sfdcAccountId2');
    this.contractModel.sfdcopportunityId2 = this.activatedRoute.snapshot.queryParamMap.get('sfdcopportunityId2');
    this.contractModel.lineofcreditNumber2 = this.activatedRoute.snapshot.queryParamMap.get('lineofcreditNumber2');
    this.contractModel.lwSeqNumber2 = this.activatedRoute.snapshot.queryParamMap.get('lwSeqNumber2');
    this.contractModel.contractDealtype2 = this.activatedRoute.snapshot.queryParamMap.get('contractDealtype2');
    this.contractModel.lineofBusinessCode2 = this.activatedRoute.snapshot.queryParamMap.get('lineofBusinessCode2');
    this.contractModel.legalEntityName2 = this.activatedRoute.snapshot.queryParamMap.get('legalEntityName2');
  }
 
  upload(userForm: NgForm) {
    if (userForm.form.value.docSubType4 == null) {
      alert('document SubType cannot be Empty');
      return false;
    } else {
      if (userForm.form.value.partyNumber2 == null) {
        alert('Party Number cannot be Empty');
        return false;
      } else {
        if (userForm.form.value.lineofcreditNumber2 == null) {
          alert('Line of Credit Number cannot be Empty');
          return false;
        }
      }
    }
    console.log(userForm.form.value);
    return true;

  }
  open(content) {
    this.modalReference = this.modalService.open(content);
    this.modalReference.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  close() {
    this.modalReference.close();
    this.router.navigate(['/home']);
  }
}
